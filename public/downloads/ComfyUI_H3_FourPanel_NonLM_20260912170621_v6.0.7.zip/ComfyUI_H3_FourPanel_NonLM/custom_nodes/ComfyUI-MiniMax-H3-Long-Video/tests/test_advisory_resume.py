# SPDX-License-Identifier: MIT
"""Checkpoint/candidate regressions, independent of a running GPU server."""
import ast
import hashlib
import json
import pathlib
import types
import unittest
from safetensors import safe_open

ROOT = pathlib.Path(__file__).resolve().parents[1]
source = ROOT.joinpath("minimax_h3_long_video/nodes.py").read_text(encoding="utf-8")
tree = ast.parse(source)
names = {"_checkpoint_audit_reusable", "_restored_audit_record", "_validate_preserved_segments",
         "_metadata_matches", "_segment_noise_seed", "_segment_lineage", "_prompt_hash",
         "_generate_verified_segment", "_candidate_quality_rank", "_resume_segment_candidate", "_may_reuse_segment", "_segment_attempt_count"}
nodes = [ast.ImportFrom(module="__future__", names=[ast.alias(name="annotations")], level=0)]
nodes += [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in names]
class Interrupted(Exception): pass
ns = {"hashlib": hashlib, "json": json, "safe_open": safe_open, "SCHEMA_VERSION": 25,
      "comfy": types.SimpleNamespace(model_management=types.SimpleNamespace(InterruptProcessingException=Interrupted))}
exec(compile(ast.fix_missing_locations(ast.Module(body=nodes, type_ignores=[])), "checkpoint-functions", "exec"), ns)

class ResumeTests(unittest.TestCase):
    def test_advisory_best_candidate_reuses_even_if_quality_failed(self):
        self.assertTrue(ns["_checkpoint_audit_reusable"]({"segment_audit_policy": "advisory-v2"}, True))
        self.assertFalse(ns["_checkpoint_audit_reusable"]({"segment_audit_policy": "unknown"}, True))
        self.assertTrue(ns["_checkpoint_audit_reusable"]({}, False))

    def test_old_advisory_failure_is_not_relabelled_pass(self):
        row = {"index": 1, "attempt": 2, "status": "fail: dialogue audio: missing tail", "failed": True}
        manifest = {"selected_segment_audits": {"1": row}}
        self.assertEqual(ns["_restored_audit_record"]({}, manifest, 1, 2), row)
        self.assertTrue(ns["_restored_audit_record"]({}, {}, 1, 2)["status"].startswith("unavailable:"))

    def test_metadata_failure_flag_is_parsed_not_truthy_string(self):
        for value, expected in [("False", False), ("True", True)]:
            row = ns["_restored_audit_record"]({"segment_audit_status": "pass", "segment_audit_failed": value}, {}, 0, 0)
            self.assertEqual(row["failed"], expected)

    def test_saved_third_attempt_passes_resume_validation(self, candidate_attempt=2):
        import tempfile
        import torch
        from safetensors.torch import save_file
        with tempfile.TemporaryDirectory() as directory:
            seg = types.SimpleNamespace(index=0, raw_frames=127, context_frames=0, output_start=0, output_frames=120)
            prompt = "A quiet garden."
            prompt_hash = ns["_prompt_hash"](prompt)
            seed = ns["_segment_noise_seed"](12, 0, candidate_attempt)
            lineage = ns["_segment_lineage"]("fp", "root", seg, prompt_hash, candidate_attempt)
            metadata = {**vars(seg), "schema": 25, "width": 864, "height": 480, "seed": seed,
                        "prompt_sha256": prompt_hash, "generation_fingerprint": "fp",
                        "predecessor_lineage": "root", "lineage": lineage, "segment_audit_attempt": candidate_attempt}
            path = pathlib.Path(directory) / "segment.safetensors"
            save_file({"video": torch.zeros(1)}, str(path), {k: str(v) for k, v in metadata.items()})
            args = ([path], [seg], [prompt], 1, 864, 480, 12, "fp", False)
            ns["_validate_preserved_segments"](*args)
            with self.assertRaises(ValueError):
                ns["_validate_preserved_segments"]([path], [seg], ["changed"], *args[3:])

    def test_fourth_and_fifth_attempts_resume(self):
        for attempt in [3,4]:
            with self.subTest(attempt=attempt):
                self.test_saved_third_attempt_passes_resume_validation(attempt)
    def test_sixth_attempt_is_out_of_bounds(self):
        with self.assertRaises(ValueError):
            self.test_saved_third_attempt_passes_resume_validation(5)

class CandidateTests(unittest.TestCase):
    def test_all_retries_fail_retains_best_not_last(self):
        rows = [
            (True, 'fail: dialogue audio: {"issues":[{"kind":"overlap"},{"kind":"changed"}]}'),
            (True, 'fail: dialogue audio: {"issues":[{"kind":"missing"}]}'),
            (True, 'fail: dialogue audio: {"issues":[{"kind":"overlap"}]}')]
        seen = []
        out, attempt = ns["_generate_verified_segment"](lambda i, feedback: i,
             lambda i: rows[i], lambda *r: seen.append(r), True, max_attempts=3)
        self.assertEqual((out, attempt), (1, 1))
        self.assertEqual(len(seen), 3)

    def test_default_five_failures_retains_best(self):
        rows=[(True,'fail: dialogue audio: {"issues":[{"kind":"overlap"},{"kind":"changed"}]}')]*5
        rows[3]=(True,'fail: dialogue audio: {"issues":[{"kind":"missing"}]}')
        seen=[]
        out,attempt=ns['_generate_verified_segment'](lambda i,f:i,lambda i:rows[i],lambda *r:seen.append(r),True)
        self.assertEqual(len(seen),5)
        self.assertEqual((out,attempt),(3,3))
    def test_fifth_success_and_early_success(self):
        for pass_at in [0,4]:
            seen=[]
            out,attempt=ns['_generate_verified_segment'](lambda i,f:i,
                lambda i:(False,'pass') if i==pass_at else (True,'fail: bad candidate'),lambda *r:seen.append(r),True)
            self.assertEqual((out,attempt),(pass_at,pass_at))
            self.assertEqual(len(seen),pass_at+1)
    def test_disabled_audit_generates_once(self):
        calls=[]
        out,attempt=ns['_generate_verified_segment'](lambda i,f:calls.append(i) or i,lambda i:self.fail('audit should be disabled'),lambda *r:None,False)
        self.assertEqual(calls,[0])

    def test_inspector_failure_does_not_trigger_unbounded_generations(self):
        calls = []
        def generate(i, feedback):
            calls.append(i)
            return i
        def audit(i):
            raise RuntimeError("unavailable")
        self.assertEqual(ns["_generate_verified_segment"](generate, audit, lambda *r: None, True), (0, 0))
        self.assertEqual(calls, [0])

    def test_user_interruption_propagates(self):
        def audit(_):
            raise Interrupted()
        with self.assertRaises(Interrupted):
            ns["_generate_verified_segment"](lambda *a: 0, audit, lambda *a: None, True)


class CumulativeRetryTests(unittest.TestCase):
    def test_automatic_resume_continues_interrupted_target_but_keeps_earlier_segments(self):
        f = ns['_may_reuse_segment']
        for status in ('sampling', 'segment_auditing', 'segment_check_failed'):
            m = {'status':status, 'current_segment':2}
            self.assertTrue(f(True,False,-1,0,m))
            self.assertTrue(f(True,False,-1,1,m))
            self.assertFalse(f(True,False,-1,2,m))
        self.assertTrue(f(True,False,-1,2,{'status':'complete_with_audit_failure','current_segment':2}))
        self.assertFalse(f(True,True,-1,2,{}))
        self.assertFalse(f(True,False,2,2,{}))

    def test_resume_generates_only_remaining_candidates_and_keeps_previous_best(self):
        calls = []
        out, attempt = ns['_generate_verified_segment'](
            lambda i, feedback: calls.append(i) or i,
            lambda i: (True, 'fail: bad candidate'), lambda *r: None, True,
            max_attempts=5, start_attempt=3, initial_candidate='old-best', initial_attempt=1,
            initial_verdict=(False, 'pass'))
        self.assertEqual(calls, [3, 4])
        self.assertEqual((out, attempt), ('old-best', 1))

    def test_exhausted_segment_selects_saved_best_without_sampling(self):
        out, attempt = ns['_generate_verified_segment'](
            lambda *a: self.fail('sixth generation'), lambda *a: self.fail('extra audit'),
            lambda *a: None, True, start_attempt=5, initial_candidate='saved',
            initial_attempt=2, initial_verdict=(True, 'fail: remaining minor issue'))
        self.assertEqual((out, attempt), ('saved', 2))

    def test_exhausted_without_checkpoint_stops_instead_of_resetting_budget(self):
        with self.assertRaises(RuntimeError):
            ns['_generate_verified_segment'](lambda *a: self.fail('reset budget'),
                lambda *a: None, lambda *a: None, True, start_attempt=5)

    def test_best_is_saved_before_later_interruption(self):
        saved = []
        def generate(i, feedback):
            if i == 2:
                raise Interrupted()
            return i
        with self.assertRaises(Interrupted):
            ns['_generate_verified_segment'](generate,
                lambda i: (True, 'fail: generic'), lambda *r: None, True,
                on_best=lambda *row: saved.append(row))
        self.assertEqual(saved, [(0, 0, True, 'fail: generic')])

    def test_manual_rejection_can_be_replaced_without_reusing_old_pass(self):
        out, attempt = ns['_generate_verified_segment'](lambda i, f: 'new',
            lambda i: (False, 'pass'), lambda *r: None, True, start_attempt=1,
            initial_candidate='old', initial_attempt=0,
            initial_verdict=(True, 'fail: user review: broken ending'))
        self.assertEqual((out, attempt), ('new', 1))

    def test_disabled_inspection_still_respects_remaining_budget(self):
        calls = []
        out, attempt = ns['_generate_verified_segment'](lambda i, f: calls.append(i) or i,
            lambda i: self.fail('disabled'), lambda *r: None, False, start_attempt=4)
        self.assertEqual(calls, [4])

    def test_real_checkpoint_restores_count_and_rejects_foreign_predecessor(self):
        import tempfile
        import torch
        from safetensors.torch import save_file, load_file
        with tempfile.TemporaryDirectory() as directory:
            seg = types.SimpleNamespace(index=2, raw_frames=141, context_frames=39,
                                        output_start=624, output_frames=96)
            prompt_hash = ns['_prompt_hash']('tail')
            lineage = ns['_segment_lineage']('fp', 'approved-middle', seg, prompt_hash, 1)
            context = ns['_segment_lineage']('fp', 'approved-middle', seg, prompt_hash)
            metadata = {**vars(seg), 'schema':25, 'width':864, 'height':480,
                'seed':ns['_segment_noise_seed'](12, 2, 1), 'prompt_sha256':prompt_hash,
                'generation_fingerprint':'fp', 'predecessor_lineage':'approved-middle',
                'lineage':lineage, 'segment_audit_attempt':1}
            path = pathlib.Path(directory)/'tail.safetensors'
            save_file({'video':torch.zeros(1)}, str(path), {k:str(v) for k,v in metadata.items()})
            def load(p):
                with safe_open(str(p),framework='pt',device='cpu') as f:
                    return load_file(str(p)), f.metadata()
            ns['_load_segment'] = load
            manifest = {'generation_fingerprint':'fp', 'segment_audits':[{'index':2,'attempt':i} for i in range(3)],
                'segment_attempt_counts':{'2':{'context':context,'count':4}}}
            args = (path,seg,prompt_hash,864,480,12,'fp','approved-middle',manifest,context)
            value, meta, count = ns['_resume_segment_candidate'](*args)
            self.assertIsNotNone(value); self.assertEqual(count,4)
            foreign = ns['_segment_lineage']('fp','other-middle',seg,prompt_hash)
            value, meta, count = ns['_resume_segment_candidate'](*args[:7], 'other-middle', manifest, foreign)
            self.assertIsNone(value); self.assertEqual(count,4)
            path.unlink()
            value, meta, count = ns['_resume_segment_candidate'](*args)
            self.assertIsNone(value); self.assertEqual(count,4)


class ChangedPredecessorBudgetTests(unittest.TestCase):
    def test_old_context_counts_accumulate_without_counting_reused_audits_twice(self):
        rows=[{'index':2,'attempt':i,'context':'old'} for i in range(2)]
        rows += [{'index':2,'attempt':i,'context':'new'} for i in range(3)]
        manifest={'segment_audits':rows+rows,'segment_attempt_counts':{'2':{'context':'new','count':3}}}
        self.assertEqual(ns['_segment_attempt_count'](manifest,2),5)

    def test_new_global_attempt_numbers_are_not_added_across_contexts(self):
        manifest={'attempt_limit_scope':'cumulative-per-segment',
                  'segment_attempt_counts':{'2':{'count':4}},
                  'segment_audits':[{'index':2,'attempt':1,'context':'old'},
                                    {'index':2,'attempt':3,'context':'new'}]}
        self.assertEqual(ns['_segment_attempt_count'](manifest,2),4)

    def test_interrupted_reservation_remains_spent_without_audit(self):
        self.assertEqual(ns['_segment_attempt_count']({'segment_attempt_counts':{'1':{'count':5}}},1),5)

    def test_confirmed_bad_candidate_does_not_beat_unreviewed_new_candidate(self):
        calls=[]
        candidate, attempt=ns['_generate_verified_segment'](
            lambda i,f:calls.append(i) or 'new',lambda v:(True,'unavailable: recognition disagreement'),
            lambda *a:None,True,start_attempt=1,initial_candidate='known-bad',initial_attempt=0,
            initial_verdict=(True,'fail: user review: incorrect dialogue'))
        self.assertEqual((candidate,attempt),('new',1))
        self.assertEqual(calls,[1])


class TimelineMetadataTests(unittest.TestCase):
    def test_runtime_duration_replaces_stale_authoring_duration_only(self):
        import importlib.util
        import sys
        spec = importlib.util.spec_from_file_location("h3_test_timeline_scope", ROOT / "minimax_h3_long_video/timeline.py")
        timeline = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = timeline
        spec.loader.exec_module(timeline)
        for old in ["40秒（8台詞×5秒）", "40 seconds (8 turns x 5 seconds)", "40s"]:
            text = "subject_definitions:\n<Subject 1>: girl.\nsummary:\nDuration: " + old + ". Keep an autumn street setting.\nretention_analysis:\n<Subject 1>: fully_preserved."
            result = timeline._scope_reference_prefix(text, 0, 5, 0, 5)
            self.assertIn("Duration: 5.000 seconds for this local pass", result)
            self.assertIn("Keep an autumn street setting.", result)
            self.assertNotIn(old, result)


if __name__ == "__main__":
    unittest.main()
