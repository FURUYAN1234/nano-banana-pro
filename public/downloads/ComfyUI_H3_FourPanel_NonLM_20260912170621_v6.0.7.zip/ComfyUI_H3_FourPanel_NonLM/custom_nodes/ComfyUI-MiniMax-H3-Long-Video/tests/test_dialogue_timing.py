# SPDX-License-Identifier: GPL-3.0-only
"""Mixed-window speech layout regressions; no model or API is needed."""
import hashlib
import importlib.util
from pathlib import Path
import sys
import types
import unittest

ROOT = Path(__file__).resolve().parents[1]
PACKAGE = "fourpanel_timing_test_package"
package = types.ModuleType(PACKAGE)
package.__path__ = [str(ROOT / "minimax_h3_long_video")]
sys.modules[PACKAGE] = package

def load(name):
    spec = importlib.util.spec_from_file_location(
        PACKAGE + "." + name, ROOT / "minimax_h3_long_video" / (name + ".py"))
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module

timeline = load("timeline")
timing = load("dialogue_timing")


def prompt_and_timing():
    readings = ["そうだね。", "あ" * 40, "ちがうよ！"]
    prompt = """subject_definitions:
<Picture 1> is the reference image.
<Subject 1> (S1) is a woman with short hair.
<Subject 2> (S2) is a man wearing glasses.
summary:
A conversation in a quiet room.
retention_analysis:
Preserve identity and source order.
detailed_description:
[Shot 1]
<Subject 1> (S1) says <d>[Japanese] READING0</d> and reacts.
[Shot 2] At 00:05.000,
<Subject 2> (S2) says <d>[Japanese] READING1</d> and reacts.
[Shot 3] At 00:12.000,
<Subject 1> (S1) says <d>[Japanese] READING2</d> and reacts.
overall_soundscape:
Quiet room ambience.
non_diegetic_music:
Low instrumental music.
[Global Instructions]
Keep identities and voices stable.
"""
    for i, reading in enumerate(readings):
        prompt = prompt.replace("READING" + str(i), reading)
    data = {"schema": timing.SCHEMA, "prompt_sha256": hashlib.sha256(prompt.encode()).hexdigest(),
            "turns": [{"index": i, "reading": reading, "output_frames": frames,
                       "estimated_speech_seconds": seconds}
                      for i, (reading, frames, seconds) in enumerate(zip(readings, [120, 168, 120], [1.5, 5.715, 1.5]))],
            "total_frames": 408}
    return prompt, data


class LayoutTests(unittest.TestCase):
    def test_only_long_turn_extends_with_contiguous_output(self):
        segments = timing.plan_confirmed_windows([120, 168, 120], 39, False)
        self.assertEqual([s.output_start for s in segments], [0, 120, 288])
        self.assertEqual([s.output_frames for s in segments], [120, 168, 120])
        self.assertEqual([s.context_frames for s in segments], [0, 39, 39])
        for segment in segments:
            self.assertEqual(segment.raw_frames % 17, 5)
            self.assertGreaterEqual(segment.raw_frames, segment.output_frames + segment.context_frames)

    def test_initial_latent_has_context_without_adding_output_duration(self):
        segments = timing.plan_confirmed_windows([120, 168], 22, True)
        self.assertEqual([s.context_frames for s in segments], [22, 22])
        self.assertEqual(sum(s.output_frames for s in segments), 288)

    def test_invalid_frames_do_not_silently_round_or_truncate(self):
        for windows in [[], [119], [121], [361], [True], [120.0], [None]]:
            with self.subTest(windows=windows):
                with self.assertRaises(ValueError):
                    timing.plan_confirmed_windows(windows, 39, False)

    def test_legacy_five_second_layout_is_unchanged(self):
        segments = timeline.plan_segments(360, 39, False, 124, exact_output_frames=360)
        self.assertEqual([s.output_frames for s in segments], [120, 120, 120])
        self.assertEqual([s.output_start for s in segments], [0, 120, 240])


class TimingContractTests(unittest.TestCase):
    def test_disconnected_confirmed_timing_cannot_fall_back_to_five_seconds(self):
        with self.assertRaises(ValueError):
            timing.require_timing_connection("CONFIRMED SPEECH TIMING: final words", None)
        timing.require_timing_connection("legacy prompt", None)

    def test_confirmed_prompt_and_layout_match(self):
        prompt, data = prompt_and_timing()
        self.assertEqual(timing.validate_timing(data, prompt), [120, 168, 120])

    def test_edited_prompt_rejected_even_when_turn_count_same(self):
        prompt, data = prompt_and_timing()
        with self.assertRaises(ValueError):
            timing.validate_timing(data, prompt.replace("ちがうよ", "そうだよ"))

    def test_missing_or_reordered_reading_rejected(self):
        prompt, data = prompt_and_timing()
        data["turns"][1]["reading"] = "べつのことば"
        with self.assertRaises(ValueError):
            timing.validate_timing(data, prompt)

    def test_wrong_total_rejected(self):
        prompt, data = prompt_and_timing()
        data["total_frames"] = 360
        with self.assertRaises(ValueError):
            timing.validate_timing(data, prompt)

    def test_variable_slicing_does_not_redistribute_to_equal_windows(self):
        prompt, data = prompt_and_timing()
        segments = timing.plan_confirmed_windows(timing.validate_timing(data, prompt), 39, False)
        local = [timeline.slice_prompt(prompt, s.prompt_start_seconds, s.prompt_end_seconds,
                                       s.context_frames / 24, s.index, len(segments), 17,
                                       confirmed_dialogue_timing=True)
                 for s in segments]
        timing.validate_local_dialogues(local, data)
        self.assertIn("00:08.125", local[1])  # 39/24 guide + 7s - 0.5s reaction.
        self.assertEqual([timing.spoken_lines(p) for p in local],
                         [[r["reading"]] for r in data["turns"]])

    def test_dropped_or_duplicated_local_speech_is_not_accepted(self):
        _, data = prompt_and_timing()
        local = [f"<d>{row['reading']}</d>" for row in data["turns"]]
        local[1] += local[1]
        with self.assertRaises(ValueError):
            timing.validate_local_dialogues(local, data)


if __name__ == "__main__":
    unittest.main()
