import ast
import importlib.util
import json
import re
from pathlib import Path
import types
import unittest

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('local_audio_test',ROOT/'minimax_h3_long_video/local_audio_audit.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)


def observation(text, duration=13, timestamp=None):
    return {'duration':duration,'result':{'text':text,'chunks':[{'text':text,'timestamp':timestamp or [0,duration]}]}}


class SpeechEvidenceTests(unittest.TestCase):
    def result(self, expected, a, b=None):
        return m.evaluate(expected,[observation(a),observation(a if b is None else b,13.8)])

    def test_good_text_and_homophone_spelling_are_not_rejected(self):
        for text in ['今日は、いい天気ですね。','今日は良い天気ですね']:
            self.assertEqual(self.result(['今日は、いい天気ですね。'],text)['status'],'pass')

    def test_one_breath_or_prolonged_vowel_is_not_lexical_babble(self):
        for prefix in ['はぁー、','あああああー、','ふぅー、','うーい、']:
            self.assertEqual(self.result(['ここにしましょう。'],prefix+'ここにしましょう')['status'],'pass')

    def test_explicit_repetition_and_vowel_in_script_are_preserved(self):
        for lines in [['行こう、行こう。'],['ああー！'],['出発しましょう。','出発しましょう。']]:
            self.assertEqual(self.result(lines,''.join(lines))['status'],'pass')

    def test_consistent_extra_speech_is_retake_candidate(self):
        result=self.result(['向こうのベンチで少し休みましょう'],
               'はぁうぅはぁんばよちぇ向こうのベンチで少し休みましょう',
               'はぁうぅはぁんばよちぇー向こうのベンチで少し休みましょう')
        self.assertEqual(result['status'],'fail')
        self.assertEqual(result['issues'][0]['kind'],'unscripted_speech')
        self.assertTrue(result['automatic_regeneration'])
        self.assertIsNone(result['quality_pass'])

    def test_unwritten_repetition_is_retake_candidate(self):
        result=self.result(['今日はいい天気ですね'],'今日はいい天気ですね今日はいい天気ですね')
        self.assertEqual(result['issues'][0]['kind'],'repeated_speech')

    def test_disagreement_does_not_request_regeneration(self):
        result=self.result(['ここにしましょう'],'ここにしましょうありがとうございました','ここにしましょう')
        self.assertEqual(result['status'],'unavailable')
        self.assertFalse(result['automatic_regeneration'])

    def test_invalid_recognition_timestamps_do_not_trigger_retake(self):
        for ts in [[0,14],[2,1],[0,None],[0,float('nan')],[0,float('inf')]]:
            result=m.evaluate(['ここにしましょう'],[observation('ここにしましょうありがとうございました',timestamp=ts),observation('ここにしましょうありがとうございました')])
            self.assertEqual(result['status'],'unavailable')
            self.assertFalse(result['automatic_regeneration'])

    def test_low_coverage_is_unknown_not_a_quality_failure(self):
        result=self.result(['今日はいい天気ですね'],'ご視聴ありがとうございました')
        self.assertEqual(result['status'],'unavailable')
        self.assertFalse(result['automatic_regeneration'])

    def test_no_script_is_not_used_as_silence_proof(self):
        self.assertEqual(m.evaluate([],[])['status'],'not_applicable')

    def test_dialogue_tags_keep_words_only(self):
        self.assertEqual(m.expected_lines('<d>[Japanese] 行こう。</d> (S2) <d>[Japanese] はい。</d>'),['行こう。','はい。'])


class AdvisorySelectionTests(unittest.TestCase):
    def functions(self):
        source=(ROOT/'minimax_h3_long_video/nodes.py').read_text(encoding="utf-8")
        names={'_candidate_quality_rank','_generate_verified_segment','_combine_three_mode_audits','_audio_result_status','_retry_generation_prompt','_checked_candidate_attempt_limit','_split_retake_feedback','_strip_retake_notes','_prepare_segment_retake'}
        ns={'json':json,'re':re,'comfy':types.SimpleNamespace(model_management=types.SimpleNamespace(InterruptProcessingException=KeyboardInterrupt))}
        body=[n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name in names]
        exec(compile(ast.Module(body=body,type_ignores=[]),'selection','exec'),ns)
        return ns

    def failure(self,size):
        return 'fail: dialogue audio: '+json.dumps({'verdict':{'pass':False,'issues':[{'kind':'unscripted_speech','extra_characters':size}]}})

    def test_five_failures_return_best_not_last_or_unbounded(self):
        f=self.functions();seen=[];sizes=[20,12,4,10,8]
        best,attempt=f['_generate_verified_segment'](lambda i,feedback:seen.append(i) or i,
                      lambda i:(True,self.failure(sizes[i])),lambda *args:None,True,max_attempts=5)
        self.assertEqual(seen,list(range(5)))
        self.assertEqual((best,attempt),(2,2))

    def test_first_pass_stops_without_extra_generations(self):
        f=self.functions();seen=[]
        best,attempt=f['_generate_verified_segment'](lambda i,feedback:seen.append(i) or i,
                      lambda i:([],'pass'),lambda *args:None,True,max_attempts=5)
        self.assertEqual(seen,[0])

    def test_checker_failure_does_not_trigger_five_regenerations(self):
        f=self.functions();seen=[]
        f['_generate_verified_segment'](lambda i,feedback:seen.append(i) or i,
                      lambda i:(True,'unavailable: ASR disagreement'),lambda *args:None,True,max_attempts=5)
        self.assertEqual(seen,[0])

    def test_failed_audio_cannot_hide_behind_visual_pass(self):
        f=self.functions();result=f['_combine_three_mode_audits'](([],'pass'),(False,json.dumps({'verdict':{'pass':False,'issues':[{'kind':'unscripted_speech'}]}})))
        self.assertTrue(result[0]);self.assertTrue(result[1].startswith('fail: audiovisual:'))

    def test_retry_never_repeats_rejected_transcript_into_prompt(self):
        f=self.functions();status='fail: dialogue audio: '+json.dumps({'verdict':{'pass':False,'issues':[{'kind':'unscripted_speech','corroborated_extras':['bad transcript']} ]}})
        result=f['_retry_generation_prompt']('<d>[Japanese] 行こう。</d>',status)
        self.assertIn('speech-free beats',result);self.assertNotIn('bad transcript',result)


class RepeatedVocalizationTests(unittest.TestCase):
    line = '向こうのベンチで少し休みましょう'

    def test_repeated_hums_match_across_phonetic_spellings(self):
        for a, b in [('うーんうーんうーん', 'ふーんふーんふーん'),
                     ('んーんーんー', 'ンーンーンー'), ('ん、ん、ん、', 'ん ん ん ')]:
            result = m.evaluate([self.line], [observation(a+self.line), observation(b+self.line)])
            self.assertEqual(result['status'], 'fail')
            self.assertEqual(result['issues'][0]['kind'], 'repeated_vocalization')
            self.assertEqual(result['issues'][0]['repeat_count'], 3)

    def test_single_hum_long_vowel_and_short_breaths_remain_permitted(self):
        for prefix in ['うーーーーんーー', 'んんんー', 'あああああああー', 'ふぅー、はぁー、ふぅー、']:
            result = m.evaluate([self.line], [observation(prefix+self.line)]*2)
            self.assertEqual(result['status'], 'pass', prefix)

    def test_scripted_humming_is_not_an_extra(self):
        line = 'んー、んー、んー、ここにしましょう。'
        self.assertEqual(m.evaluate([line], [observation(line)]*2)['status'], 'pass')

    def test_omission_in_one_context_requests_bounded_confirmation(self):
        pair = [observation(self.line), observation('ああうーんうーんうーん'+self.line)]
        first = m.evaluate([self.line], pair)
        self.assertEqual(first['status'], 'unavailable')
        self.assertTrue(first['needs_context_recheck'])
        self.assertFalse(first['automatic_regeneration'])
        result = m.evaluate([self.line], pair+[observation('ふーんふーんふーん'+self.line)])
        self.assertEqual(result['status'], 'fail')
        self.assertEqual(result['issues'][0]['observed_counts'], [0, 3, 3])

    def test_uncorroborated_or_only_two_hums_do_not_trigger_retake(self):
        for prefixes in [('', 'うーんうーんうーん', ''), ('んーんー', 'んーんー')]:
            result = m.evaluate([self.line], [observation(prefix+self.line) for prefix in prefixes])
            self.assertEqual(result['status'], 'unavailable')
            self.assertFalse(result['automatic_regeneration'])

    def test_invalid_third_timing_never_confirms_repetition(self):
        text = 'んーんーんー'+self.line
        result = m.evaluate([self.line], [observation(self.line), observation(text),
                                          observation(text, timestamp=[0, 30])])
        self.assertEqual(result['status'], 'unavailable')
        self.assertFalse(result['automatic_regeneration'])

    def test_runtime_uses_third_context_only_for_disagreement(self):
        import torch
        from unittest.mock import patch
        for prefixes, expected_calls, expected_status in [
                (['', ''], 2, 'pass'),
                (['', 'んーんーんー', 'ふーんふーんふーん'], 3, 'fail'),
                (['', 'んーんーんー', ''], 3, 'unavailable')]:
            calls = []
            outer = self
            class Recognizer:
                device = torch.device('cpu')
                def __call__(self, audio, **kwargs):
                    text = prefixes[len(calls)]+outer.line
                    calls.append(len(audio['array'])/audio['sampling_rate'])
                    return observation(text, duration=calls[-1])['result']
            with patch.object(m, 'configuration', return_value='local-test'), patch.object(m, '_recognizer', return_value=Recognizer()):
                result = m.audit({'waveform':torch.zeros(1, 1, 16000), 'sample_rate':16000},
                                 '<d>[Japanese] '+self.line+'</d>')
            self.assertEqual(len(calls), expected_calls)
            self.assertEqual(result['status'], expected_status)
            self.assertEqual(result['recognition_passes'], expected_calls)
            self.assertEqual(calls[:2], [1.0, 1.8])
            if expected_calls == 3:
                self.assertEqual(calls[-1], 2.6)


class RepeatedVoiceSelectionTests(unittest.TestCase):
    def test_five_failed_candidates_keep_fewest_repeated_hums(self):
        funcs = AdvisorySelectionTests().functions()
        counts = [7, 5, 3, 6, 4]
        seen = []
        def audit(i):
            return True, 'fail: dialogue audio: '+json.dumps({'verdict':{'pass':False,
                'issues':[{'kind':'repeated_vocalization','repeat_count':counts[i]}]}})
        best, attempt = funcs['_generate_verified_segment'](lambda i, feedback: seen.append(i) or i,
                       audit, lambda *args: None, True, max_attempts=5)
        self.assertEqual(seen, list(range(5)))
        self.assertEqual((best, attempt), (2, 2))

    def test_retake_addresses_humming_without_echoing_recognized_sounds(self):
        funcs = AdvisorySelectionTests().functions()
        status = 'fail: dialogue audio: '+json.dumps({'verdict':{'pass':False,
            'issues':[{'kind':'repeated_vocalization','observed_transcript':'ふーんふーんふーん'}]}})
        prompt = '<d>[Japanese] 行こう。</d>'
        result = funcs['_retry_generation_prompt'](prompt, status)
        self.assertIn('Do not hum', result)
        self.assertIn('brief natural breath', result)
        self.assertIn(prompt, result)
        self.assertNotIn('ふーん', result)


class CandidateBudgetTests(unittest.TestCase):
    def test_explicit_attempt_limit_is_one_to_five_only(self):
        check=AdvisorySelectionTests().functions()['_checked_candidate_attempt_limit']
        for value in range(1,6):
            self.assertEqual(check(value),value)
        for value in (0,6,-1,2.5,'3',None,True):
            with self.assertRaises(ValueError):
                check(value)

    def test_one_candidate_keeps_inspection_without_automatic_retakes(self):
        funcs=AdvisorySelectionTests().functions();generated=[];inspected=[];reported=[]
        def audit(candidate):
            inspected.append(candidate)
            return True, 'fail: dialogue audio: '+json.dumps({'verdict':{'pass':False,'issues':[{'kind':'repeated_vocalization','repeat_count':3}]}})
        best,attempt=funcs['_generate_verified_segment'](lambda i,feedback:generated.append(i) or i,
                        audit,lambda *args:reported.append(args),True,max_attempts=1)
        self.assertEqual(generated,[0]);self.assertEqual(inspected,[0]);self.assertEqual(len(reported),1)
        self.assertTrue(reported[0][1]);self.assertEqual((best,attempt),(0,0))


class CoverageDisagreementTests(unittest.TestCase):
    def test_one_context_loses_script_requests_only_one_confirmation(self):
        expected=['向こうのベンチで少し休みましょう']
        pair=[observation('ああ向こうのベンチで少し休みます'), observation('ああああんんんん')]
        result=m.evaluate(expected,pair)
        self.assertEqual(result['status'],'unavailable')
        self.assertTrue(result['needs_context_recheck'])
        self.assertFalse(result['automatic_regeneration'])
        result=m.evaluate(expected,pair+[observation('んんんん')])
        self.assertFalse(result['needs_context_recheck'])
        self.assertFalse(result['automatic_regeneration'])

    def test_two_usable_contexts_can_agree_despite_one_omission(self):
        text='今日はいい天気ですね'
        result=m.evaluate([text],[observation(text),observation('ああああ'),observation(text)])
        self.assertEqual(result['status'],'pass')
        self.assertIsNone(result['quality_pass'])

    def test_dialogue_quality_has_priority_when_all_candidates_have_defects(self):
        f=AdvisorySelectionTests().functions()['_candidate_quality_rank']
        bad_voice='fail: dialogue audio: '+json.dumps({'verdict':{'pass':False,'issues':[{'kind':'changed_words'}]}})
        wrong_words='fail: audiovisual: '+json.dumps({'audio':bad_voice,'visual':'pass'})
        wardrobe='fail: audiovisual: '+json.dumps({'audio':'pass','visual':'fail: visual continuity: '+json.dumps({'pass':False,'issues':[{'kind':'wardrobe_mismatch'}]})})
        self.assertLess(f(True,wardrobe),f(True,wrong_words))


class CoverageRuntimeTests(unittest.TestCase):
    def test_coverage_omission_uses_third_context_once_without_forcing_retake(self):
        import torch
        from unittest.mock import patch
        line='向こうのベンチで少し休みましょう'
        for third, expected_status in [(line,'pass'),('あああんんん','unavailable')]:
            answers=[line,'ああああんんん',third];calls=[]
            class Recognizer:
                device=torch.device('cpu')
                def __call__(self,audio,**kwargs):
                    text=answers[len(calls)];duration=len(audio['array'])/audio['sampling_rate'];calls.append(duration)
                    return observation(text,duration=duration)['result']
            with patch.object(m,'configuration',return_value='local-test'),patch.object(m,'_recognizer',return_value=Recognizer()):
                result=m.audit({'waveform':torch.zeros(1,1,16000),'sample_rate':16000},'<d>[Japanese] '+line+'</d>')
            self.assertEqual(len(calls),3)
            self.assertEqual(result['status'],expected_status)
            self.assertFalse(result['automatic_regeneration'])


class KanaEndingTests(unittest.TestCase):
    def test_confirmed_changed_ending_does_not_pass_extra_speech_guard(self):
        result=m.evaluate(['向こうのベンチで少し休みましょう'],[
            observation('ああ向こうのベンチで少し休みます'),
            observation('ああああうん向こうのベンチで少し休みます')])
        self.assertEqual(result['status'],'fail')
        self.assertTrue(result['automatic_regeneration'])
        self.assertEqual(result['issues'][0]['kind'],'changed_words')
        self.assertEqual(result['issues'][0]['expected_ending'],'しょう')
        self.assertEqual(result['issues'][0]['recognized_ending'],'す')
        self.assertIsNone(result['quality_pass'])

    def test_spelling_homophones_breaths_and_one_vowel_stay_allowed(self):
        for expected,actual in [('今日はいい天気ですね','今日は良い天気ですね'),
                                ('ありがとうございます','有難う御座います'),
                                ('お願いします','おねがいします'),
                                ('ここにしましょう','ここにしましょー'),
                                ('ここにしましょう','ふぅーここにしましょう'),
                                ('ここにしましょう','ここにしましょうあああー')]:
            result=m.evaluate([expected],[observation(actual)]*2)
            self.assertNotEqual(result['status'],'fail',(expected,actual))
            self.assertFalse(result['automatic_regeneration'])

    def test_one_disagreeing_ending_is_rechecked_but_not_a_retake(self):
        line='向こうのベンチで少し休みましょう';bad='向こうのベンチで少し休みます'
        pair=[observation(line),observation(bad)]
        first=m.evaluate([line],pair)
        self.assertTrue(first['needs_context_recheck']);self.assertFalse(first['automatic_regeneration'])
        result=m.evaluate([line],pair+[observation(line)])
        self.assertFalse(result['automatic_regeneration'])
        self.assertEqual(m.evaluate([line],pair+[observation(bad)])['status'],'fail')

    def test_explicit_scripted_ending_is_authoritative(self):
        line='向こうのベンチで少し休みます'
        self.assertEqual(m.evaluate([line],[observation(line)]*2)['status'],'pass')


class RetakeRoutingTests(unittest.TestCase):
    prompt = ("subject_definitions:\n<Subject 7> (S2): a woman in a blue jacket.\n"
              "detailed_description:\n[Shot 1] At 00:01.625, <Subject 7> (S2) says "
              "<d>[Japanese] せきにん。</d> Original staging.\n"
              "overall_soundscape: soft room tone.\nnon_diegetic_music: N/A\n")

    def visual(self):
        return "fail 3:" + json.dumps({
            "first": {"pass": False, "issues": [{"issue": "Two simultaneous copies of Subject 7."}]},
            "recheck": {"pass": False, "issues": [], "speaker_check": {
                "status": "fail", "expected_subject_id": 7, "expected_speaker_id": "S2",
                "extra_speaking_subject_ids": [9]}}})

    def combined(self, audio="pass", visual=None):
        return "fail: audiovisual: " + json.dumps({
            "audio": audio, "visual": self.visual() if visual is None else visual})

    def test_compound_visual_failure_calls_replacement_with_visual_only(self):
        f = AdvisorySelectionTests().functions()
        calls = []
        repaired = self.prompt.replace("Original staging.", "One readable speaker at the desk.")
        def repair(base, feedback):
            calls.append((base, feedback))
            return repaired, {"revision": "test"}
        result, record = f["_prepare_segment_retake"](self.prompt, self.combined(), repair)
        self.assertEqual(calls, [(self.prompt, self.visual())])
        self.assertEqual(result, repaired)
        self.assertEqual(record["status"], "repaired")
        self.assertNotIn("Two simultaneous copies", result)
        self.assertNotIn("RETAKE CORRECTION", result)

    def test_compound_audio_failure_keeps_words_and_adds_one_audio_note_after_repair(self):
        f = AdvisorySelectionTests().functions()
        status = "fail: dialogue audio: " + json.dumps({
            "verdict": {"pass": False, "issues": [
                {"kind": "changed_words", "heard": "UNRELATED REJECTED TRANSCRIPT"}]}})
        result, record = f["_prepare_segment_retake"](
            self.prompt, self.combined(audio=status),
            lambda base, feedback: (base.replace("Original staging.", "Readable speaker."), {}))
        self.assertIn("Readable speaker.", result)
        self.assertEqual(re.findall(r"<d>.*?</d>", result), re.findall(r"<d>.*?</d>", self.prompt))
        self.assertIn("00:01.625", result)
        self.assertEqual(result.count("[AUDIO RETAKE CORRECTION"), 1)
        self.assertNotIn("[VISUAL RETAKE CORRECTION", result)
        self.assertNotIn("UNRELATED REJECTED TRANSCRIPT", result)
        self.assertIn("non_diegetic_music: N/A", result)

    def test_audio_only_and_checker_outages_do_not_call_visual_repair(self):
        f = AdvisorySelectionTests().functions()
        def forbidden(*args):
            self.fail("No visual failure exists")
        audio = "fail: dialogue audio: " + json.dumps({
            "verdict": {"pass": False, "issues": [{"kind": "missing_speech"}]}})
        for feedback in (audio, self.combined(audio=audio, visual="pass"),
                         self.combined(visual="unavailable: timeout"), "pass", "", "unavailable: timeout",
                         "fail: audiovisual: broken JSON", "fail: audiovisual: []"):
            with self.subTest(feedback=feedback):
                result, record = f["_prepare_segment_retake"](self.prompt, feedback, forbidden)
                self.assertIsNone(record)
                self.assertNotIn("[VISUAL RETAKE CORRECTION", result)

    def test_fallback_never_copies_audit_json_or_keeps_old_notes(self):
        f = AdvisorySelectionTests().functions()
        def unavailable(*args):
            raise RuntimeError("provider failed")
        old = f["_retry_generation_prompt"](self.prompt, self.combined())
        result, record = f["_prepare_segment_retake"](old, self.combined(), unavailable)
        self.assertEqual(record, {"status": "unavailable", "error_type": "RuntimeError"})
        self.assertEqual(result.count("[VISUAL RETAKE CORRECTION"), 1)
        self.assertNotIn("Two simultaneous copies", result)
        self.assertNotIn("expected_subject_id", result)
        self.assertIn("Original staging.", result)

    def test_new_replacement_drops_failed_fallback_and_audio_notes(self):
        f = AdvisorySelectionTests().functions()
        audio = "fail: dialogue audio: " + json.dumps({
            "verdict": {"pass": False, "issues": [{"kind": "changed_words"}]}})
        old = f["_retry_generation_prompt"](self.prompt, self.combined(audio=audio))
        calls = []
        def repair(base, feedback):
            calls.append(base)
            return base.replace("Original staging.", "New staging."), {}
        result, record = f["_prepare_segment_retake"](old, self.combined(), repair)
        self.assertEqual(calls, [self.prompt])
        self.assertNotIn("RETAKE CORRECTION", result)
        self.assertNotIn("Original staging.", result)
        self.assertIn("New staging.", result)

    def test_interruption_propagates_instead_of_generating_another_candidate(self):
        f = AdvisorySelectionTests().functions()
        def interrupted(*args):
            raise KeyboardInterrupt()
        with self.assertRaises(KeyboardInterrupt):
            f["_prepare_segment_retake"](self.prompt, self.combined(), interrupted)

    def test_strip_notes_keeps_following_h3_sections_and_dialogue(self):
        f = AdvisorySelectionTests().functions()
        prompt = ("[Shot 1] <d>[Japanese] 行こう。</d>\n"
                  "[VISUAL RETAKE CORRECTION — highest priority] Old report.\n"
                  "[Global Instructions]\nKeep identities.\n"
                  "overall_soundscape: wind.\nnon_diegetic_music: N/A")
        result = f["_strip_retake_notes"](prompt)
        self.assertNotIn("Old report", result)
        self.assertIn("[Global Instructions]\nKeep identities.", result)
        self.assertIn("non_diegetic_music: N/A", result)
        self.assertIn("<d>[Japanese] 行こう。</d>", result)


if __name__ == "__main__":
    unittest.main()
