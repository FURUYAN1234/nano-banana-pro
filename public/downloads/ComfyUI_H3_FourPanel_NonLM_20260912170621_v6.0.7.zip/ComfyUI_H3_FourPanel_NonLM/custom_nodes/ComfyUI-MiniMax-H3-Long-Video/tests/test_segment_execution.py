"""Run the real sampler execute body; replace only model sampling, inspection and media decoding."""
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import shutil
import sys
import tempfile
import types
import unittest

import torch
from safetensors import safe_open
from safetensors.torch import save_file

ROOT = Path(__file__).resolve().parents[1]
TREE = ast.parse((ROOT / "minimax_h3_long_video/nodes.py").read_text(encoding="utf-8"))
NAMES = {"_checked_candidate_attempt_limit", "_validate_preserved_segments", "_metadata_matches",
         "_segment_noise_seed", "_segment_lineage", "_prompt_hash", "_may_reuse_segment",
         "_checkpoint_audit_reusable", "_restored_audit_record", "_resume_segment_candidate",
         "_manifest_segment", "_generate_verified_segment", "_candidate_quality_rank",
         "_retry_generation_prompt", "_split_retake_feedback", "_strip_retake_notes", "_prepare_segment_retake", "_segment_attempt_count", "_save_resume_fallback",
         "_restore_resume_fallback", "_combine_three_mode_audits", "_audio_result_status"}
BODY = [n for n in TREE.body if isinstance(n, ast.FunctionDef) and n.name in NAMES]
CLASS = next(n for n in TREE.body if isinstance(n, ast.ClassDef) and n.name == "MiniMaxH3LongReferenceSampler")
FUNCTION = next(n for n in CLASS.body if isinstance(n, ast.FunctionDef) and n.name == "execute")
FUNCTION.decorator_list = []
BODY.append(FUNCTION)
SPEC = importlib.util.spec_from_file_location("test_execution_timeline", ROOT / "minimax_h3_long_video/timeline.py")
TL = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = TL
SPEC.loader.exec_module(TL)


class Interrupted(Exception):
    pass


class ExecutionTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.project = Path(self.temporary.name)
        (self.project / "latents").mkdir()
        self.prompts = ["<d>[Japanese] 今日はいい天気ですね。</d>",
                        "<d>[Japanese] 向こうのベンチで少し休みましょう。</d>",
                        "<d>[Japanese] ここにしましょう。</d>"]
        self.settings = ("local", "http://localhost:1234/v1", 20)
        self.audio_config = {"enabled": False}
        contract = {"quality_policy": "three-mode-continuity-v1", "enabled": True,
                    "settings": self.settings, "local_audio_guard": self.audio_config}
        self.fingerprint = hashlib.sha256(("base" + json.dumps(contract, sort_keys=True)).encode()).hexdigest()
        self.sampled = []
        self.audited = []
        self.assemblies = []
        self.interrupt = False
        self.segments = TL.plan_segments(736, 39, False, 328, exact_output_frames=720)
        self.ns = {"hashlib": hashlib, "json": json, "safe_open": safe_open, "re": re, "shutil": shutil,
                   "SCHEMA_VERSION": 25, "FPS": 24, "SEGMENT_SEED_STRATEGY": "test", "AUDIO_CONTINUITY_STRATEGY": "test",
                   "AUDIO_REFINE_STRATEGY": "test", "THREE_MODE_POLICY": "three-mode-continuity-v1",
                   "_expand_cache_name": lambda name,*a:name, "_generation_fingerprint": lambda *a:"base",
                   "plan_segments": TL.plan_segments, "count_timeline_dialogue_turns": TL.count_timeline_dialogue_turns,
                   "require_timing_connection": lambda *a: None,
                   "_output_paths": lambda *a:(self.project,self.project/"master.mp4","test"),
                   "prompt_plan_prompts": lambda *a:self.prompts,
                   "_atomic_text": lambda p,t:p.write_text(t, encoding="utf-8"), "_atomic_json": lambda p,d:p.write_text(json.dumps(d), encoding="utf-8"),
                   "upstream_graph": lambda *a:{}, "standard_audit_settings": lambda *a:self.settings,
                   "local_audio_audit": types.SimpleNamespace(config_contract=lambda:self.audio_config),
                   "_load_segment": self.load, "_save_segment": self.save,
                   "_prepare_references": lambda *a:([],[]),
                   "_delivered_continuation_guide": lambda previous,*a:{"source":previous["saved"]},
                   "_add_continuation_guide": lambda conditioning,guide:conditioning,
                   "_opening_audit_images": lambda value,segment,vae:{"opening":value["saved"]},
                   "h3": types.SimpleNamespace(_empty_av_latent=lambda *a:({},None),
                        MiniMaxH3ImageToVideo=types.SimpleNamespace(execute=lambda *a,**k:(None,{}))),
                   "custom_sampler": types.SimpleNamespace(BasicGuider=types.SimpleNamespace(execute=lambda *a:(None,)),
                        RandomNoise=types.SimpleNamespace(execute=lambda seed:(seed,)),
                        SamplerCustomAdvanced=types.SimpleNamespace(execute=self.sample)),
                   "_refine_segment_audio": lambda model,cond,latent,*a:latent,
                   "_cpu_latent": lambda value:value,
                   "_audit_three_mode_segment": self.audit, "_write_master": self.assemble,
                   "has_tagged_dialogue": TL.has_tagged_dialogue,
                   "comfy": types.SimpleNamespace(model_management=types.SimpleNamespace(InterruptProcessingException=Interrupted)),
                   "InputImpl": types.SimpleNamespace(VideoFromFile=lambda path:path),
                   "ui": types.SimpleNamespace(PreviewVideo=lambda x:x,SavedResult=lambda *x:x),
                   "io": types.SimpleNamespace(NodeOutput=lambda *a,**k:a,FolderType=types.SimpleNamespace(output="output"))}
        exec(compile(ast.fix_missing_locations(ast.Module(body=BODY,type_ignores=[])),"real-sampler-execute","exec"),self.ns)
        self.paths = [self.project/"latents"/f"segment_{seg.index:04d}.safetensors" for seg in self.segments]
        manifest = {"generation_fingerprint":self.fingerprint,"status":"complete", "preserve_generated_audio":True, "segment_attempt_counts":{},
                    "segment_audits":[],"selected_segment_audits":{},"candidate_selection":{},"segments":[]}
        predecessor = "root"
        for seg,path,text,attempt in zip(self.segments,self.paths,self.prompts,[0,0,1]):
            prompt_hash=self.ns['_prompt_hash'](text)
            context=self.ns['_segment_lineage'](self.fingerprint,predecessor,seg,prompt_hash)
            lineage=self.ns['_segment_lineage'](self.fingerprint,predecessor,seg,prompt_hash,attempt)
            seed=self.ns['_segment_noise_seed'](42,seg.index,attempt)
            metadata={"schema":25, "index":seg.index,"raw_frames":seg.raw_frames,"context_frames":seg.context_frames,
                      "output_start":seg.output_start,"output_frames":seg.output_frames,"width":864,"height":480,
                      "seed":seed,"prompt_sha256":prompt_hash,"generation_fingerprint":self.fingerprint,
                      "predecessor_lineage":predecessor,"lineage":lineage,"segment_audit_attempt":attempt,
                      "segment_audit_policy":"advisory-v2","segment_audit_status":"pass","segment_audit_failed":False}
            self.save(path,None,metadata)
            record={"index":seg.index,"attempt":attempt,"failed":False,"status":"pass","context":context}
            manifest['selected_segment_audits'][str(seg.index)]=record
            manifest['segment_audits'].append(record)
            manifest['candidate_selection'][str(seg.index)]={"attempt":attempt+1,"rank":[0,0]}
            manifest['segment_attempt_counts'][str(seg.index)]={"context":context,"count":attempt+1}
            manifest['segments'].append(self.ns['_manifest_segment'](seg,'generated',path,prompt_hash,seed,lineage))
            predecessor=lineage
        self.write_manifest(manifest)

    def save(self,path,value,metadata):
        save_file({'video':torch.tensor([int(metadata['index'])],dtype=torch.float32)},str(path),{k:str(v) for k,v in metadata.items()})

    def load(self,path):
        with safe_open(str(path),framework='pt',device='cpu') as handle:
            return {'saved':path.name},handle.metadata()

    def sample(self,noise,*args):
        if self.interrupt:
            raise Interrupted()
        self.sampled.append(noise)
        return ({'samples':torch.zeros(1)},)

    def audit(self,candidate,previous,source,segment,vae,prompt,refs,*args):
        self.audited.append((segment.index,refs))
        return [],'pass'

    def assemble(self,path,paths,segments,*args,**kwargs):
        self.assemblies.append(sum(seg.output_frames for seg in segments))
        path.write_text('MOCK ASSEMBLY; no media generated', encoding="utf-8")

    def manifest(self):
        return json.loads((self.project/'manifest.json').read_text(encoding="utf-8"))

    def write_manifest(self,value):
        (self.project/'manifest.json').write_text(json.dumps(value), encoding="utf-8")

    def hashes(self):
        return [hashlib.sha256(p.read_bytes()).hexdigest() for p in self.paths]

    def run_sampler(self,start=-1,stop=-1,feedback=''):
        return self.ns['execute'](types.SimpleNamespace(hidden=None),None,None,None,None,'',864,480,736,328,39,42,
                    None,None,'test',True,start,18,
                    prompt_plan={'requested_output_frames':720,'preserve_generated_audio':True,'quality_policy':'three-mode-continuity-v1'},
                    candidate_attempt_limit=5,reroll_feedback=feedback,stop_after_segment=stop)

    def test_compound_fourpanel_audits_rewrite_staging_and_escalate_after_two_visual_failures(self):
        self.settings = {"backend": "nanobanana", "provider": "test"}
        calls, inspected = [], []
        def repair(provider, references, prompt, feedback, *, simplify_framing=False):
            calls.append({"provider": provider, "feedback": feedback, "simplify": simplify_framing})
            return prompt + " Replacement staging.", {"revision": "mock"}
        self.ns["comfy_nodes"] = types.SimpleNamespace(NODE_CLASS_MAPPINGS={
            "NanoBananaH3Transform": types.SimpleNamespace(repair_video_segment_prompt=repair)})
        self.ns["_flatten_image_tensors"] = lambda value: []
        self.ns["_audit_delivered_audio"] = lambda *args: (True, "pass")
        def audit(*args):
            inspected.append(args[0])
            if len(inspected) < 3:
                return [0], "fail: visual continuity: " + json.dumps({
                    "pass": False, "issues": [{"issue": "An extra simultaneous main body."}]})
            return [], "pass"
        self.ns["_audit_three_mode_segment"] = audit
        self.run_sampler(0, 0)
        self.assertEqual(len(inspected), 3)
        self.assertEqual([call["simplify"] for call in calls], [False, True])
        self.assertTrue(all(call["feedback"].startswith("fail: visual continuity:") for call in calls))
        result = self.manifest()
        self.assertEqual(result["segment_attempt_counts"]["0"]["count"], 3)
        self.assertFalse(result["selected_segment_audits"]["0"]["failed"])
        self.assertEqual(result["status"], "partial_complete")

    def test_review_middle_then_continue_tail_preserves_prefix_and_total_counts(self):
        before=self.hashes()
        self.run_sampler(1,1,'Correct the broken dialogue.')
        partial=self.manifest()
        self.assertEqual(self.sampled,[self.ns['_segment_noise_seed'](42,1,1)])
        self.assertEqual(self.assemblies,[624])
        self.assertEqual(partial['status'],'partial_complete')
        self.assertEqual(partial['completed_output_frames'],624)
        self.assertTrue(partial['master_is_partial'])
        self.assertEqual(self.hashes()[0],before[0]);self.assertEqual(self.hashes()[2],before[2])
        self.assertEqual(partial['segment_attempt_counts']['2']['count'],2)
        self.assertEqual(self.audited[0][1],{'opening':'segment_0000.safetensors'})
        prefix=self.hashes()[:2]
        self.run_sampler()
        completed=self.manifest()
        self.assertEqual(self.sampled[-1],self.ns['_segment_noise_seed'](42,2,2))
        self.assertEqual(completed['segment_attempt_counts']['2']['count'],3)
        self.assertEqual(completed['candidate_selection']['2']['attempt'],3)
        self.assertEqual(self.hashes()[:2],prefix)
        self.assertEqual(completed['status'],'complete');self.assertEqual(self.assemblies,[624,720])

    def test_completed_chain_is_kept_when_downstream_budget_is_exhausted(self):
        manifest=self.manifest();manifest['segment_attempt_counts']['2']['count']=5;self.write_manifest(manifest)
        before=self.hashes()
        self.run_sampler(1,feedback='Dialogue still wrong.')
        result=self.manifest()
        self.assertEqual(self.sampled,[]);self.assertEqual(self.hashes(),before)
        self.assertEqual(result['segment_attempt_counts']['1']['count'],1)
        self.assertEqual(result['segment_attempt_counts']['2']['count'],5)
        self.assertIn('budget_fallback',result)
        self.assertEqual(result['status'],'complete_with_audit_failure')
        self.assertTrue(result['selected_segment_audits']['1']['status'].startswith('fail: user review:'))

    def test_fifth_attempt_interruption_restores_a_compatible_chain_without_sixth(self):
        original=self.hashes()
        self.run_sampler(1,1,'Fix middle.')
        manifest=self.manifest();manifest['segment_attempt_counts']['2']['count']=4;self.write_manifest(manifest)
        self.interrupt=True
        with self.assertRaises(Interrupted):self.run_sampler()
        self.assertEqual(self.manifest()['segment_attempt_counts']['2']['count'],5)
        calls=len(self.sampled);self.interrupt=False
        self.run_sampler()
        result=self.manifest()
        self.assertEqual(len(self.sampled),calls)
        self.assertEqual(self.hashes(),original)
        self.assertEqual(result['segment_attempt_counts']['1']['count'],2)
        self.assertEqual(result['segment_attempt_counts']['2']['count'],5)
        self.assertIn('budget_fallback',result)
        self.assertEqual(result['status'],'complete_with_audit_failure')
        self.ns['_validate_preserved_segments'](self.paths,self.segments,self.prompts,3,864,480,42,self.fingerprint,False)

    def test_reviewing_reused_prefix_does_not_spend_any_attempt(self):
        before=self.hashes();self.run_sampler(stop=0)
        self.assertEqual(self.sampled,[]);self.assertEqual(self.hashes(),before)
        self.assertEqual(self.assemblies,[312])
        self.assertEqual(self.manifest()['status'],'partial_complete')

    def test_fallback_pointer_cannot_escape_cache_directory(self):
        manifest=self.manifest();manifest.update(resume_fallback='../outside',attempt_limit=5)
        out=self.ns['_restore_resume_fallback'](self.project,self.paths,self.segments,self.prompts,864,480,42,self.fingerprint,False,manifest)
        self.assertIsNone(out)


if __name__ == '__main__':
    unittest.main()
