"""Visual-only continuity checks, including actual delivered frame selection on CPU."""
import ast
import importlib.util
import json
import math
from pathlib import Path
import tempfile
import types
import unittest
import torch
from PIL import Image, ImageDraw

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('three_mode_audit',ROOT/'minimax_h3_long_video/continuity_audit.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

class AuditPolicyTests(unittest.TestCase):
    def test_disconnected_provider_cannot_supply_audit_credentials(self):
        graph={'150':{'inputs':{'prompt_plan':['138',4]}},
               '138':{'class_type':'H3StandardPrompt','inputs':{'model':'my-local','api_base':'http://127.0.0.1:1234/v1'}},
               '999':{'class_type':'NanoBananaH3Transform','inputs':{'provider':'OpenAI API'}}}
        active=m.upstream_graph(graph,'150')
        self.assertEqual(set(active),{'150','138'})
        self.assertEqual(m.standard_audit_settings(active),('my-local','http://127.0.0.1:1234/v1',360))
        self.assertEqual(m.upstream_graph(graph,'missing'),{})

    def test_pass_and_observed_failure(self):
        self.assertTrue(m.parse_verdict('{"pass":true,"frames_checked":6,"issues":[]}',6)[0])
        bad={'pass':False,'frames_checked':6,'issues':[{'kind':'scene_reset','frame':0,'evidence':'Current frame shows a new room whereas prior frames are outdoors.'}]}
        self.assertFalse(m.parse_verdict(json.dumps(bad),6)[0])

    def test_unsupported_or_unobserved_failure_is_unavailable(self):
        for value in ({'pass':False,'frames_checked':6,'issues':[]},
                      {'pass':True,'frames_checked':1,'issues':[]},
                      {'pass':False,'frames_checked':6,'issues':[{'kind':'wrong_audio','frame':0,'evidence':'heard'}]},
                      {'pass':False,'frames_checked':6,'issues':[{'kind':'scene_reset','frame':8,'evidence':'guess'}]}):
            with self.assertRaises(ValueError):m.parse_verdict(json.dumps(value),6)

    def test_t2v_needs_no_reference_image_and_does_not_claim_audio(self):
        text=m.audit_instruction('A boat sails.',0,2,(0,.25,2,2.25,4.75,5))
        self.assertIn('first 0 images',text)
        self.assertIn('visual-only',text)
        self.assertIn('do not claim to hear speech',text)
        self.assertIn('explicitly scheduled',text)

    def test_inspection_samples_delivered_tail_and_head_not_context_or_padding(self):
        source=(ROOT/'minimax_h3_long_video/nodes.py').read_text(encoding='utf-8')
        fns=[n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name in ('_audit_three_mode_segment','_labeled_audit_image')]
        seen={}
        class VAE:
            def decode(self,value):return value
        class Helper:
            def convert(self,*args,**kwargs):
                seen.update(kwargs)
                return '{"pass":true,"frames_checked":6,"issues":[]}','mock'
        ns={'FPS':24,'torch':torch,'math':math,'Image':Image,'ImageDraw':ImageDraw,'json':json,
            '_streams':lambda x:(x,None),'_flatten_image_tensors':lambda x:[] if not x else list(x.values()),
            'comfy_nodes':types.SimpleNamespace(NODE_CLASS_MAPPINGS={'QwenJapanesePromptLMStudio':Helper}),
            'audit_instruction':m.audit_instruction,'parse_verdict':m.parse_verdict,
            '_atomic_json':lambda p,d:p.write_text(json.dumps(d),encoding='utf-8')}
        exec(compile(ast.Module(body=fns,type_ignores=[]),'audit-function','exec'),ns)
        previous=torch.arange(40,dtype=torch.float32).view(40,1,1,1).expand(40,8,8,3)/100
        candidate=torch.arange(45,dtype=torch.float32).view(45,1,1,1).expand(45,8,8,3)/100
        old=types.SimpleNamespace(context_frames=3,output_frames=24)
        seg=types.SimpleNamespace(index=1,context_frames=5,output_frames=24)
        with tempfile.TemporaryDirectory() as directory:
            result=ns['_audit_three_mode_segment'](candidate,previous,old,seg,VAE(),'A boat.',None,
                                                   ('local','http://localhost:1234/v1',20),Path(directory)/'evidence.png')
            self.assertEqual(result,([],'pass'))
            inputs=seen['input_images']
            self.assertAlmostEqual(inputs[0][0,28,0,0].item(),51/255,places=6)
            self.assertAlmostEqual(inputs[1][0,28,0,0].item(),66/255,places=6)
            self.assertAlmostEqual(inputs[2][0,28,0,0].item(),12/255,places=6)
            self.assertAlmostEqual(inputs[-1][0,28,0,0].item(),71/255,places=6)
            report=json.loads((Path(directory)/'evidence.json').read_text(encoding="utf-8"))
            self.assertEqual(report['scope'],'visual_continuity_only')


class AppearanceTests(unittest.TestCase):
    def test_wardrobe_failure_is_supported_and_must_be_observable(self):
        report={'pass':False,'frames_checked':6,'issues':[{'kind':'wardrobe_mismatch','frame':5,'evidence':'The opening has a plain coat and white blouse; the final frame has a sailor collar and large red neck ribbon.'}]}
        self.assertFalse(m.parse_verdict(json.dumps(report),6)[0])
        text=m.audit_instruction('A woman turns around.',2,2,(0,.25,2,2.25,3.7,3.9))
        self.assertIn('previously selected opening',text)
        self.assertIn('back or an occluded view',text)
        self.assertIn('major wardrobe',text)
        self.assertIn('minor cosmetic',text)

    def test_opening_appearance_uses_delivered_frames_and_detaches_storage(self):
        source=(ROOT/'minimax_h3_long_video/nodes.py').read_text(encoding="utf-8")
        fn=next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name=='_opening_audit_images')
        ns={'_streams':lambda x:(x,None)}
        exec(compile(ast.Module(body=[fn],type_ignores=[]),'opening-appearance','exec'),ns)
        class VAE:
            def decode(self,value):return value
        video=torch.arange(40,dtype=torch.float32).view(40,1,1,1).expand(40,8,8,3).clone()
        references=ns['_opening_audit_images'](video,types.SimpleNamespace(context_frames=3,output_frames=24),VAE())
        self.assertEqual([x[0,0,0,0].item() for x in references.values()],[3,14])
        video.fill_(999)
        self.assertEqual([x[0,0,0,0].item() for x in references.values()],[3,14])


class FocusedAppearanceExecutionTests(unittest.TestCase):
    def test_chronology_pass_still_checks_clothing_and_maps_last_frame(self):
        source=(ROOT/'minimax_h3_long_video/nodes.py').read_text(encoding="utf-8")
        body=[n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name in ('_audit_three_mode_segment','_labeled_audit_image')]
        for wrong_clothing in (False,True):
            calls=[]
            class VAE:
                def decode(self,value):return value
            class Helper:
                def convert(self,instruction,*args,**kwargs):
                    calls.append(kwargs['input_images'])
                    if instruction.startswith('Compare major clothing only'):
                        issues=[{'kind':'wardrobe_mismatch','frame':0,'evidence':'A different collar and a large red neck ribbon.'}] if wrong_clothing else []
                        return json.dumps({'pass':not wrong_clothing,'frames_checked':1,'issues':issues}),'mock'
                    return '{"pass":true,"frames_checked":6,"issues":[]}','mock'
            ns={'FPS':24,'torch':torch,'math':math,'Image':Image,'ImageDraw':ImageDraw,'json':json,
                '_streams':lambda x:(x,None),'_flatten_image_tensors':lambda x:list(x.values()),
                'comfy_nodes':types.SimpleNamespace(NODE_CLASS_MAPPINGS={'QwenJapanesePromptLMStudio':Helper}),
                'audit_instruction':m.audit_instruction,'appearance_instruction':m.appearance_instruction,'parse_verdict':m.parse_verdict,
                '_atomic_json':lambda p,d:p.write_text(json.dumps(d), encoding="utf-8")}
            exec(compile(ast.Module(body=body,type_ignores=[]),'focused-appearance-execute','exec'),ns)
            video=torch.zeros(30,8,8,3)
            seg=types.SimpleNamespace(index=2,context_frames=5,output_frames=24)
            with tempfile.TemporaryDirectory() as directory:
                result=ns['_audit_three_mode_segment'](video,None,None,seg,VAE(),'A woman turns.',{'opening':video[:1]},
                         ('local','http://localhost:1234/v1',20),Path(directory)/'test.png')
                report=json.loads((Path(directory)/'test.json').read_text(encoding="utf-8"))
            self.assertEqual(len(calls),2)
            self.assertEqual(len(calls[1]),2)
            self.assertEqual(bool(result[0]),wrong_clothing)
            if wrong_clothing:self.assertEqual(report['detail']['issues'][0]['frame'],5)
            else:self.assertEqual(result,([],'pass'))

if __name__=='__main__':unittest.main()
