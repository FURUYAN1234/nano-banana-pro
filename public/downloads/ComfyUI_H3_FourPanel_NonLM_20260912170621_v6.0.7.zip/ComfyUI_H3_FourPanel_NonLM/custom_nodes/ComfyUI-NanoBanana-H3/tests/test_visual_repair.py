"""Visual shot replacement keeps speech, clocks and sound immutable."""
import importlib.util
import json
from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("visual_repair_test", ROOT / "visual_repair.py")
m = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(m)

PROMPT = (
    "subject_definitions:\n"
    "<Subject 7> (S2): a woman with a blue jacket.\n"
    "<Subject 9>: a man with glasses.\n"
    "detailed_description: Preserve the reference identity.\n"
    "PACKED-PASS CLOCK: output begins at 00:01.625.\n"
    "[Shot 1] At 00:01.625, <Subject 7> (S2) completes the utterance by 00:06.125: "
    "<d>[Japanese] せきにん。</d> "
    + m._LOCK_END + " A crowded wide shot shows both subjects near the table.\n\n"
    "overall_soundscape: quiet room tone.\n"
    "non_diegetic_music: a soft instrumental cue.\n"
    "[Global Instructions]\nPreserve the original story and cast.")
ACTION = ("A stable medium shot keeps <Subject 7> at the table with her original blue jacket, "
          "speaking face readable. <Subject 9> remains beside the table, silently watching "
          "with still lips. She retains the original gesture and then relaxes naturally.")


class VisualRepairTests(unittest.TestCase):
    def report(self):
        return "fail 3:" + json.dumps({
            "first": {"pass": False, "frames_checked": 6,
                      "issues": [{"frame": n, "issue": "Two simultaneous copies of Subject 7."}
                                 for n in range(1, 7)],
                      "speaker_check": {"status": "pass", "evidence": [
                          {"observation": "Irrelevant passing evidence " * 200}]}},
            "recheck": {"pass": False, "issues": [],
                        "speaker_check": {"status": "fail", "expected_subject_id": 7,
                                          "expected_speaker_id": "S2", "extra_speaking_subject_ids": [9],
                                          "evidence": [{"subject_id": 9, "frame_indices": [5, 6],
                                                        "observation": "Repeated lip articulation."}]}}})

    def test_long_report_retains_early_identity_defect_and_separate_speaker_evidence(self):
        report = m.compact_visual_feedback(self.report())
        self.assertEqual(report["identity_issues"], ["Two simultaneous copies of Subject 7."])
        self.assertEqual(report["speaker_checks"][0]["extra_speaking_subject_ids"], [9])
        self.assertNotIn("Irrelevant passing evidence", json.dumps(report))

    def test_repair_replaces_staging_without_changing_protected_content(self):
        requests = []
        def request(text):
            requests.append(text)
            return {"reason": "Separate the two existing identities.", "visual_actions": [ACTION]}
        result, record = m.repair_visual_prompt(PROMPT, self.report(), request)
        start, split, stop = m.split_visual_shots(PROMPT)[0]
        self.assertEqual(result[:split], PROMPT[:split])
        self.assertEqual(
            result[result.index("overall_soundscape:"):],
            PROMPT[PROMPT.index("overall_soundscape:", stop):],
        )
        self.assertEqual(re.findall(r"<d>.*?</d>", result), re.findall(r"<d>.*?</d>", PROMPT))
        self.assertEqual(re.findall(r"\b\d{2}:\d{2}\.\d{3}\b", result),
                         re.findall(r"\b\d{2}:\d{2}\.\d{3}\b", PROMPT))
        self.assertNotIn("crowded wide shot", result)
        self.assertNotIn("Two simultaneous copies", result)
        self.assertNotIn("speaker_checks", result)
        self.assertEqual(record["format_attempt"], 1)
        self.assertFalse(record["simplify_framing"])
        self.assertIn("identity_issues", requests[0])

    def test_repeated_failure_focuses_speaker_without_reassigning_actions_or_narration(self):
        requests = []
        def request(text):
            requests.append(text)
            return {"reason": "Use a readable medium shot.", "visual_actions": [ACTION]}
        result, record = m.repair_visual_prompt(PROMPT, self.report(), request, simplify_framing=True)
        self.assertTrue(record["simplify_framing"])
        self.assertIn("exactly one on-screen speaker", requests[0])
        self.assertIn("participant required for the physical story action", requests[0])
        self.assertIn("Never convert narration into an on-screen speaker", requests[0])
        self.assertIn("<Subject 7>", result)
        self.assertNotIn("<Subject 5>", result)

    def test_later_repair_replaces_previous_staging_instead_of_appending_it(self):
        first, _ = m.repair_visual_prompt(PROMPT, self.report(),
            lambda text: {"reason": "First correction.", "visual_actions": [ACTION]})
        next_action = "Both original subjects stay at opposite sides of the table while the same speaker gestures naturally."
        second, _ = m.repair_visual_prompt(first, self.report(),
            lambda text: {"reason": "Second correction.", "visual_actions": [next_action]})
        self.assertNotIn(ACTION, second)
        self.assertNotIn("crowded wide shot", second)
        self.assertIn(next_action, second)
        self.assertEqual(second.count("[Shot 1]"), 1)

    def test_dialogue_timestamps_new_identities_and_sections_are_rejected(self):
        for action in [
            ACTION + " <d>[Japanese] 余計な台詞。</d>",
            ACTION + " At 00:02.000 she turns.",
            ACTION + " <Subject 42> watches.",
            ACTION + "\noverall_soundscape: replace the music.",
            ACTION + " [Shot 2] new shot."]:
            with self.subTest(action=action):
                with self.assertRaises(ValueError):
                    m.replace_visual_actions(PROMPT, [action])

    def test_bad_model_response_has_only_one_format_retry(self):
        calls = []
        def request(text):
            calls.append(text)
            return {"reason": "Bad response.", "visual_actions": [ACTION + " <d>bad</d>"]}
        with self.assertRaises(ValueError):
            m.repair_visual_prompt(PROMPT, self.report(), request)
        self.assertEqual(len(calls), 2)

    def test_speech_free_shot_preserves_sound_and_does_not_add_a_speaker(self):
        prompt = ("subject_definitions:\n<Subject 9>: a man with glasses.\n"
                  "detailed_description:\n[Shot 1] At 00:01.625, He silently sorts papers.\n\n"
                  "overall_soundscape: paper rustle.\nnon_diegetic_music: N/A")
        action = "<Subject 9> sorts the same papers at the desk with stable framing and no voice."
        result = m.replace_visual_actions(prompt, [action])
        self.assertNotIn("<d>", result)
        self.assertNotIn("(S", result)
        self.assertEqual(result[result.index("overall_soundscape:"):],
                         prompt[prompt.index("overall_soundscape:"):])

    def test_malformed_optional_observation_lists_do_not_crash_compaction(self):
        report = m.compact_visual_feedback({"issues": 1, "speaker_check": {
            "status": "not_observable", "expected_subject_id": 7, "evidence": 42}})
        self.assertEqual(report["identity_issues"], [])
        self.assertEqual(report["speaker_checks"][0]["evidence"], [])

    def test_unparseable_feedback_stays_request_data(self):
        result, _ = m.repair_visual_prompt(PROMPT, "Malformed audit report",
            lambda text: {"reason": "Ground the correction in the reference.", "visual_actions": [ACTION]})
        self.assertNotIn("Malformed audit report", result)


if __name__ == "__main__":
    unittest.main()
