# SPDX-License-Identifier: MIT
"""Regression cases for speech fitting. Execute after the requested model switch."""
import importlib.util
import json
from pathlib import Path
import re
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("fourpanel_dialogue_fit_tests", ROOT / "dialogue_fit.py")
fit = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = fit
spec.loader.exec_module(fit)


def prompt_for(readings):
    prefix = ("subject_definitions:\n<Picture 1> is the reference.\n"
              "<Subject 1> (S1) is a woman with short hair.\n"
              "<Subject 2> (S2) is a man wearing glasses.\n"
              "summary:\nA conversation.\nretention_analysis:\nPreserve source identity.\n"
              "detailed_description:\n")
    shots = []
    for i, reading in enumerate(readings):
        sid = i % 2 + 1
        anchor = "[Shot 1]" if i == 0 else f"[Shot {i+1}] At {i*5//60:02d}:{i*5%60:02d}.000,"
        shots.append(f"{anchor}\n<Subject {sid}> (S{sid}) speaks with natural emotion. <d>[Japanese] {reading}</d>")
    return prefix + "\n".join(shots) + (
        "\noverall_soundscape:\nQuiet room.\nnon_diegetic_music:\nSoft instrumental music.\n"
        "[Global Instructions]\nPreserve character identity and music. Keep one turn in each five-second window.")


class ReadingBudgetTests(unittest.TestCase):
    def test_yoon_sokuon_and_long_vowels(self):
        self.assertEqual(fit.estimate_reading("きゃっと")["mora"], 3)
        self.assertEqual(fit.estimate_reading("コーヒー")["mora"], 4)
        self.assertEqual(fit.estimate_reading("ﾁｮｯﾄ")["mora"], 3)

    def test_trailing_punctuation_and_ellipsis_are_pauses(self):
        self.assertGreater(fit.estimate_reading("えっ…ほんと？")["estimated_speech_seconds"],
                           fit.estimate_reading("えっほんと")["estimated_speech_seconds"])

    def test_short_natural_line_has_five_second_window(self):
        row = fit.estimate_reading("それはちがうよ。")
        self.assertTrue(row["valid"])
        self.assertFalse(row["needs_compression"])
        self.assertEqual(row["window_seconds"], 5)

    def test_long_reading_extends_instead_of_clipping(self):
        row = fit.estimate_reading("あ" * 40)
        self.assertEqual(row["window_seconds"], 7)
        self.assertGreaterEqual(row["window_seconds"], row["estimated_speech_seconds"] + 1)

    def test_kanji_numbers_and_latin_are_not_miscounted_as_one_mora(self):
        for line in ["明日は晴れ", "123", "AIです", ""]:
            with self.subTest(line=line):
                self.assertFalse(fit.estimate_reading(line)["valid"])
                self.assertIsNone(fit.estimate_reading(line)["window_seconds"])

    def test_extreme_line_remains_invalid_not_capped_and_passed(self):
        row = fit.estimate_reading("あ" * 150)
        self.assertFalse(row["valid"])
        self.assertGreater(row["window_seconds"], 15)

    def test_only_punctuation_is_silent(self):
        self.assertFalse(fit.has_speech("……！"))
        self.assertTrue(fit.has_speech("ああ！"))


class CompressionTests(unittest.TestCase):
    def test_short_lines_do_not_call_provider(self):
        rows = fit.suggest_dialogues(["そうだね。"], ["そうだね。"],
                                     lambda *a: self.fail("unnecessary provider call"), fit.HYBRID)
        self.assertEqual(rows[0]["text"], "そうだね。")

    def test_verbatim_mode_does_not_compress_long_source(self):
        source = "元の長い台詞"
        rows = fit.suggest_dialogues([source], ["あ" * 40],
                                     lambda *a: self.fail("verbatim was compressed"), fit.VERBATIM)
        self.assertEqual(rows[0]["text"], source)
        self.assertEqual(fit.estimate_reading(rows[0]["reading"])["window_seconds"], 7)

    def test_only_long_row_changes_with_context_retained(self):
        requests = []
        def request(system, text):
            body = json.loads(text); requests.append(body)
            self.assertEqual(body["requested_ids"], [1])
            self.assertEqual(body["context"][0]["source"], "そう？")
            return {"dialogues": [{"id": 1, "text": "絶対に違うよ！", "reading": "ぜったいにちがうよ！", "note": "説明の重複だけ削減"}]}
        rows = fit.suggest_dialogues(["そう？", "長い否定の台詞"], ["そう？", "あ" * 40], request, fit.HYBRID)
        self.assertEqual(len(requests), 1)
        self.assertEqual(rows[0]["text"], "そう？")
        self.assertEqual(rows[1]["reading"], "ぜったいにちがうよ！")

    def test_malformed_or_duplicate_rows_do_not_drop_turns(self):
        for response in [None, {"dialogues": []},
                         {"dialogues": [{"id": 1, "text": "はい", "reading": "はい"}]},
                         {"dialogues": [{"id": 0}, {"id": 0}]}]:
            rows = fit.suggest_dialogues(["原文"], ["あ" * 40], lambda *a: response, fit.HYBRID)
            self.assertEqual(rows[0]["text"], "原文")
            self.assertEqual(rows[0]["reading"], "あ" * 40)

    def test_invented_tags_and_unknown_reading_are_rejected(self):
        for text, reading in [("<d>はい</d>", "はい"), ("AI", "AI")]:
            response = {"dialogues": [{"id": 0, "text": text, "reading": reading}]}
            rows = fit.suggest_dialogues(["原文"], ["あ" * 40], lambda *a: response, fit.HYBRID)
            self.assertEqual(rows[0]["text"], "原文")

    def test_retry_budget_and_remaining_long_line_use_extension(self):
        calls = []
        def request(*args):
            calls.append(1)
            return {"dialogues": [{"id": 0, "text": "残すべき内容", "reading": "あ" * (50-len(calls))}]}
        rows = fit.suggest_dialogues(["原文"], ["あ" * 60], request, fit.HYBRID)
        self.assertEqual(len(calls), 2)
        self.assertGreater(fit.estimate_reading(rows[0]["reading"])["window_seconds"], 5)


class RetimeTests(unittest.TestCase):
    def test_long_first_turn_shifts_later_windows_without_rewriting_words(self):
        readings = ["あ" * 40, "そう？", "ちがうよ！"]
        source = prompt_for(readings)
        result, timing = fit.retime_confirmed_prompt(source, readings)
        self.assertIn("[Shot 2] At 00:07.000", result)
        self.assertIn("[Shot 3] At 00:12.000", result)
        self.assertEqual(timing["total_frames"], 17 * 24)
        self.assertEqual([r["output_frames"] for r in timing["turns"]], [168, 120, 120])
        self.assertEqual(fit.TAG.findall(result), readings)
        self.assertEqual(re.findall(r"\(S\d+\)", source), re.findall(r"\(S\d+\)", result))
        self.assertIn("Preserve character identity and music.", result)

    def test_wrong_turn_count_and_duplicate_window_fail_before_sampling(self):
        with self.assertRaises(ValueError):
            fit.retime_confirmed_prompt(prompt_for(["はい", "いいえ"]), ["はい"])
        bad = prompt_for(["はい", "いいえ"]).replace("00:05.000", "00:00.000")
        with self.assertRaises(ValueError):
            fit.retime_confirmed_prompt(bad, ["はい", "いいえ"])

    def test_delayed_speech_is_not_treated_as_a_full_available_window(self):
        readings = ["はい", "いいえ"]
        late = prompt_for(readings).replace("00:05.000", "00:08.000")
        with self.assertRaises(ValueError):
            fit.retime_confirmed_prompt(late, readings)

    def test_no_speech_returns_empty_timing_for_fallback(self):
        source = "detailed_description:\n[Shot 1] A silent reaction."
        result, timing = fit.retime_confirmed_prompt(source, [])
        self.assertEqual(result, source)
        self.assertEqual(timing["turns"], [])
        self.assertEqual(timing["total_frames"], 0)


if __name__ == "__main__":
    unittest.main()
