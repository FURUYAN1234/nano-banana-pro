# Four-panel v6.0.7 validation

The functionally identical v5.9.8 candidate completed a fresh GPU/API run on 2026-09-12 JST. It used the saved non-LM four-panel workflow with Fused4, SLA 0.90, 864x480, 24fps, two audio-refinement steps at 0.5, H3-generated instrumental BGM and `軽く要約＋必要な台詞だけ延長` dialogue review. The confirmed windows were 5, 7, 5, 5, 7, 5 and 5 seconds, totaling 39 seconds.

Selected candidate attempts were 2, 1, 2, 3, 3, 3 and 1. Every selected segment passed the combined acoustic and visual audit. All seven selected acoustic verbatim transcripts exactly matched the confirmed readings, including the endings of both seven-second lines. Segments 4, 5 and 6 reached the simpler-framing repair after two visual failures; the retry records preserved exact tagged dialogue and omitted raw audit text. The prior v5.9.7 run's exhausted or accepted-failure state was not reused or reset.

The final file was saved under `ComfyUI/output/video/MiniMax_H3/`, with SHA256 `9fcd7dda5f2ae30f87b2eec51e72182f43484928ea30dbfa36d7372ec4c44554`. FFmpeg measured 39.00 seconds, 864x480, constant 24fps, 936 frames, H.264 High yuv420p and AAC stereo at 32kHz. A 42-frame contact sheet showed no obvious duplicate main body or clear hairstyle mismatch; title and end credit remained inside the frame. This was sampled visual inspection, not exhaustive frame-by-frame review. The user listened to the completed audio and reported it was OK.

Before the supplied candidate build, Python syntax passed, NanoBanana-H3's complete local suite passed 74 tests, and MiniMax-H3-Long-Video's complete local suite passed 107 tests. The v6.0.7 publication changes only public version labels, filenames and release metadata. Its final source, deterministic rebuild and extracted-package checks are recorded in the adjacent v6.0.7 release-check record.

No model, API key, personal pronunciation dictionary, input image or validation media is distributed. Another-PC ComfyUI execution, the missing-model UI and a fresh GPU run from the final v6.0.7 ZIP remain unverified.
