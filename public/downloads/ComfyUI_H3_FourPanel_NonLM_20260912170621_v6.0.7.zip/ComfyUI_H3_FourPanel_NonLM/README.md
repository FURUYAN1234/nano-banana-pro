# MiniMax H3 Four-panel non-LM Studio release v6.0.7

This release contains one workflow: `FourPanel_NonLM_4step_20260912170621_v6.0.7.json`. It uses the selected cloud API for image transformation, H3 prompt authoring and auditing; LM Studio is not required.

Copy all five folders from `custom_nodes/` into ComfyUI's `custom_nodes/`:
- ComfyUI-NanoBanana-H3
- ComfyUI-MiniMax-H3-Long-Video
- ComfyUI-Spectrum-MiniMax-H3 (included for compatibility; not connected in the Fused4 workflow)
- ComfyUI-H3-AudioRefine (bundled runtime dependency)
- ComfyUI-PlagueKind-Nodes (bundled SLA dependency)

All five are included; do not separately download and patch them. Install requirements using ComfyUI's Python. Use a CUDA/H3-compatible ComfyUI and OS/PyTorch-compatible Triton (triton-windows on Windows), FFmpeg on PATH and a Japanese font. Download the four models listed in models.json into their specified models directories.

Run verify_package.py after extraction. Load the workflow, supply your own four-panel image, register the selected API key in the node and confirm dialogue readings. API keys remain only in process memory and must be re-entered after restart. No model weights, user images/videos, credentials or personal pronunciation dictionary are included.

The optional local Whisper helper is disabled in the portable package. To use it, set `enabled` to `true` in `custom_nodes/ComfyUI-MiniMax-H3-Long-Video/minimax_h3_long_video/local_audio_audit.json` and provide a local model folder through `model_path` or `H3_LOCAL_WHISPER_MODEL`. It never downloads a model automatically. The normal external-API segment acoustic audit is separate from this optional helper.

Video: Fused4 + SLA, 4 steps, 24fps, 16:9. Audio: 2 refinement steps at 0.5, with original/refined candidate comparison. Dialogue review lightly shortens text only when meaning and endings remain intact, then extends only lines that need more than the five-second base window, up to 15 seconds. The fallback without dialogue is 30 seconds. H3 generates quiet instrumental BGM. Completed files are saved in ComfyUI/output/video/MiniMax_H3; checkpoints are in output/h3_long_video.

Quality checks compare at most five candidates, including the initial attempt. An earlier passing candidate proceeds immediately; if all five fail, the best inspected candidate is retained and generation continues. Protected dialogue is never rewritten by prose translation. Interruptions and unavailable required inputs are not reported as successful generation.

Version 6.0.7 routes visual failures through structured shot replacement even when audio and visual checks fail together. After two visual failures in one segment it requests simpler speaker-readable framing while preserving exact confirmed dialogue, timing, identities, sound and H3-generated music; raw audit JSON is never inserted into the H3 prompt. The functionally identical v5.9.8 candidate completed a 39-second GPU/API run at 864x480, 24fps and 936 frames. All seven selected segments passed combined audio and visual audits, every selected acoustic transcript matched the confirmed line through its ending, and a 42-frame visual sample showed no obvious duplicate main body or clear hairstyle mismatch. The user listened to the finished audio and accepted it. The v6.0.7 publication changes version labels and public metadata only. Another-PC execution and a fresh GPU run from the final v6.0.7 ZIP remain unverified.

See [the version correction and apology](VERSION_CORRECTION_JA.md). This four-panel product advances from 5.9.7 to 6.0.7 to follow the current Nano Banana release line and remains separate from the T2V/I2V/Ref2V service. See VALIDATION.md for evidence and limits.
