# MiniMax H3 四コマ・非LM Studio版 v6.0.7

配布ワークフローは **FourPanel_NonLM_4step_20260912170621_v6.0.7.json の1本**です。以前のT2V・I2V・Ref2Vサンプルは本ZIPの対象ではありません。既存公開履歴と旧版テスト・ソースは対応Gitソースのlegacy_v1_1_5に保持しています。

## 同梱内容と導入
`custom_nodes/`内の5フォルダーをComfyUIの`custom_nodes/`へコピーします。
主要3パッケージは NanoBanana-H3、MiniMax-H3-Long-Video、Spectrum-MiniMax-H3。
実行依存の ComfyUI-H3-AudioRefine と ComfyUI-PlagueKind-Nodes も **同梱済み** です。別途取得してパッチを適用する手順はありません。
Spectrumは互換用に同梱しますが、配布ワークフローの4ステップFused＋SLA経路には接続していません。
同名フォルダーの二重導入を避け、更新前の既存フォルダーは退避してください。

1. ZIPを展開し、`python verify_package.py` で同梱内容と全件ハッシュを検査します。
2. 上記5フォルダーを配置し、**ComfyUI自身のPython**で `-m pip install -r 展開先/requirements.txt` を実行します。Windows Portableなら `python_embeded/python.exe`、venvなら `.venv/bin/python` を使います。PyTorchは既存のCUDA対応版を維持してください。
3. H3・ResolutionSelector・ComfyMathExpression・V3ノードAPI対応のComfyUIが必要です。NVIDIA CUDAと、OS/PyTorchに適合するTritonを準備します。Linux/WSLは対応するtriton、Windowsは [triton-windowsの互換表](https://github.com/woct0rdho/triton-windows) に従います。PlagueKindは同梱されていますがTriton本体は同梱していません。
4. FFmpegをPATHから利用可能にします。日本語タイトル・クレジットにはMeiryo/Yu Gothic、またはNoto CJK等の日本語フォントが必要です。
5. 以下の4モデルを取得し、ComfyUIのmodels配下へ配置します。各ローダーのproperties.modelsにも同じ取得先を登録しています。不足モデル画面から取得候補を開けますが、他PCでのその画面操作は未検証です。
6. ComfyUIを再起動し、workflows内のJSONを読み込みます。読み込んだワークフローは既存の動画→MiniMax-H3→四コマの分類配下へ保存してください。
7. 自分の四コマ画像をLoadImageへアップロードします。入力画像は同梱していません。
8. Nano BananaノードでOpenAI APIまたはGoogle Gemini APIを選び、APIキーを登録します。画像変換・文章生成・検査で外部APIを使用します。**LM Studioの起動やローカルLLMモデルは不要**です。
9. キーはComfyUIプロセスのメモリだけに保持し、ZIPやワークフローへ保存しません。再起動後は再登録してください。
10. 実行後に表示される台詞の読みと秒数を確認・確定します。既定の「軽く要約＋必要な台詞だけ延長」は、意味と語尾を保てる範囲で整え、5秒に収まらない台詞だけ最大15秒まで延長します。個人の発音辞書は同梱せず、受領PCで設定します。
11. 完成動画は `ComfyUI/output/video/MiniMax_H3/`、中間区間・検査結果は `ComfyUI/output/h3_long_video/` に保存されます。

任意のローカルWhisper補助検査は配布時には無効です。使う場合は `custom_nodes/ComfyUI-MiniMax-H3-Long-Video/minimax_h3_long_video/local_audio_audit.json` の `enabled` を `true` にし、ローカルモデルのフォルダーを `model_path` または環境変数 `H3_LOCAL_WHISPER_MODEL` で指定します。モデルは自動取得されず、本ZIPにも含みません。通常の外部APIによる区間音響監査はこの設定とは別に動作します。

## モデル取得先
- [minimax_h3_fused_refdelta_r1024_turbo8_mystic07_int8_convrot.safetensors](https://huggingface.co/MATLOWAI/minimax-h3-fused-turbo-int8-convrot/resolve/main/diffusion_models/minimax_h3_fused_refdelta_r1024_turbo8_mystic07_int8_convrot.safetensors) → models/diffusion_models/
- [qwen3vl_32b_minimax_h3_nvfp4_awq.safetensors](https://huggingface.co/Comfy-Org/MiniMax-H3/resolve/main/text_encoders/qwen3vl_32b_minimax_h3_nvfp4_awq.safetensors) → models/text_encoders/
- [minimax_h3_video_vae_int8_convrot.safetensors](https://huggingface.co/Kijai/MiniMax-H3-experimental/resolve/main/minimax_h3_video_vae_int8_convrot.safetensors) → models/vae/
- [minimax_h3_audio_vae_fp32.safetensors](https://huggingface.co/Comfy-Org/MiniMax-H3/resolve/main/vae/minimax_h3_audio_vae_fp32.safetensors) → models/vae/
モデル本体・入力画像・完成動画・APIキー・個人辞書はZIPに含みません。モデルの利用条件は各配布元を確認してください。

## 実際の生成設定
- 映像：Fusedモデル、res_multistep、simple **4ステップ**、SLA 0.90、音声保護ON。
- 音声：同じFusedモデルのSLA適用前経路で **2ステップ・強さ0.5**。検査で追加処理前の音声が良い場合はそちらを採用します。
- 画面：16:9、ResolutionSelector 0.4（検証時864×480）、24fps。
- 尺：台詞1本あたり基本5秒。意味と語尾を保った軽い要約で収まらない台詞だけ、必要秒数へ延長（最大15秒）します。台詞がなければ30秒。句読点だけの無言反応は発話数へ含めません。
- BGM：H3が生成する低音量のインストゥルメンタル。外部BGMファイルは不要です。
- 画像変換：Nano Bananaの画像変換指示は、四コマを単一場面へ変換し、吹き出しと印刷文字を除去するためのものです。変換した1枚をH3へ渡し、元のコマ割り画像をH3参照へ直接渡しません。
- H3文章生成：画像変換とは別のH3動画文章生成指示で、映像ショット・話者・台詞時刻・環境音・H3生成BGMを作ります。台詞確認ノードで確定した文章と秒数が最終優先でサンプラーへ接続されます。
- 台詞を保護して説明文を英語へ整形します。変換が不完全でも使える入力を捨てず続行します。
- 区間の品質不合格は最大5候補（初回込み）を比較し、検査結果上の最良候補を採用して続行します。ユーザーの中断、未登録API、モデル欠落等まで成功扱いにはしません。
- 正常な母音伸長や自然な息継ぎを一律に二重発声と扱いません。人物重複・明らかな外見変更・台詞破綻は品質検査対象です。

## 今回の修正と検証（6.0.7）
台詞確認に「軽く要約＋必要な台詞だけ延長」を追加し、短い台詞は5秒、長い台詞だけ7秒など必要な長さへ延長します。音声と映像が同時に不合格になった場合も、映像の人物重複・髪型・話者口形を構造化してNano Banana修正へ渡します。同一区間で映像不合格が2回続くと話者中心の単純構図へ切り替えます。再生成時も確定済み台詞、時刻、環境音、BGMを保持し、監査JSONはH3プロンプトへ入れません。

2026-09-12に、機能が同一のv5.9.8受領候補で39秒、864×480、24fps、936フレームのGPU/API生成が完走しました。7区間すべての選定候補が音声・映像監査に合格し、7台詞の音響監査は期待文と語尾まで完全一致しました。42枚の抜き出し画像で人物分身・明らかな髪型不一致は確認されず、タイトルと終了クレジットも画面内でした。利用者が完成音声を確認してOKと判定しています。v6.0.7への変更は公開版番号、ファイル名、公開用メタデータだけで、生成処理と設定は変更していません。別PC実行と最終v6.0.7 ZIPからの新規GPU生成は未検証です。
詳細は[VALIDATION.md](VALIDATION.md)、再構築手順は[REPRODUCE.md](REPRODUCE.md)を参照してください。

## 版番号の訂正
[お詫び・訂正案内](VERSION_CORRECTION_JA.md)を同梱しています。現行Nano Banana v6.0.6の次版として、四コマ配布版をv6.0.7へ統一しました。T2V・I2V・Ref2Vは別サービスであり、その版番号や内容は変更しません。
