# MiniMax-H3 四コマ15秒・Fused Turbo＋Spectrum＋SLA 高速版

配布日: 2026-09-03  
配布内容: 実行確認済みワークフロー、必須カスタムノード4点、モデル取得先、導入手順

## 結論

Nano Banana用にノードを別の種類へ差し替える必要はありません。ワークフロー内の `NanoBananaH3Transform` が、次を1ノードで行います。

- 四コマ画像を、文字・吹き出し・コマ枠のない単一の16:9シーンへ変換
- MiniMax-H3用英語プロンプトを生成
- 元漫画のタイトルを抽出して、生成後のタイトル合成へ渡す
- Google Gemini APIまたはOpenAI APIを選択可能

ただし、このノードはComfyUI標準ではないため、同梱の `ComfyUI-NanoBanana-H3` を `custom_nodes` へ導入してください。

## 内容物

- `01_ワークフロー/`：配布用・検証済JSON
- `02_カスタムノード/`：必要な4パックを個別ZIPで収録
- `03_モデル直リンク/モデル一覧とSHA256.txt`：Downloadが出ない場合の手動取得先
- `04_動作確認/検証結果.txt`：速度と実行確認結果

## インストール

1. 4つのZIPをそれぞれ展開します。
2. 展開された最上位フォルダをすべて `ComfyUI/custom_nodes/` へコピーします。
3. ComfyUIを完全に再起動します。
4. `01_ワークフロー` のJSONをComfyUIへドラッグ＆ドロップします。
5. 不足モデルのDownloadを実行します。Downloadが表示されなければ `03_モデル直リンク` のURLを使います。
6. `SELECT_YOUR_4KOMA_MANGA.png` を自分の四コマ画像へ差し替えます。
7. Nano Bananaノードのボタンから自分のAPIキーを登録して実行します。

## カスタムノードの配布元

- Spectrum: https://github.com/xmarre/ComfyUI-Spectrum-MiniMax-H3
- SLA Attention: https://github.com/PlagueKind/ComfyUI-PlagueKind-Nodes
- Fast VAE Decode: https://github.com/Mozer/ComfyUI-MiniMax-H3-MotionCache-FastVAE
- Nano Banana統合ノード: 本配布物に同梱

同梱ZIPは検証時の状態を固定したものです。新しい版を使う場合は各配布元から取得してください。

## APIキーの安全性

APIキーはワークフローJSONおよびZIPへ含めていません。利用者がノードUIから登録したキーは、各自のPC内の `ComfyUI/user/nanobanana_h3_credentials.json` に暗号化なしで保存されます。配布、画面共有、バックアップ時にこのファイルを含めないでください。

## 確認済み設定

- 15秒 / 16:9 / 0.4MP / 24fps
- Fused Turbo INT8 ConvRot
- Spectrum degree 1
- SLA 0.90 / block 64 / audio protection有効
- RES Multistep / Simple / 8 steps
- RTX 5080 16GBで生成成功

旧Hybrid＋Turbo LoRA版との5秒A/Bでは、全体97.2秒→80.2秒、拡散39秒→27秒でした。初回実行はモデル読み込み時間を含むため、連続実行より長くなります。
