配布版変更（2026-09-07）

修正後に20秒動画を再生成し、4区間初回合格・リトライ0回。再生成動画は利用者の視聴でも問題なし確認。
音声の文字起こしが失敗判定でも独立波形検査へ進み、同一語の終端伸ばし・句読点差の誤検出を軽減。人物複製、明白な髪型違い、台詞破綻、二重発声は検査対象。最大3試行と検査警告後の候補保存を維持。
配布コピーでは画像名、個人URL、固有クレジット、メタデータを除外。APIキー保存方式は変更なし。生成・再生ノードを追加していません。元環境は変更していません。
匿名化したソース（既定クレジット・拡張識別子・本人指定の著作者名のみ。第三者ライセンス保持）:
custom_nodes/ComfyUI-NanoBanana-H3/LICENSE
custom_nodes/ComfyUI-NanoBanana-H3/__init__.py
custom_nodes/ComfyUI-NanoBanana-H3/web/nanobanana_h3.js
custom_nodes/ComfyUI-NanoBanana-H3/web/timestamped_save_video_preview.js
custom_nodes/ComfyUI-MiniMax-H3-Long-Video/web/timestamped_save_video_preview.js
