# 四コマ → 自動可変尺動画（Fused4＋SLA・外部API版）

非LM Studio版1本と、修正済みNanoBanana-H3／MiniMax-H3-Long-Video／Spectrum-MiniMax-H3の3パッケージです。「非LLM」はローカルLLM不要という意味です。外部APIによる画像変換・文章生成・品質検査は使用し、別途料金が発生します。入力画像・指示文・検査する映像/音声は選択したAPI提供元へ送信されます。権利・機密性を確認した素材を使用してください。

## 確認済み仕様

- 最終台詞1本につき5秒。台詞なしは既定30秒。固定の台詞数上限はありませんが、処理時間・メモリ・ディスク容量の制約があります。
- 初期出力864×480、24fps。映像4step（res_multistep/simple）、音声再精錬2step・denoise 0.5。SLA sparsity 0.9、block 64、音声保護有効。Spectrumは同梱しますが今回のグラフには接続していません。
- H3動画文章の最終優先指示は、台詞を優先した小音量インストBGMあり・区間間の継続・最後の短い終止です。画像変換用文章内の「BGMなし」はH3動画の実行設定ではありません。動画用と画像用の2つの指示欄を区別してください。
- 音声/映像の区間検査を維持し、不合格時は原因別の指示で最大3回生成（初回＋再試行2回）。検査器の不調や上限到達は警告付き候補保存へ進みます。生成不能・認証失敗・ユーザー中断まで無視する仕組みではありません。
- 長い母音・自然な短い息継ぎ・句読点など軽微な差は許容。人物複製、明らかな髪型違い、台詞破綻、二重発声は検査対象。ただし自動検査は品質保証ではなく、保存された候補は利用者が再生確認してください。

## 1. ComfyUIと依存物

[ComfyUI公式導入手順](https://docs.comfy.org/installation/manual_install)に従い、NVIDIA GPUが使えるPython/PyTorch環境を構築してください。[ComfyUIソース](https://github.com/Comfy-Org/ComfyUI)。既存環境へ上書きする前にバックアップしてください。

検証環境はWindows＋WSL2 Linux、RTX 5080・VRAM約16GB、RAM 96GBです。RAM容量は最低要件ではありません。ComfyUI commit `3216c62e9962c3babd28a4dfea6e5aef50b8fe16`、PyTorch `2.13.0+cu130`、Triton `3.7.1`、comfy-kitchen `0.2.31`、frontend `1.51.9`。使用Pythonに対応するPyTorch/CUDAを公式手順で選び、ComfyUIのrequirementsを同じPythonへ導入してください。新しい標準のResolutionSelectorとComfyMathExpressionも必要です。古いComfyUIでは不足する場合があります。

ZIPのcustom_nodes内の3フォルダーを、ComfyUI/custom_nodes/直下へ配置します。同名旧版はComfyUIの外へ退避し、二重読み込みしないでください。同梱ソースには今回の修正があるため、公開版へ無条件で置き換えると同じ動作にはなりません。

追加必須：[ComfyUI-PlagueKind-Nodes](https://github.com/PlagueKind/ComfyUI-PlagueKind-Nodes)（H3SLAAttention）。基準commit `6ca3037bd16dc143b6d461c67c87a28ca8074063`。同リポジトリREADMEに従い依存物を導入してください。SLAはTritonを使うため、ノードが表示されるだけでなく対応GPU/PyTorch/Tritonで実行できる必要があります。Windowsネイティブ版のTriton設定と他PCの実操作は未検証です。再現基準はWSL2/Linuxです。

FFmpegをPATHで利用可能にしてください（Ubuntuの例：`sudo apt install ffmpeg`）。Python依存はComfyUIを起動する環境に導入します：`python -m pip install requests numpy pillow aiohttp`。torchおよびComfyUI本体の依存物も必要です。最後にComfyUIを再起動します。

## 2. モデルを取得

各モデルローダーのproperties.modelsにファイル名・directory・ダウンロードURLを登録済みです。ワークフロー内メモとMODEL_DOWNLOADS.jsonにも同じリンクがあります。不足モデル画面から候補を開けない場合は直接リンクから取得してください。モデルの利用条件は各配布元で確認してください。

| 保存先（ComfyUI配下） | モデル |
|---|---|
| models/diffusion_models | [Fused INT8 ConvRot](https://huggingface.co/MATLOWAI/minimax-h3-fused-turbo-int8-convrot/resolve/main/diffusion_models/minimax_h3_fused_refdelta_r1024_turbo8_mystic07_int8_convrot.safetensors) |
| models/text_encoders | [Qwen3VL 32B NVFP4 AWQ](https://huggingface.co/Comfy-Org/MiniMax-H3/resolve/main/text_encoders/qwen3vl_32b_minimax_h3_nvfp4_awq.safetensors) |
| models/vae | [映像VAE INT8 ConvRot](https://huggingface.co/Kijai/MiniMax-H3-experimental/resolve/main/minimax_h3_video_vae_int8_convrot.safetensors) |
| models/vae | [音声VAE FP32](https://huggingface.co/Comfy-Org/MiniMax-H3/resolve/main/vae/minimax_h3_audio_vae_fp32.safetensors) |

ファイル名を変更しないでください。Fusedファイル名のturbo8と実行ステップ数は別で、今回は映像4stepです。Qwen3VLはH3のエンコーダーであり、LM Studioへ入れるチャットモデルではありません。LM Studio・GGUFモデルは不要です。モデル本体・入力画像は同梱しません。

## 3. APIキー・読み確認・実行

1. ComfyUIを起動し、workflows/FourPanel_Fused4_SLA_API.jsonを画面へ読み込みます。不足モデル・不足ノードを解消します。
2. 画像ノードへ自分の四コマ画像を設定します。画像変換用とH3動画文章用の指示欄を必要に応じて編集します。初期設定は全台詞を保持し、1台詞5秒です。
3. NanoBananaH3TransformのProviderは検証済みのOpenAI APIが初期値です。実行時に表示されるキー入力画面で、自分のAPIキーを入力します。[APIキー管理](https://platform.openai.com/api-keys)。ChatGPTの契約とは別のAPI課金・モデル利用権限が必要です。
4. 使用ソースのAPIモデルは画像変換gpt-image-2、文章生成/判定gpt-4.1系、映像判定gpt-5.4、文字起こしwhisper-1、波形検査gpt-audio-1.5です。モデルの提供・利用権限はAPI側に依存します。Google Geminiもコードに選択肢がありますが、今回の再生成はOpenAI経路のみ検証しています。
5. キーは既存方式のままプロセスメモリに保持します。ワークフローJSONやZIPには保存しません。ComfyUI再起動後は再入力が必要です。キーを文章欄へ貼らないでください。
6. H3生成前に「原文／発音用台詞」の確認画面が表示されます。読みだけを直して続行します。個人の発音辞書は各PCのuser/default/nanobanana_h3/pronunciation_dictionary.jsonへ保存されますが、配布には含めていません。
7. 完成MP4はoutput/video/MiniMax_H3/FourPanel_Fused4_年月日時分秒.mp4。最終保存ノード内の再生・シークを使用できます。再生用の新規ノードは追加していません。途中ファイルはoutput/h3_long_video/FourPanel_Fused4/です。

## 検証範囲と配布内容

修正を適用した環境で20秒を再生成し、4区間すべて初回合格、リトライ0回、MP4保存成功。全体約15分59秒（前処理・読み確認待ち・生成・検査・保存込み、キャッシュなしの1回）。H.264/AAC、864×480、24fps、480フレーム、全デコードエラーなし。利用者も修正後動画を再生して「問題なし」と確認しました。

配布コピーについてはノード/接続、指示本文、4step/音声2step、区間検査、モデルURL、匿名化、構文、ZIP整合性、展開後のハッシュを検査します。別PCの新規インストールと不足モデル画面での実クリックは未検証で、誰のPCでも成功する保証はありません。

個人情報・個人URL・APIキー・個人辞書・入力画像・検証動画・モデル・ログは同梱しません。一般の製品名、モデル名、導入元URL、第三者のライセンス表示は必要なため保持しています。同梱LICENSE/COPYRIGHTを尊重してください。SHA256.jsonは収録ファイルの整合性確認用です。
