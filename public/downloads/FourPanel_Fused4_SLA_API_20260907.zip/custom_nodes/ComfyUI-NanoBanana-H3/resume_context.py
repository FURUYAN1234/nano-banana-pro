"""Restore explicitly checkpointed preprocessing only for a matching resume run."""
import hashlib,json
from pathlib import Path
import numpy as np
import torch
from PIL import Image

def signature(image, provider, temperature, seed, image_transform_prompt, h3_prompt_instruction):
    digest=hashlib.sha256()
    array=image.detach().to(device="cpu",dtype=torch.float32).contiguous().numpy()
    digest.update(str(array.shape).encode());digest.update(array.tobytes())
    digest.update(json.dumps([provider,float(temperature),int(seed),image_transform_prompt,h3_prompt_instruction],ensure_ascii=False,separators=(",",":")).encode())
    return digest.hexdigest()

def restore(graph, unique_id, output_root, image, provider, temperature, seed, image_transform_prompt, h3_prompt_instruction):
    if not isinstance(graph,dict):return None
    candidates=[]
    for node in graph.values():
        ins=node.get("inputs",{})
        if node.get("class_type")!="MiniMaxH3LongReferenceSampler" or ins.get("resume") is not True:continue
        if ins.get("ref_images.ref_image_0")!=[str(unique_id),0]:continue
        name=ins.get("cache_name")
        if not isinstance(name,str) or "%" in name:continue
        base=Path(output_root).resolve();project=(base/name).resolve()
        if not project.is_relative_to(base):raise ValueError("Resume project outside output")
        context=project/"recovery_inputs"/"context.json"
        if context.exists():candidates.append(context)
    if not candidates:return None
    if len(set(candidates))!=1:raise ValueError("Ambiguous preprocessing resume context")
    context=candidates[0];data=json.loads(context.read_text(encoding="utf-8"))
    actual=signature(image,provider,temperature,seed,image_transform_prompt,h3_prompt_instruction)
    if data.get("signature")!=actual:raise ValueError("Resume source or preprocessing settings changed; preserved segments cannot be reused")
    reference=context.parent/"reference.png"
    if hashlib.sha256(reference.read_bytes()).hexdigest()!=data["reference_sha256"]:raise ValueError("Resume reference changed")
    arr=np.asarray(Image.open(reference).convert("RGB"),dtype=np.float32)/255.0
    return torch.from_numpy(arr.copy()).unsqueeze(0),data["h3_prompt"],data["overlay_title"]
