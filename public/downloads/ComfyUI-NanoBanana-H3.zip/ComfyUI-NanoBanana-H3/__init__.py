"""Local Nano Banana image-edit node for MiniMax-H3 workflows.

Credentials are stored outside workflows.  The frontend registers a credential
through a password dialog and this node looks it up by provider and slot.
"""

from __future__ import annotations

import base64
import asyncio
import io
import json
import os
import re
import tempfile
import time
from pathlib import Path

import numpy as np
import requests
import torch
from aiohttp import web
from PIL import Image, ImageDraw, ImageFont

import folder_paths
from server import PromptServer


NODE_CLASS_MAPPINGS = {}
NODE_DISPLAY_NAME_MAPPINGS = {}
WEB_DIRECTORY = "./web"

_SLOT_RE = re.compile(r"^[A-Za-z0-9_-]{1,32}$")
_PROVIDERS = ("OpenAI API", "Google Gemini API")
_UNIFIED_SLOT = "workflow_api"
_MODELS = {
    "Nano Banana 2 (Gemini 3.1 Flash Image)": "gemini-3.1-flash-image",
    "Nano Banana Pro (Gemini 3 Pro Image)": "gemini-3-pro-image",
}
_H3_PROMPT_INSTRUCTION = """You write production-ready MiniMax H3 Reference-to-Video prompts.
Return only these six English sections in this exact order: subject_definitions, summary,
retention_analysis, detailed_description, overall_soundscape, non_diegetic_music.
The transformed image is <Picture 1>. Preserve its main subject, visual identity, composition,
and art style. Convert the user's transformation instruction into natural, restrained motion
for a 5-second video. Do not use markdown fences. Do not invent dialogue or visible text unless
the user explicitly asks for it."""

_H3_LLM_SYSTEM = (Path(__file__).with_name("h3_prompt_system.txt")
                  .read_text(encoding="utf-8").strip())


def _credential_path() -> Path:
    return Path(folder_paths.get_user_directory()) / "nanobanana_h3_credentials.json"


def _read_credentials() -> dict:
    path = _credential_path()
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"Nano Banana credential store cannot be read: {exc}") from exc


def _write_credentials(data: dict) -> None:
    path = _credential_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary_name = tempfile.mkstemp(prefix=".nanobanana_", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as temporary:
            os.chmod(temporary_name, 0o600)
            json.dump(data, temporary, ensure_ascii=False)
        os.replace(temporary_name, path)
        os.chmod(path, 0o600)
    finally:
        if os.path.exists(temporary_name):
            os.unlink(temporary_name)


def _sanitize_api_key(provider: str, raw_key: str) -> str:
    """Extract a pasted API token and reject prose/non-ASCII header values."""
    text = str(raw_key or "").strip()
    pattern = r"sk-[A-Za-z0-9_-]{20,}" if provider == "OpenAI API" else r"AIza[A-Za-z0-9_-]{20,}"
    match = re.search(pattern, text)
    if match:
        return match.group(0)
    if not text or any(ord(char) > 127 for char in text) or re.search(r"\s", text):
        raise RuntimeError("APIキー以外の文字が含まれています。キー本体だけを貼り付けてください。")
    if len(text) < 20:
        raise RuntimeError("APIキーが短すぎます。キー本体を確認してください。")
    return text


def _credential(provider: str, slot: str = _UNIFIED_SLOT) -> str:
    values = _read_credentials()
    key = values.get(slot, {}).get(provider, "")
    # Reuse credentials saved by the previous two-slot implementation without
    # putting them into workflow JSON or forcing the user to paste them again.
    if not key:
        legacy_slot = "h3_prompt" if provider == "OpenAI API" else "nano_banana"
        key = values.get(legacy_slot, {}).get(provider, "")
    if not key:
        raise RuntimeError(
            f"{provider} のAPIキーがスロット「{slot}」に登録されていません。"
            "ノードの「APIキーを登録／更新」から入力してください。"
        )
    return _sanitize_api_key(provider, key)


def _tensor_to_png_base64(image: torch.Tensor) -> str:
    if image.ndim == 4:
        image = image[0]
    pixels = (image.detach().cpu().clamp(0, 1).numpy() * 255.0).round().astype(np.uint8)
    buffer = io.BytesIO()
    Image.fromarray(pixels, mode="RGB").save(buffer, format="PNG")
    return base64.b64encode(buffer.getvalue()).decode("ascii")


def _tensor_to_png_bytes(image: torch.Tensor) -> bytes:
    return base64.b64decode(_tensor_to_png_base64(image))


def _image_bytes_to_tensor(data: bytes) -> torch.Tensor:
    decoded = Image.open(io.BytesIO(data)).convert("RGB")
    pixels = np.asarray(decoded).astype(np.float32) / 255.0
    return torch.from_numpy(pixels)[None,]


def _response_image(payload: dict) -> torch.Tensor:
    for candidate in payload.get("candidates", []):
        for part in candidate.get("content", {}).get("parts", []):
            inline_data = part.get("inlineData", {})
            encoded = inline_data.get("data")
            if encoded and inline_data.get("mimeType", "").startswith("image/"):
                decoded = Image.open(io.BytesIO(base64.b64decode(encoded))).convert("RGB")
                pixels = np.asarray(decoded).astype(np.float32) / 255.0
                return torch.from_numpy(pixels)[None,]
    raise RuntimeError("Nano Banana returned no image. Prompt or safety policy may have blocked the edit.")


def _response_text(payload: dict) -> str:
    pieces = []
    for candidate in payload.get("candidates", []):
        for part in candidate.get("content", {}).get("parts", []):
            if part.get("text"):
                pieces.append(part["text"])
    return "\n".join(pieces)


_SINGLE_FRAME_CONTRACT = """
MANDATORY OUTPUT CONTRACT: Create exactly ONE single 16:9 cinematic illustration.
It must NOT be a comic page, manga panel, collage, diptych, triptych, contact sheet,
split screen, storyboard, or montage. Remove every panel border, gutter, white margin,
speech balloon, balloon tail, caption, dialogue, readable text, logo, and comic frame.
Reconstruct one continuous environment behind all removed elements. Return one clean,
full-bleed animation keyframe only.
"""


def _openai_chat_request(
    api_key: str,
    system: str,
    user_text: str,
    image: torch.Tensor | None = None,
    temperature: float = 0.2,
    max_tokens: int = 8192,
) -> str:
    content: str | list[dict] = user_text
    if image is not None:
        content = [
            {"type": "text", "text": user_text},
            {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{_tensor_to_png_base64(image)}", "detail": "high"}},
        ]
    body = {
        "model": "gpt-4.1-mini",
        "messages": [{"role": "system", "content": system}, {"role": "user", "content": content}],
        "temperature": float(temperature),
        "max_tokens": int(max_tokens),
    }
    try:
        response = requests.post(
            "https://api.openai.com/v1/chat/completions",
            headers={"Authorization": f"Bearer {_sanitize_api_key('OpenAI API', api_key)}"},
            json=body,
            timeout=300,
        )
    except (requests.RequestException, UnicodeError) as exc:
        raise RuntimeError(f"OpenAI request failed: {exc}") from exc
    if not response.ok:
        raise RuntimeError(f"OpenAI request failed ({response.status_code}): {response.text[:1000]}")
    choices = response.json().get("choices", [])
    result = choices[0].get("message", {}).get("content", "").strip() if choices else ""
    if not result:
        raise RuntimeError("OpenAI returned an empty response.")
    return result


def _openai_image_edit(api_key: str, image: torch.Tensor, prompt: str) -> torch.Tensor:
    try:
        response = requests.post(
            "https://api.openai.com/v1/images/edits",
            headers={"Authorization": f"Bearer {_sanitize_api_key('OpenAI API', api_key)}"},
            files={"image[]": ("source.png", _tensor_to_png_bytes(image), "image/png")},
            data={"model": "gpt-image-2", "prompt": prompt},
            timeout=600,
        )
    except (requests.RequestException, UnicodeError) as exc:
        raise RuntimeError(f"OpenAI image edit failed: {exc}") from exc
    if not response.ok:
        raise RuntimeError(f"OpenAI image edit failed ({response.status_code}): {response.text[:1000]}")
    items = response.json().get("data", [])
    encoded = items[0].get("b64_json") if items else None
    if encoded:
        return _image_bytes_to_tensor(base64.b64decode(encoded))
    image_url = items[0].get("url") if items else None
    if image_url:
        download = requests.get(image_url, timeout=180)
        download.raise_for_status()
        return _image_bytes_to_tensor(download.content)
    raise RuntimeError("OpenAI image edit returned no image.")


def _inspect_single_clean_frame(provider: str, api_key: str, image: torch.Tensor) -> tuple[bool, str]:
    instruction = "Inspect this image for use as one animation keyframe. Return JSON only: {\"pass\":true|false,\"reasons\":[\"panel borders\",\"gutters\",\"speech balloons\",\"readable text\",\"split screen\",\"other\"]}. pass is true only for one single full-bleed scene with none of those problems."
    if provider == "OpenAI API":
        verdict = _openai_chat_request(api_key, "You are a strict image QA validator. Return JSON only.", instruction, image, 0.0, 300).strip()
    else:
        check = {
            "contents": [{"role": "user", "parts": [
                {"text": instruction},
                {"inlineData": {"mimeType": "image/png", "data": _tensor_to_png_base64(image)}},
            ]}],
        }
        verdict = _response_text(_request(provider, api_key, "gemini-2.5-flash", check)).strip()
    try:
        parsed = json.loads(verdict[verdict.find("{"):verdict.rfind("}") + 1])
        return bool(parsed.get("pass")), ", ".join(parsed.get("reasons", [])) or "no reason returned"
    except (ValueError, TypeError, json.JSONDecodeError):
        return False, f"unparseable validator response: {verdict[:240]}"


def _save_diagnostic_image(image: torch.Tensor, source_index: int, attempt: int) -> str:
    filename = f"nanobanana_diagnostic_{int(time.time())}_{source_index}_{attempt}.png"
    target = Path(folder_paths.get_temp_directory()) / filename
    encoded = _tensor_to_png_base64(image)
    target.write_bytes(base64.b64decode(encoded))
    return filename


def _request(provider: str, api_key: str, model_id: str, body: dict) -> dict:
    if provider == "ComfyUI API":
        url = f"https://api.comfy.org/proxy/vertexai/gemini/{model_id}"
        headers = {
            "X-API-KEY": api_key,
            "Authorization": f"Bearer {api_key}",
            "Comfy-Usage-Source": "comfyui-local",
        }
    else:
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{model_id}:generateContent?key={api_key}"
        headers = {}
    try:
        response = requests.post(url, headers=headers, json=body, timeout=180)
    except requests.RequestException as exc:
        raise RuntimeError(f"Nano Banana request failed: {exc}") from exc
    if not response.ok:
        message = response.text[:1000]
        raise RuntimeError(f"Nano Banana request failed ({response.status_code}): {message}")
    return response.json()


def _validate_credential(provider: str, api_key: str) -> None:
    """Make a minimal real request before persisting a credential."""
    api_key = _sanitize_api_key(provider, api_key)
    if provider == "OpenAI API":
        result = _openai_chat_request(api_key, "Reply only with OK.", "OK", None, 0.0, 10)
    else:
        response = _request(
            provider,
            api_key,
            "gemini-2.5-flash",
            {"contents": [{"role": "user", "parts": [{"text": "Reply only: OK"}]}]},
        )
        result = _response_text(response).strip()
    if not result.strip():
        raise RuntimeError("APIキーの検証応答が空でした。キーまたはProvider設定を確認してください。")


def _h3_llm_request(provider: str, api_key: str, model: str, brief: str, temperature: float) -> str:
    """Call the selected cloud provider and return just its text."""
    if provider == "OpenAI API":
        return _openai_chat_request(api_key, _H3_LLM_SYSTEM, brief, None, temperature, 8192)
    elif provider == "Google Gemini API":
        model_id = model.strip() or "gemini-2.5-flash"
        url, headers = f"https://generativelanguage.googleapis.com/v1beta/models/{model_id}:generateContent?key={api_key}", {}
        body = {"systemInstruction": {"parts": [{"text": _H3_LLM_SYSTEM}]}, "contents": [{"role": "user", "parts": [{"text": brief}]}], "generationConfig": {"temperature": float(temperature), "maxOutputTokens": 8192}}
    else:
        raise RuntimeError(f"Unknown H3 LLM provider: {provider}")

    try:
        response = requests.post(url, headers=headers, json=body, timeout=300)
    except requests.RequestException as exc:
        raise RuntimeError(f"H3 LLM request failed: {exc}") from exc
    if not response.ok:
        raise RuntimeError(f"H3 LLM request failed ({response.status_code}): {response.text[:1000]}")
    payload = response.json()
    result = _response_text(payload).strip()
    if not result:
        raise RuntimeError("H3 LLM returned an empty prompt.")
    return result


def _validate_h3_llm_credential(provider: str, api_key: str) -> None:
    """Verify an H3 cloud credential with its selected provider before saving it."""
    default_model = "gpt-4.1-mini" if provider == "OpenAI API" else "gemini-2.5-flash"
    result = _h3_llm_request(provider, api_key, default_model, "Reply exactly: OK", 0.0)
    if not result.strip():
        raise RuntimeError("APIキーの検証応答が空でした。キーまたはProvider設定を確認してください。")


class NanoBananaH3Transform:
    """Transforms a single image, then returns it as a normal IMAGE for H3."""

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "image": ("IMAGE",),
                "provider": (_PROVIDERS, {"default": "OpenAI API", "tooltip": "選択した1つのAPIを画像変換とH3プロンプト生成の両方に使います。"}),
                "temperature": ("FLOAT", {"default": 0.2, "min": 0.0, "max": 1.0, "step": 0.05}),
                "seed": ("INT", {"default": 42, "min": 0, "max": 0xFFFFFFFFFFFFFFFF, "control_after_generate": True}),
            },
            "optional": {
                "image_transform_prompt": ("STRING", {"forceInput": True, "tooltip": "Nano Banana用の画像変換指示を接続します。"}),
                "h3_prompt_instruction": ("STRING", {"forceInput": True, "tooltip": "4コマからH3生成プロンプトを作る指示を接続します。"}),
            },
        }

    RETURN_TYPES = ("IMAGE", "STRING", "STRING")
    RETURN_NAMES = ("IMAGE", "H3_PROMPT", "OVERLAY_TITLE")
    FUNCTION = "transform"
    CATEGORY = "image/Nano Banana"
    DESCRIPTION = "選択した同じProvider/APIキーで画像変換とH3プロンプト生成を実行します。資格情報はワークフロー外に保存されます。"

    def transform(
        self,
        image: torch.Tensor,
        provider: str,
        temperature: float,
        seed: int,
        image_transform_prompt: str | None = None,
        h3_prompt_instruction: str | None = None,
    ):
        if provider not in _PROVIDERS:
            raise RuntimeError("Unknown workflow API provider.")
        if not image_transform_prompt or not image_transform_prompt.strip():
            raise RuntimeError("Nano Banana画像変換指示を入力してください。")
        if not h3_prompt_instruction or not h3_prompt_instruction.strip():
            raise RuntimeError("H3プロンプト生成指示を入力してください。")

        api_key = _credential(provider)
        # The H3 prompt deliberately contains no rendered title or readable text.
        # Its reference image must enforce the same rule; otherwise H3 can faithfully
        # reproduce a title or speech balloon that survives Nano Banana conversion.
        strict_image_transform_prompt = f"{image_transform_prompt.rstrip()}\n\n{_SINGLE_FRAME_CONTRACT.strip()}"
        if provider == "OpenAI API":
            transformed_image = _openai_image_edit(api_key, image, strict_image_transform_prompt)
        else:
            model_id = _MODELS["Nano Banana 2 (Gemini 3.1 Flash Image)"]
            body = {
                "contents": [{"role": "user", "parts": [
                    {"text": strict_image_transform_prompt},
                    {"inlineData": {"mimeType": "image/png", "data": _tensor_to_png_base64(image)}},
                ]}],
                "generationConfig": {"responseModalities": ["IMAGE", "TEXT"], "imageConfig": {"imageSize": "1K"}, "seed": int(seed) % 2147483647},
            }
            image_response = _request(provider, api_key, model_id, body)
            try:
                transformed_image = _response_image(image_response)
            except RuntimeError as first_error:
                response_text = _response_text(image_response).strip()[:500]
                print(f"[Nano Banana H3] initial clean-frame response had no image: {response_text or first_error}")
                retry_body = {
                    "contents": [{"role": "user", "parts": [
                        {"text": "Return IMAGE ONLY: one clean 16:9 anime animation keyframe based on this source. Remove every title, speech bubble, caption, sign, number, logo, panel border, and readable text. No text anywhere."},
                        {"inlineData": {"mimeType": "image/png", "data": _tensor_to_png_base64(image)}},
                    ]}],
                    "generationConfig": {"responseModalities": ["IMAGE", "TEXT"], "imageConfig": {"imageSize": "1K"}, "seed": int(seed) % 2147483647},
                }
                transformed_image = _response_image(_request(provider, api_key, model_id, retry_body))
        clean, reason = _inspect_single_clean_frame(provider, api_key, transformed_image)
        if not clean:
            repair_prompt = "Repair this candidate into one clean animation keyframe. " + _SINGLE_FRAME_CONTRACT.strip() + " The validator found: " + reason
            if provider == "OpenAI API":
                transformed_image = _openai_image_edit(api_key, transformed_image, repair_prompt)
            else:
                repair_body = {
                    "contents": [{"role": "user", "parts": [
                        {"text": repair_prompt},
                        {"inlineData": {"mimeType": "image/png", "data": _tensor_to_png_base64(transformed_image)}},
                    ]}],
                    "generationConfig": {"responseModalities": ["IMAGE", "TEXT"], "imageConfig": {"imageSize": "1K"}, "seed": int(seed) % 2147483647},
                }
                transformed_image = _response_image(_request(provider, api_key, model_id, repair_body))
            clean, reason = _inspect_single_clean_frame(provider, api_key, transformed_image)
            if not clean:
                diagnostic = _save_diagnostic_image(transformed_image, 0, 2)
                print(f"[Nano Banana H3] WARNING: validator still reported '{reason}'. Continuing with repaired image. Diagnostic: {diagnostic}")
        if provider == "OpenAI API":
            h3_prompt = _openai_chat_request(
                api_key,
                h3_prompt_instruction,
                "Analyze the supplied original four-panel manga and create the final H3 prompt now.",
                image,
                temperature,
                8192,
            ).strip()
        else:
            prompt_body = {
                "contents": [{"role": "user", "parts": [
                    {"text": "Analyze the supplied original four-panel manga and create the final H3 prompt now."},
                    {"inlineData": {"mimeType": "image/png", "data": _tensor_to_png_base64(image)}},
                ]}],
                "systemInstruction": {"parts": [{"text": h3_prompt_instruction}]},
                "generationConfig": {"temperature": float(temperature)},
            }
            h3_prompt = _response_text(_request(provider, api_key, "gemini-2.5-flash", prompt_body)).strip()
        if not h3_prompt:
            h3_prompt = h3_prompt_instruction
        title_match = re.search(r'(?im)^\s*overlay_title\s*[:：]\s*["“「]([^"”」\r\n]+)["”」]\s*$', h3_prompt)
        overlay_title = title_match.group(1).strip() if title_match else ""
        # overlay_title is workflow metadata, never conditioning text for H3.
        # Keeping it out of the H3 prompt prevents a second generated title.
        if title_match:
            h3_prompt = (h3_prompt[:title_match.start()] + h3_prompt[title_match.end():]).strip()
        return (transformed_image, h3_prompt, overlay_title)


class DeterministicEndCreditOverlay:
    """Adds an exact, readable end credit to decoded video frames.

    Generative video models cannot reliably spell Japanese text or URLs.  This
    post-processing node deliberately runs after H3 generation, so the credit
    is independent of the image model and is identical on every render.
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "images": ("IMAGE",),
                "fps": ("FLOAT", {"default": 24.0, "min": 1.0, "max": 120.0, "step": 1.0}),
                "credit_seconds": ("FLOAT", {"default": 3.0, "min": 0.5, "max": 10.0, "step": 0.5}),
                "credit_line": ("STRING", {"default": "ネームから全自動の自律式統合AI漫画システム"}),
                "url": ("STRING", {"default": "https://note.com/happy_duck780"}),
                "position": (("bottom_right", "bottom_left"), {"default": "bottom_right"}),
                "credit_font_scale": ("FLOAT", {"default": 0.018, "min": 0.01, "max": 0.06, "step": 0.001}),
                "url_font_scale": ("FLOAT", {"default": 0.030, "min": 0.01, "max": 0.06, "step": 0.001}),
            },
        }

    RETURN_TYPES = ("IMAGE",)
    RETURN_NAMES = ("images",)
    FUNCTION = "apply"
    CATEGORY = "video/postprocess"
    DESCRIPTION = "Draws an exact static end credit and URL on the last seconds of a video."

    @staticmethod
    def _font(size: int):
        for path in (
            "/mnt/c/Windows/Fonts/meiryob.ttc",
            "/mnt/c/Windows/Fonts/YuGothB.ttc",
            "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        ):
            if os.path.exists(path):
                return ImageFont.truetype(path, size=size)
        return ImageFont.load_default()

    def apply(
        self,
        images: torch.Tensor,
        fps: float,
        credit_seconds: float,
        credit_line: str,
        url: str,
        position: str,
        credit_font_scale: float,
        url_font_scale: float,
    ):
        if images.ndim != 4 or images.shape[-1] not in (3, 4):
            raise RuntimeError("End credit overlay expects a batch of RGB video frames.")
        frame_count, height, width, _ = images.shape
        first_credit_frame = max(0, frame_count - max(1, round(float(fps) * float(credit_seconds))))
        result = images.detach().cpu().clone().float()
        # The URL is the primary call-to-action, so it has its own scale and
        # defaults larger than the supporting credit line.
        title_font = self._font(max(14, round(width * float(credit_font_scale))))
        url_font = self._font(max(22, round(width * float(url_font_scale))))
        margin = max(18, round(width * 0.025))

        for index in range(first_credit_frame, frame_count):
            array = (result[index, ..., :3].clamp(0, 1).numpy() * 255.0).round().astype(np.uint8)
            frame = Image.fromarray(array, mode="RGB").convert("RGBA")
            overlay = Image.new("RGBA", frame.size, (0, 0, 0, 0))
            draw = ImageDraw.Draw(overlay)
            title_box = draw.textbbox((0, 0), credit_line, font=title_font)
            url_box = draw.textbbox((0, 0), url, font=url_font)
            text_height = (title_box[3] - title_box[1]) + (url_box[3] - url_box[1]) + margin
            panel_top = height - text_height - (margin * 2)
            panel_width = min(width - margin, max(title_box[2], url_box[2]) + (margin * 2))
            panel_left = width - panel_width if position == "bottom_right" else 0
            panel_right = panel_left + panel_width
            draw.rounded_rectangle((panel_left, panel_top, panel_right, height), radius=margin // 2, fill=(0, 0, 0, 190))
            y = panel_top + margin
            x = panel_left + margin
            draw.text((x, y), credit_line, font=title_font, fill=(255, 255, 255, 255), stroke_width=1, stroke_fill=(0, 0, 0, 255))
            y += (title_box[3] - title_box[1]) + max(6, margin // 3)
            draw.text((x, y), url, font=url_font, fill=(125, 210, 255, 255), stroke_width=1, stroke_fill=(0, 0, 0, 255))
            result[index, ..., :3] = torch.from_numpy(np.asarray(Image.alpha_composite(frame, overlay).convert("RGB"))).float() / 255.0
        return (result,)


class DeterministicTitleWatermarkOverlay:
    """Burn exact title and footer text into every generated video deterministically."""

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "images": ("IMAGE",),
                "fps": ("FLOAT", {"default": 24.0, "min": 1.0, "max": 120.0, "step": 1.0}),
                "title": ("STRING", {"default": "", "multiline": False, "tooltip": "漫画タイトル。空欄ならタイトルを合成しません。"}),
                "title_seconds": ("FLOAT", {"default": 3.7, "min": 0.0, "max": 15.0, "step": 0.1}),
                "footer_left": ("STRING", {"default": "ネームから全自動の自律式統合AI漫画システム : https://note.com/happy_duck780", "multiline": False}),
                "footer_right": ("STRING", {"default": "Generated by ChatGPT with Super FURO AI 4-koma v5.5.2", "multiline": False}),
            },
            "hidden": {
                # The exact H3 prompt is part of the queued workflow.  Keeping it
                # available here makes a title resilient to a frontend widget value
                # that has not yet committed to the saved workflow.
                "prompt": "PROMPT",
            },
        }

    RETURN_TYPES = ("IMAGE",)
    RETURN_NAMES = ("images",)
    FUNCTION = "apply"
    CATEGORY = "video/postprocess"
    DESCRIPTION = "H3生成後にタイトルと2本のフッターを正確な文字として合成します。"

    @staticmethod
    def _font(size: int):
        return DeterministicEndCreditOverlay._font(size)

    @staticmethod
    def _draw_label(draw, image_size, text, x, y, font, anchor="la"):
        if not text:
            return
        draw.text(
            (x, y), text, font=font, anchor=anchor,
            fill=(255, 255, 255, 255), stroke_width=max(1, font.size // 18),
            stroke_fill=(0, 0, 0, 255),
        )

    @staticmethod
    def _title_from_prompt(prompt) -> str:
        """Read only an explicitly declared overlay title; never invent one."""
        if not isinstance(prompt, dict):
            return ""
        values = []
        for node in prompt.values():
            if not isinstance(node, dict):
                continue
            inputs = node.get("inputs", {})
            if isinstance(inputs, dict):
                values.extend(value for value in inputs.values() if isinstance(value, str))
        patterns = (
            r'(?im)\boverlay\s+title\s*[:：]?\s*["“「]([^"”」\r\n]+)["”」]',
            r'(?im)\bexact\s+(?:japanese\s+)?title\s*(?:is|:|：)?\s*["“「]([^"”」\r\n]+)["”」]',
        )
        for value in values:
            for pattern in patterns:
                match = re.search(pattern, value)
                if match:
                    return match.group(1).strip()
        return ""

    def apply(self, images, fps, title, title_seconds, footer_left, footer_right, prompt=None):
        if images.ndim != 4 or images.shape[-1] not in (3, 4):
            raise RuntimeError("Title/watermark overlay expects a batch of RGB video frames.")
        title = (title or "").strip() or self._title_from_prompt(prompt)
        frame_count, height, width, _ = images.shape
        title_frames = min(frame_count, max(0, round(float(fps) * float(title_seconds))))
        title_font = self._font(max(20, round(width * 0.044)))
        footer_font = self._font(max(10, round(width * 0.012)))
        margin = max(10, round(width * 0.014))
        result = images.detach().cpu().clone().float()
        for index in range(frame_count):
            array = (result[index, ..., :3].clamp(0, 1).numpy() * 255.0).round().astype(np.uint8)
            frame = Image.fromarray(array, mode="RGB").convert("RGBA")
            overlay = Image.new("RGBA", frame.size, (0, 0, 0, 0))
            draw = ImageDraw.Draw(overlay)
            if title and index < title_frames:
                # Opening title: fixed upper-left overlap, no panel, bar, or card.
                # Preserve the system style: black lettering with a thin white outline.
                draw.text(
                    (margin, margin), title, font=title_font, anchor="la",
                    fill=(0, 0, 0, 255), stroke_width=max(1, title_font.size // 18),
                    stroke_fill=(255, 255, 255, 255),
                )
            # Use two rows so both credits remain readable at 16:9 H3 output sizes.
            for row, text in enumerate((footer_left, footer_right)):
                if not text:
                    continue
                y = height - margin - (2 - row) * (footer_font.size + margin // 2)
                box = draw.textbbox((0, 0), text, font=footer_font)
                draw.rounded_rectangle((0, y - footer_font.size, min(width, box[2] + margin * 2), y + margin // 2), radius=max(2, margin // 2), fill=(0, 0, 0, 135))
                self._draw_label(draw, frame.size, text, margin, y - footer_font.size // 2, footer_font, "lm")
            result[index, ..., :3] = torch.from_numpy(np.asarray(Image.alpha_composite(frame, overlay).convert("RGB"))).float() / 255.0
        return (result,)


NODE_CLASS_MAPPINGS["NanoBananaH3Transform"] = NanoBananaH3Transform
NODE_DISPLAY_NAME_MAPPINGS["NanoBananaH3Transform"] = "Nano Banana Image Transform (H3)"
NODE_CLASS_MAPPINGS["DeterministicEndCreditOverlay"] = DeterministicEndCreditOverlay
NODE_DISPLAY_NAME_MAPPINGS["DeterministicEndCreditOverlay"] = "固定エンドクレジット（正確なNote URL）"
NODE_CLASS_MAPPINGS["DeterministicTitleWatermarkOverlay"] = DeterministicTitleWatermarkOverlay
NODE_DISPLAY_NAME_MAPPINGS["DeterministicTitleWatermarkOverlay"] = "固定タイトル・ウォーターマーク（正確な文字）"


@PromptServer.instance.routes.get("/nanobanana_h3/h3_system_prompt")
async def h3_system_prompt(request):
    """Expose the same canonical instruction used by every H3 LLM provider."""
    return web.Response(text=_H3_LLM_SYSTEM, content_type="text/plain", charset="utf-8")


@PromptServer.instance.routes.post("/nanobanana_h3/credential")
async def save_credential(request):
    body = await request.json()
    provider = body.get("provider", "")
    slot = body.get("slot", "")
    api_key = body.get("api_key", "").strip()
    if provider not in _PROVIDERS or not _SLOT_RE.fullmatch(slot) or not api_key:
        return web.json_response({"error": "Invalid provider, slot, or API key."}, status=400)
    try:
        api_key = _sanitize_api_key(provider, api_key)
        await asyncio.to_thread(_validate_credential, provider, api_key)
    except RuntimeError as exc:
        return web.json_response({"error": str(exc)}, status=401)
    credentials = _read_credentials()
    credentials.setdefault(slot, {})[provider] = api_key
    _write_credentials(credentials)
    return web.json_response({"ok": True, "provider": provider, "slot": slot, "verified": True})


@PromptServer.instance.routes.get("/nanobanana_h3/credential_status")
async def credential_status(request):
    provider = request.query.get("provider", "")
    slot = request.query.get("slot", "")
    if provider not in _PROVIDERS or not _SLOT_RE.fullmatch(slot):
        return web.json_response({"error": "Invalid provider or slot."}, status=400)
    values = _read_credentials()
    configured = bool(values.get(slot, {}).get(provider))
    if not configured and slot == _UNIFIED_SLOT:
        legacy_slot = "h3_prompt" if provider == "OpenAI API" else "nano_banana"
        configured = bool(values.get(legacy_slot, {}).get(provider))
    return web.json_response({"configured": configured, "provider": provider, "slot": slot})


@PromptServer.instance.routes.post("/nanobanana_h3/llm_credential")
async def save_llm_credential(request):
    """Persist an H3 cloud key locally, never inside a workflow JSON."""
    body = await request.json()
    provider = body.get("provider", "")
    slot = body.get("slot", "")
    api_key = body.get("api_key", "").strip()
    if provider not in ("OpenAI API", "Google Gemini API") or not _SLOT_RE.fullmatch(slot) or not api_key:
        return web.json_response({"error": "Invalid provider, slot, or API key."}, status=400)
    try:
        await asyncio.to_thread(_validate_h3_llm_credential, provider, api_key)
    except RuntimeError as exc:
        return web.json_response({"error": str(exc)}, status=401)
    credentials = _read_credentials()
    credentials.setdefault(slot, {})[provider] = api_key
    _write_credentials(credentials)
    return web.json_response({"ok": True, "provider": provider, "slot": slot, "verified": True})


@PromptServer.instance.routes.get("/nanobanana_h3/llm_credential_status")
async def llm_credential_status(request):
    provider = request.query.get("provider", "")
    slot = request.query.get("slot", "")
    if provider not in ("OpenAI API", "Google Gemini API") or not _SLOT_RE.fullmatch(slot):
        return web.json_response({"error": "Invalid provider or slot."}, status=400)
    configured = bool(_read_credentials().get(slot, {}).get(provider))
    return web.json_response({"configured": configured, "local": False, "provider": provider, "slot": slot})


@PromptServer.instance.routes.post("/nanobanana_h3/restore_preview")
async def restore_preview(request):
    """Re-publish a completed preview when a job was started by a remote client."""
    body = await request.json()
    filename = body.get("filename", "")
    node_id = str(body.get("node_id", "142"))
    if not filename or Path(filename).name != filename or not filename.lower().endswith((".png", ".jpg", ".jpeg", ".webp")):
        return web.json_response({"error": "Invalid preview filename."}, status=400)
    preview_path = Path(folder_paths.get_temp_directory()) / filename
    if not preview_path.is_file():
        return web.json_response({"error": "Preview image was not found."}, status=404)
    PromptServer.instance.send_sync(
        "executed",
        {
            "node": node_id,
            "display_node": node_id,
            "output": {"images": [{"filename": filename, "subfolder": "", "type": "temp"}]},
            "prompt_id": "restored-nanobanana-preview",
        },
    )
    return web.json_response({"ok": True})


@PromptServer.instance.routes.post("/nanobanana_h3/restore_video")
async def restore_video(request):
    """Re-publish a saved video to the original Save Video node for playback."""
    body = await request.json()
    filename = body.get("filename", "")
    subfolder = body.get("subfolder", "")
    node_id = str(body.get("node_id", "92"))
    if not filename or Path(filename).name != filename or not filename.lower().endswith((".mp4", ".webm", ".mov")):
        return web.json_response({"error": "Invalid video filename."}, status=400)
    relative_path = Path(subfolder) / filename
    video_path = Path(folder_paths.get_output_directory()) / relative_path
    if not video_path.is_file():
        return web.json_response({"error": "Saved video was not found."}, status=404)
    PromptServer.instance.send_sync(
        "executed",
        {
            "node": node_id,
            "display_node": node_id,
            "output": {"gifs": [{"filename": filename, "subfolder": subfolder, "type": "output", "format": "video/h264-mp4", "frame_rate": 24.0}]},
            "prompt_id": "restored-nanobanana-video",
        },
    )
    return web.json_response({"ok": True})
