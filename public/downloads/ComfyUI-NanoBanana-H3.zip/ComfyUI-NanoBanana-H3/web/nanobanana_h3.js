import { app } from "../../scripts/app.js";

const CREDENTIAL_SLOT = "workflow_api";

function widgetValue(node, name, fallback = "") {
  return node.widgets?.find((widget) => widget.name === name)?.value ?? fallback;
}

async function credentialStatus(provider) {
  const query = new URLSearchParams({provider, slot: CREDENTIAL_SLOT});
  const response = await fetch(`/nanobanana_h3/credential_status?${query}`, {cache: "no-store"});
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || "資格情報の状態を確認できませんでした");
  return result;
}

async function refreshCredentialStatus(node, button) {
  const provider = widgetValue(node, "provider", "OpenAI API");
  button.name = `🔑 ${provider}：確認中…`;
  try {
    const status = await credentialStatus(provider);
    button.name = status.configured
      ? `✅ ${provider} 登録済み（画像＋H3共通）`
      : `⚠️ ${provider} APIキー未登録／登録`;
  } catch {
    button.name = `⚠️ ${provider} 状態エラー／開く`;
  }
  node.setDirtyCanvas(true, true);
}

function showCredentialDialog(node, button) {
  const provider = widgetValue(node, "provider", "OpenAI API");
  const overlay = document.createElement("div");
  overlay.style.cssText = "position:fixed;inset:0;z-index:10000;background:#0009;display:flex;align-items:center;justify-content:center";
  const panel = document.createElement("div");
  panel.style.cssText = "width:560px;max-width:92vw;background:#252525;color:#eee;padding:20px;border-radius:10px;font:14px sans-serif";
  panel.innerHTML = `
    <h3 style="margin:0 0 8px">API設定（入力欄は1つ）</h3>
    <p style="margin:0 0 8px;color:#ddd">選択中：<strong>${provider}</strong></p>
    <p style="margin:0 0 14px;color:#bbb">この1つのキーを画像変換とH3プロンプト生成の両方に使います。キーはワークフローJSONには保存されません。</p>
    <div data-status style="color:#bbb;margin-bottom:8px">状態を確認中…</div>
    <input data-key type="password" autocomplete="off" placeholder="${provider} のAPIキー" style="width:100%;box-sizing:border-box;padding:9px">
    <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:14px">
      <button data-close>閉じる</button><button data-save>認証して保存</button>
    </div>`;

  const statusElement = panel.querySelector("[data-status]");
  const setStatus = (configured) => {
    statusElement.textContent = configured ? `✅ ${provider} 登録済み` : `⚠️ ${provider} 未登録`;
    statusElement.style.color = configured ? "#8ee59b" : "#ffcc80";
  };
  const refresh = async () => {
    try {
      setStatus((await credentialStatus(provider)).configured);
    } catch (error) {
      statusElement.textContent = `⚠️ 状態確認エラー: ${error.message}`;
    }
    refreshCredentialStatus(node, button);
  };

  panel.querySelector("[data-close]").onclick = () => overlay.remove();
  panel.querySelector("[data-save]").onclick = async () => {
    const input = panel.querySelector("[data-key]");
    const saveButton = panel.querySelector("[data-save]");
    const apiKey = input.value.trim();
    if (!apiKey) return;
    saveButton.disabled = true;
    saveButton.textContent = "認証を確認中…";
    try {
      const response = await fetch("/nanobanana_h3/credential", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({provider, slot: CREDENTIAL_SLOT, api_key: apiKey}),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "保存に失敗しました");
      input.value = "";
      setStatus(true);
    } catch (error) {
      alert(`${provider} を保存できませんでした: ${error.message}`);
    } finally {
      saveButton.disabled = false;
      saveButton.textContent = "認証して保存";
      refreshCredentialStatus(node, button);
    }
  };
  overlay.appendChild(panel);
  document.body.appendChild(overlay);
  refresh();
}

app.registerExtension({
  name: "local.nanobanana_h3.credentials",
  beforeRegisterNodeDef(nodeType, nodeData) {
    if (nodeData.name !== "NanoBananaH3Transform") return;
    const original = nodeType.prototype.onNodeCreated;
    nodeType.prototype.onNodeCreated = function () {
      original?.apply(this, arguments);
      const button = this.addWidget("button", "🔑 API設定を確認中…", null, () => showCredentialDialog(this, button));
      button.serialize = false;
      const copyButton = this.addWidget("button", "📋 H3システム指示をコピー", null, () => copyH3SystemPrompt(copyButton));
      copyButton.serialize = false;
      refreshCredentialStatus(this, button);
      const previousWidgetChanged = this.onWidgetChanged;
      this.onWidgetChanged = function (name, value, oldValue, widget) {
        previousWidgetChanged?.apply(this, arguments);
        if (name === "provider") refreshCredentialStatus(this, button);
      };
      const previousConfigure = this.onConfigure;
      this.onConfigure = function () {
        previousConfigure?.apply(this, arguments);
        queueMicrotask(() => refreshCredentialStatus(this, button));
      };
    };
  },
});

async function copyH3SystemPrompt(button) {
  const response = await fetch("/nanobanana_h3/h3_system_prompt");
  if (!response.ok) throw new Error("汎用システム指示を取得できませんでした");
  await navigator.clipboard.writeText(await response.text());
  const original = button.name;
  button.name = "✅ 汎用システム指示をコピー済み";
  setTimeout(() => { button.name = original; }, 1600);
}
