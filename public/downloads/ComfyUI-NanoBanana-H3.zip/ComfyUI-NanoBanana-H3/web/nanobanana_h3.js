import { app } from "../../scripts/app.js";

function widgetValue(node, name, fallback = "") {
  return node.widgets?.find((widget) => widget.name === name)?.value ?? fallback;
}

async function refreshCredentialStatus(node, button) {
  const provider = widgetValue(node, "provider", "ComfyUI API");
  const slot = widgetValue(node, "credential_slot", "nano_banana");
  button.name = "🔐 APIキーを確認中…";
  try {
    const query = new URLSearchParams({provider, slot});
    const response = await fetch(`/nanobanana_h3/credential_status?${query}`);
    const result = await response.json();
    button.name = result.configured ? "✅ APIキー認証済み（更新）" : "⚠️ APIキー未登録／登録";
  } catch {
    button.name = "🔐 APIキーを登録／更新";
  }
  node.setDirtyCanvas(true, true);
}

function showCredentialDialog(node, button) {
  const provider = widgetValue(node, "provider", "ComfyUI API");
  const slot = widgetValue(node, "credential_slot", "nano_banana");
  const overlay = document.createElement("div");
  overlay.style.cssText = "position:fixed;inset:0;z-index:10000;background:#0009;display:flex;align-items:center;justify-content:center";
  const panel = document.createElement("div");
  panel.style.cssText = "width:440px;max-width:90vw;background:#252525;color:#eee;padding:20px;border-radius:10px;font:14px sans-serif";
  panel.innerHTML = `<h3 style="margin-top:0">Nano Banana APIキー</h3><p>${provider} ／スロット: <b>${slot}</b></p><input type="password" autocomplete="off" placeholder="APIキーを貼り付け" style="width:100%;box-sizing:border-box;padding:9px"><p style="color:#bbb;font-size:12px">保存前に、選択中Providerで実際に認証確認します。失敗したキーは保存しません。キーはワークフローには保存されず、このPCのComfyUI秘密設定にだけ保存されます。</p><div style="display:flex;gap:8px;justify-content:flex-end"><button data-cancel>キャンセル</button><button data-save>認証して保存</button></div>`;
  const input = panel.querySelector("input");
  const close = () => overlay.remove();
  panel.querySelector("[data-cancel]").onclick = close;
  panel.querySelector("[data-save]").onclick = async () => {
    const apiKey = input.value.trim();
    if (!apiKey) return;
    const button = panel.querySelector("[data-save]");
    button.disabled = true;
    button.textContent = "認証を確認中…";
    try {
      const response = await fetch("/nanobanana_h3/credential", {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({provider,slot,api_key:apiKey})});
      if (!response.ok) throw new Error((await response.json()).error || "保存に失敗しました");
      close();
      alert(`認証確認済み：APIキーを ${provider} / ${slot} に保存しました。`);
      refreshCredentialStatus(node, button);
    } catch (error) {
      button.disabled = false;
      button.textContent = "認証して保存";
      alert(`APIキーを保存できませんでした: ${error.message}`);
    }
  };
  overlay.appendChild(panel);
  document.body.appendChild(overlay);
  input.focus();
}

app.registerExtension({
  name: "local.nanobanana_h3.credentials",
  beforeRegisterNodeDef(nodeType, nodeData) {
    if (nodeData.name !== "NanoBananaH3Transform") return;
    const original = nodeType.prototype.onNodeCreated;
    nodeType.prototype.onNodeCreated = function () {
      original?.apply(this, arguments);
      const button = this.addWidget("button", "🔐 APIキーを確認中…", null, () => showCredentialDialog(this, button));
      button.serialize = false;
      refreshCredentialStatus(this, button);
      const previousWidgetChanged = this.onWidgetChanged;
      this.onWidgetChanged = function (name, value, oldValue, widget) {
        previousWidgetChanged?.apply(this, arguments);
        if (name === "provider" || name === "credential_slot") refreshCredentialStatus(this, button);
      };
    };
  },
});

async function refreshLLMCredentialStatus(node, button) {
  const provider = widgetValue(node, "provider", "LM Studio local_fast (Qwen3.5 9B)");
  const slot = widgetValue(node, "credential_slot", "h3_prompt");
  button.name = "🔐 接続を確認中…";
  try {
    const query = new URLSearchParams({provider, slot});
    const response = await fetch(`/nanobanana_h3/llm_credential_status?${query}`);
    const result = await response.json();
    if (result.local) button.name = provider.startsWith("Manual") ? "✍️ 手入力モード" : "🖥️ LM Studio（キー不要）";
    else button.name = result.configured ? "✅ APIキー登録済み（更新）" : "⚠️ APIキー未登録／登録";
  } catch {
    button.name = "🔐 APIキーを登録／更新";
  }
  node.setDirtyCanvas(true, true);
}

function showLLMCredentialDialog(node, button) {
  const provider = widgetValue(node, "provider", "LM Studio local_fast (Qwen3.5 9B)");
  if (provider.startsWith("LM Studio") || provider.startsWith("Manual")) return;
  const slot = widgetValue(node, "credential_slot", "h3_prompt");
  const overlay = document.createElement("div");
  overlay.style.cssText = "position:fixed;inset:0;z-index:10000;background:#0009;display:flex;align-items:center;justify-content:center";
  const panel = document.createElement("div");
  panel.style.cssText = "width:440px;max-width:90vw;background:#252525;color:#eee;padding:20px;border-radius:10px;font:14px sans-serif";
  panel.innerHTML = `<h3 style="margin-top:0">H3プロンプトLLM APIキー</h3><p>${provider} ／スロット: <b>${slot}</b></p><input type="password" autocomplete="off" placeholder="APIキーを貼り付け" style="width:100%;box-sizing:border-box;padding:9px"><p style="color:#bbb;font-size:12px">キーはワークフローには保存されず、このPCのComfyUI秘密設定だけに保存されます。</p><div style="display:flex;gap:8px;justify-content:flex-end"><button data-cancel>キャンセル</button><button data-save>保存</button></div>`;
  const input = panel.querySelector("input");
  const close = () => overlay.remove();
  panel.querySelector("[data-cancel]").onclick = close;
  panel.querySelector("[data-save]").onclick = async () => {
    const apiKey = input.value.trim();
    if (!apiKey) return;
    const saveButton = panel.querySelector("[data-save]");
    saveButton.disabled = true;
    saveButton.textContent = "保存中…";
    try {
      const response = await fetch("/nanobanana_h3/llm_credential", {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({provider,slot,api_key:apiKey})});
      if (!response.ok) throw new Error((await response.json()).error || "保存に失敗しました");
      close();
      await refreshLLMCredentialStatus(node, button);
    } catch (error) {
      saveButton.disabled = false;
      saveButton.textContent = "保存";
      alert(`APIキーを保存できませんでした: ${error.message}`);
    }
  };
  overlay.appendChild(panel);
  document.body.appendChild(overlay);
  input.focus();
}

async function copyH3SystemPrompt(button) {
  const response = await fetch("/nanobanana_h3/h3_system_prompt");
  if (!response.ok) throw new Error("汎用システム指示を取得できませんでした");
  await navigator.clipboard.writeText(await response.text());
  const original = button.name;
  button.name = "✅ 汎用システム指示をコピー済み";
  button.callback = () => copyH3SystemPrompt(button);
  setTimeout(() => { button.name = original; }, 1600);
}

app.registerExtension({
  name: "local.nanobanana_h3.h3_prompt_provider",
  beforeRegisterNodeDef(nodeType, nodeData) {
    if (nodeData.name !== "H3PromptProviderRouter") return;
    const original = nodeType.prototype.onNodeCreated;
    nodeType.prototype.onNodeCreated = function () {
      original?.apply(this, arguments);
      const button = this.addWidget("button", "🔐 接続を確認中…", null, () => showLLMCredentialDialog(this, button));
      button.serialize = false;
      const copyButton = this.addWidget("button", "📋 汎用システム指示をコピー", null, () => copyH3SystemPrompt(copyButton));
      copyButton.serialize = false;
      refreshLLMCredentialStatus(this, button);
      const previousWidgetChanged = this.onWidgetChanged;
      this.onWidgetChanged = function (name, value, oldValue, widget) {
        previousWidgetChanged?.apply(this, arguments);
        if (name === "provider" || name === "credential_slot") refreshLLMCredentialStatus(this, button);
        if (name === "provider" && value === "OpenAI API") {
          const model = this.widgets?.find((item) => item.name === "cloud_model");
          if (model) model.value = "gpt-4.1-mini";
        }
        if (name === "provider" && value === "Google Gemini API") {
          const model = this.widgets?.find((item) => item.name === "cloud_model");
          if (model) model.value = "gemini-2.5-flash";
        }
        if (name === "provider" && value.startsWith("LM Studio")) {
          const model = this.widgets?.find((item) => item.name === "cloud_model");
          if (model) model.value = "";
        }
      };
    };
  },
});
