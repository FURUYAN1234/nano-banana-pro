# MiniMax H3 Four-panel non-LM Studio release v1.1.7

This release contains one workflow: `FourPanel_NonLM_4step_20260910071735_v1.1.7.json`. It uses the selected cloud API for image transformation, H3 prompt authoring and auditing; LM Studio is not required.

v1.1.7 fixes the bundled offline tests failing to read UTF-8 source under the Windows CP932 default. It also redacts credentials from provider connection errors and echoed error responses. Generation settings and the five-candidate limit are unchanged from v1.1.6. The GPU results below were supplied with v1.1.6; no new API or GPU generation was performed for these corrections.

Copy all five folders from `custom_nodes/` into ComfyUI's `custom_nodes/`:
- ComfyUI-NanoBanana-H3
- ComfyUI-MiniMax-H3-Long-Video
- ComfyUI-Spectrum-MiniMax-H3 (included for compatibility; not connected in the Fused4 workflow)
- ComfyUI-H3-AudioRefine (bundled runtime dependency)
- ComfyUI-PlagueKind-Nodes (bundled SLA dependency)

All five are included; do not separately download and patch them. Install requirements using ComfyUI's Python. Use a CUDA/H3-compatible ComfyUI and OS/PyTorch-compatible Triton (triton-windows on Windows), FFmpeg on PATH and a Japanese font. Download the four models listed in models.json into their specified models directories.

Run verify_package.py after extraction. Load the workflow, supply your own four-panel image, register the selected API key in the node and confirm dialogue readings. API keys remain only in process memory and must be re-entered after restart. No model weights, user images/videos, credentials or personal pronunciation dictionary are included.

Video: Fused4 + SLA, 4 steps, 24fps, 16:9. Audio: 2 refinement steps at 0.5, with original/refined candidate comparison. Duration: five seconds per spoken turn, 30-second fallback without dialogue. H3 generates quiet instrumental BGM. Completed files are saved in ComfyUI/output/video/MiniMax_H3; checkpoints are in output/h3_long_video.

Quality checks compare at most five candidates, including the initial attempt. An earlier passing candidate proceeds immediately; if all five fail, the best inspected candidate is retained and generation continues. Protected dialogue is never rewritten by prose translation. Interruptions and unavailable required inputs are not reported as successful generation.

Source-image API inspection, fresh image transformation and prompt authoring were followed by a 25-second/600-frame GPU generation. All five selected audiovisual audits passed (attempts 1,1,1,3,1); full decoding and 15 sampled frames were checked. The manga balloon-order correction was verified against source geometry. After completion, the candidate limit was changed to five; 13 offline tests cover early success, best-of-five fallback and fourth/fifth checkpoint reuse. A further GPU run for that limit-only change was omitted as authorized. Full human audio listening, fresh GPU generation from the ZIP and another-PC execution remain unverified. See README_JA.md, VALIDATION.md and REPRODUCE.md.

This package replaces the former three LM Studio sample workflows as the current release payload. Their source and tests remain in legacy_v1_1_5 in the tagged source history.
