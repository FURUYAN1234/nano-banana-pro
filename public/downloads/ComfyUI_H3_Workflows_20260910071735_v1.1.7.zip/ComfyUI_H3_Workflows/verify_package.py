"""Verify the actual extracted four-panel portable release, including extra files."""
import ast, hashlib, json, pathlib, re, sys
ROOT=pathlib.Path(__file__).resolve().parent
def require(value,message):
    if not value:raise AssertionError(message)
def verify(root=ROOT):
    v=json.loads((root/'VERSION.json').read_text(encoding='utf-8'))
    paths=list((root/'workflows').glob('*.json'))
    require(len(paths)==1 and set(v['workflow_files'])=={p.name for p in paths},'Exactly one four-panel workflow is required')
    required={'ComfyUI-NanoBanana-H3','ComfyUI-MiniMax-H3-Long-Video','ComfyUI-Spectrum-MiniMax-H3','ComfyUI-H3-AudioRefine','ComfyUI-PlagueKind-Nodes'}
    require(set(v['custom_node_packages'])==required,'Version package inventory differs')
    require({p.name for p in (root/'custom_nodes').iterdir() if p.is_dir()}==required,'Custom-node package list differs')
    f=paths[0];d=json.loads(f.read_text(encoding='utf-8'));ns={n['id']:n for n in d['nodes']};links={l[0]:l for l in d['links']}
    require('_v'+v['version']+'.json' in f.name,'Workflow version differs')
    require(ns[124]['widgets_values']==['simple',4,1],'Video steps changed')
    require(ns[123]['widgets_values']==['res_multistep'],'Sampler changed')
    require(ns[160]['widgets_values']==[0.9,'64',8192,0,True,True],'SLA configuration changed')
    require(ns[150]['widgets_values'][13:]==[2,0.5,True,True,False],'Audio steps or duration/audit policy changed')
    require(ns[115]['widgets_values']==['16:9 (Widescreen)',0.4,32],'Resolution default changed')
    require(ns[132]['widgets_values']==[30],'Silent fallback duration changed')
    require(ns[154]['widgets_values'][1] is True,'Reading confirmation removed')
    require(ns[141]['type']=='NanoBananaH3Transform','Image-to-prompt path missing')
    require(not any('LMStudio' in n['type'] or n['type']=='H3StandardPrompt' for n in ns.values()),'LM Studio unexpectedly required')
    models=json.loads((root/'models.json').read_text(encoding='utf-8'))
    for n in ns.values():
        require('widgets_values_named' not in n,'Stale named-widget state remains')
        for slot,i in enumerate(n.get('inputs',[])):
            lid=i.get('link')
            if lid is not None:
                require(lid in links,'Missing link record')
                l=links[lid];require(l[3]==n['id'] and l[4]==slot,'Input socket/link mismatch')
                require(l[1] in ns and l[2]<len(ns[l[1]].get('outputs',[])),'Source socket missing')
        if n['type'] in ('UNETLoader','CLIPLoader','VAELoader'):
            m=next(m for m in models if m['name']==n['widgets_values'][0])
            require(n['properties']['models']==[{k:m[k] for k in ('name','directory','url')}],'Model download metadata mismatch')
        if n['type']=='LoadImage':require(n['widgets_values'][0]=='','Image or private path remains')
    def origin(node_id,name):
        item=next(i for i in ns[node_id]['inputs'] if i['name']==name)
        return links[item['link']][1:3] if item.get('link') is not None else None
    require(origin(150,'prompt')==[154,0],'Reading-reviewed prompt is not connected')
    require(origin(154,'h3_prompt')==[141,1],'H3 authoring path broken')
    require(origin(150,'audio_refine_model')==[127,0],'Clean audio-refine model is not connected')
    require(origin(150,'model')==[160,0],'SLA model is not connected')
    require(any(l[1:3]==[141,0] and l[3]==150 for l in links.values()),'Clean transformed reference not connected')
    for name in ['prose_language.py','candidate_policy.py','identity_contract.py','resume_context.py','visual_repair.py','prosody_policy.py']:
        require((root/'custom_nodes/ComfyUI-NanoBanana-H3'/name).is_file(),'Missing portable dependency: '+name)
    for name in required:require((root/'custom_nodes'/name/'LICENSE').is_file(),'Missing third-party license: '+name)
    long_source=(root/'custom_nodes/ComfyUI-MiniMax-H3-Long-Video/minimax_h3_long_video/nodes.py').read_text(encoding='utf-8')
    require('max_attempts=5' in long_source and long_source.count('not in range(5)')==2,'Five-candidate or resume bounds missing')
    require('max_attempts=3' not in long_source,'Old candidate cap remains')
    for p in root.rglob('*'):
        if not p.is_file():continue
        require('__pycache__' not in p.parts and p.suffix!='.pyc','Runtime cache included')
        require(p.suffix.lower() not in ('.safetensors','.gguf','.mp4','.webm','.wav','.png','.jpg','.jpeg','.pth','.pt','.zip','.log'),'Unexpected model/media/archive: '+str(p.relative_to(root)))
        require('.git' not in p.parts and p.name not in ('.env','pronunciation_dictionary.json'),'Unexpected private file')
        if p.suffix=='.py':ast.parse(p.read_text(encoding='utf-8-sig'),filename=str(p))
        if p.suffix in ('.py','.json','.md','.txt','.js'):
            text=p.read_text(encoding='utf-8-sig')
            require(not re.search(r'sk-[A-Za-z0-9_-]{20,}|AIza[A-Za-z0-9_-]{20,}|/home/[A-Za-z0-9_-]+/|[A-Za-z]:[/\\]+Users[/\\]+[A-Za-z0-9_-]+[/\\]',text),'Private data in '+str(p.relative_to(root)))
    for name in ['README.md','README_JA.md','CHANGELOG.md','VALIDATION.md','REPRODUCE.md']:
        require(v['version'] in (root/name).read_text(encoding='utf-8'),'Current version absent: '+name)
    manifest=root/'SHA256SUMS.json';require(manifest.is_file(),'Missing SHA256SUMS.json')
    hashes=json.loads(manifest.read_text(encoding='utf-8'))
    require(set(hashes)=={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p!=manifest},'Unlisted or missing package files')
    for rel,digest in hashes.items():require(hashlib.sha256((root/rel).read_bytes()).hexdigest()==digest,'Checksum mismatch: '+rel)
    print('Four-panel workflow and all',len(hashes),'file hashes passed.')
if __name__=='__main__':verify(pathlib.Path(sys.argv[1]).resolve() if len(sys.argv)>1 else ROOT)
