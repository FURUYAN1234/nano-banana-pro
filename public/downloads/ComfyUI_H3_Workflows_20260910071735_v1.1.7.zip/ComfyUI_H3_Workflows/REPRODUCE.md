# v1.1.7 タグからの再構築
Python 3とGitを使用します。
```
git clone <ComfyUI_H3_Workflows_20260910071735_v1.1.7_source.bundle> source
cd source
git checkout --detach v1.1.7
python build_release.py ../rebuilt.zip
```
公開予定ZIPとrebuilt.zipのサイズ・SHA256を比較し、双方を新規フォルダーへ展開して全ファイルの相対パス・SHA256を比較します。SHA256SUMS.json自身もZIP間比較に含めます。展開後にverify_package.pyを実行してください。
既存v1.1.5の公開コミットを親履歴に保持します。GitHub/Noteへの公開と公開URLのバイト確認は受領PCで別途実施する工程です。
