# MiniMax H3 四コマ・非LM Studio版 v1.1.7

配布ワークフローは **FourPanel_NonLM_4step_20260910071735_v1.1.7.json の1本**です。以前のT2V・I2V・Ref2Vサンプルは本ZIPの対象ではありません。既存公開履歴と旧版テスト・ソースは対応Gitソースのlegacy_v1_1_5に保持しています。

v1.1.7では、Windowsの既定文字コードがCP932の場合に同梱オフラインテストがUTF-8ソースを読めず失敗する問題と、API通信エラー・エラー応答にキーが含まれる場合の表示を修正しました。APIキーはエラー文から伏せます。生成設定・最大5候補の仕様はv1.1.6から変更していません。以下のGPU生成結果はv1.1.6作成PCからの受領記録であり、今回の修正後にAPI・GPU生成を新たに実施した結果ではありません。

## 同梱内容と導入
`custom_nodes/`内の5フォルダーをComfyUIの`custom_nodes/`へコピーします。
主要3パッケージは NanoBanana-H3、MiniMax-H3-Long-Video、Spectrum-MiniMax-H3。
実行依存の ComfyUI-H3-AudioRefine と ComfyUI-PlagueKind-Nodes も **同梱済み** です。別途取得してパッチを適用する手順はありません。
Spectrumは互換用に同梱しますが、配布ワークフローの4ステップFused＋SLA経路には接続していません。
同名フォルダーの二重導入を避け、更新前の既存フォルダーは退避してください。

1. ZIPを展開し、`python verify_package.py` で同梱内容と全件ハッシュを検査します。
2. 上記5フォルダーを配置し、**ComfyUI自身のPython**で `-m pip install -r 展開先/requirements.txt` を実行します。Windows Portableなら `python_embeded/python.exe`、venvなら `.venv/bin/python` を使います。PyTorchは既存のCUDA対応版を維持してください。
3. H3・ResolutionSelector・ComfyMathExpression・V3ノードAPI対応のComfyUIが必要です。NVIDIA CUDAと、OS/PyTorchに適合するTritonを準備します。Linux/WSLは対応するtriton、Windowsは [triton-windowsの互換表](https://github.com/woct0rdho/triton-windows) に従います。PlagueKindは同梱されていますがTriton本体は同梱していません。
4. FFmpegをPATHから利用可能にします。日本語タイトル・クレジットにはMeiryo/Yu Gothic、またはNoto CJK等の日本語フォントが必要です。
5. 以下の4モデルを取得し、ComfyUIのmodels配下へ配置します。各ローダーのproperties.modelsにも同じ取得先を登録しています。不足モデル画面から取得候補を開けますが、他PCでのその画面操作は未検証です。
6. ComfyUIを再起動し、workflows内のJSONを読み込みます。読み込んだワークフローは既存の動画→MiniMax-H3→四コマの分類配下へ保存してください。
7. 自分の四コマ画像をLoadImageへアップロードします。入力画像は同梱していません。
8. Nano BananaノードでOpenAI APIまたはGoogle Gemini APIを選び、APIキーを登録します。画像変換・文章生成・検査で外部APIを使用します。**LM Studioの起動やローカルLLMモデルは不要**です。
9. キーはComfyUIプロセスのメモリだけに保持し、ZIPやワークフローへ保存しません。再起動後は再登録してください。
10. 実行後に表示される台詞の読みを確認・確定します。個人の発音辞書は同梱せず、受領PCで設定します。
11. 完成動画は `ComfyUI/output/video/MiniMax_H3/`、中間区間・検査結果は `ComfyUI/output/h3_long_video/` に保存されます。

## モデル取得先
- [minimax_h3_fused_refdelta_r1024_turbo8_mystic07_int8_convrot.safetensors](https://huggingface.co/MATLOWAI/minimax-h3-fused-turbo-int8-convrot/resolve/main/diffusion_models/minimax_h3_fused_refdelta_r1024_turbo8_mystic07_int8_convrot.safetensors) → models/diffusion_models/
- [qwen3vl_32b_minimax_h3_nvfp4_awq.safetensors](https://huggingface.co/Comfy-Org/MiniMax-H3/resolve/main/text_encoders/qwen3vl_32b_minimax_h3_nvfp4_awq.safetensors) → models/text_encoders/
- [minimax_h3_video_vae_int8_convrot.safetensors](https://huggingface.co/Kijai/MiniMax-H3-experimental/resolve/main/minimax_h3_video_vae_int8_convrot.safetensors) → models/vae/
- [minimax_h3_audio_vae_fp32.safetensors](https://huggingface.co/Comfy-Org/MiniMax-H3/resolve/main/vae/minimax_h3_audio_vae_fp32.safetensors) → models/vae/
モデル本体・入力画像・完成動画・APIキー・個人辞書はZIPに含みません。モデルの利用条件は各配布元を確認してください。

## 実際の生成設定
- 映像：Fusedモデル、res_multistep、simple **4ステップ**、SLA 0.90、音声保護ON。
- 音声：同じFusedモデルのSLA適用前経路で **2ステップ・強さ0.5**。検査で追加処理前の音声が良い場合はそちらを採用します。
- 画面：16:9、ResolutionSelector 0.4（検証時864×480）、24fps。
- 尺：台詞1本あたり5秒、台詞がなければ30秒。句読点だけの無言反応は発話数へ含めません。
- BGM：H3が生成する低音量のインストゥルメンタル。外部BGMファイルは不要です。
- 参照画像：Nano Bananaが変換した1枚をH3へ渡します。元のコマ割り画像をH3参照へ直接渡しません。
- 台詞を保護して説明文を英語へ整形します。変換が不完全でも使える入力を捨てず続行します。
- 区間の品質不合格は最大5候補（初回込み）を比較し、検査結果上の最良候補を採用して続行します。ユーザーの中断、未登録API、モデル欠落等まで成功扱いにはしません。
- 正常な母音伸長や自然な息継ぎを一律に二重発声と扱いません。人物重複・明らかな外見変更・台詞破綻は品質検査対象です。

## 今回の修正と検証
v1.1.6では説明文の誤発話、候補の上書き、出力区間と継続ガイドの時間不一致、3回目候補の再開拒否、音声選択の記録を修正しました。特定の人物・場面専用の分岐はありません。
日本漫画の吹き出しを位置情報から右→左へ整列する汎用処理を追加しました。元画像のAPI抽出・画像変換から25秒600フレームを生成し、全5区間の採用候補が自動の音声・映像検査に合格しました。採用回は1・1・1・3・1回目です。完成動画の全編デコードと15フレームの目視を実施しました。
完走後、品質候補の上限だけを初回込み5へ増やし、4・5回目の途中再開を含む13件のローカル検査で確認しました。この上限変更後のGPU再生成は省略しています。音声の人手による全編聴取、別PCでの実行、配布ZIPからの新規GPU生成は未検証です。
細部はVALIDATION.md、再構築はREPRODUCE.mdを参照してください。
