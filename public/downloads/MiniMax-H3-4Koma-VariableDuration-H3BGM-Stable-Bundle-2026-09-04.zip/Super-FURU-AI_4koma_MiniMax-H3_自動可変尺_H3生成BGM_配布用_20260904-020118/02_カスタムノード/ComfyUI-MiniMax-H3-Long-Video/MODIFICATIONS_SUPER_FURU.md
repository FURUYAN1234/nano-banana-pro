# Super FURU AI 4-koma System向け改変

Upstream: https://github.com/palealloy2999-prog/ComfyUI-MiniMax-H3-Long-Video

Base commit: `f3fc996068a9319ace1d99d7c6ef54747a4018d2`

License: GPL-3.0-only（元の `LICENSE` を維持）

## 主な改変

- 台詞数に基づく5秒刻み・最大30秒の自動可変尺
- 日本語台詞タグ `<d>[Japanese] ...</d>` の正規化
- 台詞の重複発話、区間またぎ、末尾切れを抑えるタイムライン処理
- 後半区間への不要な台詞再注入と再演を抑えるローカル化
- Audio Refineを含む長尺音声安定化と区間継続処理
- H3生成BGMを区間間で継続させ、台詞を優先するプロンプト処理
- 人数を固定値で決めず、定義済みSubjectから扱う参照整合性処理
- 年月日時分秒によるMP4保存ノード
- 回帰テストの追加

改変済みの対応ソースは本フォルダ内に同梱しています。
