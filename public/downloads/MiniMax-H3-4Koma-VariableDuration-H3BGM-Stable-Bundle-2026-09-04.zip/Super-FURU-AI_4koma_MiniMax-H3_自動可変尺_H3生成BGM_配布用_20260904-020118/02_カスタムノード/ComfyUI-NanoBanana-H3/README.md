# ComfyUI-NanoBanana-H3

`Super FURU AI 4-koma System` 用に作成した、ComfyUI向けの画像変換・H3プロンプト生成・日本語発音確認・固定文字合成ノードです。

## 非公式プロジェクト

本ソフトウェアはコミュニティ製の**非公式**実装です。Google、OpenAI、MiniMax、ComfyUI、Comfy Orgのいずれからも承認、後援、提携を受けていません。Nano Banana、Gemini、OpenAI、MiniMax、ComfyUIなどの名称・商標は各権利者に帰属します。

## 主な機能

- Google Gemini APIまたはOpenAI APIを利用した四コマ素材の画像変換
- MiniMax H3向け動画プロンプトの生成
- H3生成前の日本語原文／発音用テキスト確認とローカル発音辞書
- タイトル、ウォーターマーク、エンドクレジットの決定論的な描画
- APIキーをワークフローJSONへ保存しないセッション内資格情報管理

APIキーはComfyUIサーバープロセスのメモリだけに保持され、ワークフローやディスクには保存しません。詳細は `README_API_SECURITY.md` を参照してください。

## インストール

このフォルダを `ComfyUI/custom_nodes/ComfyUI-NanoBanana-H3` に配置し、ComfyUIを再起動してください。利用する外部APIには、利用者自身の有効なAPIキー、契約、利用料金が必要です。

本リポジトリにモデル重み、APIキー、生成画像、個人用発音辞書は含みません。モデルおよび外部APIは、それぞれの配布元・提供元の規約に従って利用してください。

## ライセンス

このカスタムノード独自のソースコードはMIT Licenseです。`LICENSE` を参照してください。外部サービス、モデル、ComfyUI本体および別カスタムノードには、それぞれ別のライセンス・利用規約が適用されます。
