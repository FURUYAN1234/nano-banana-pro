// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Super FURU AI 4-koma System contributors

import { app } from "../../scripts/app.js";
import { api } from "../../scripts/api.js";

const CREDENTIAL_SLOT = "workflow_api";

function widgetValue(node, name, fallback = "") {
  return node.widgets?.find((widget) => widget.name === name)?.value ?? fallback;
}

async function credentialStatus(provider) {
  const query = new URLSearchParams({provider, slot: CREDENTIAL_SLOT});
  const response = await fetch(`/nanobanana_h3/credential_status?${query}`, {cache: "no-store"});
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || "資格情報の状態を確認できませんでした");
  return result;
}

async function refreshCredentialStatus(node, button) {
  const provider = widgetValue(node, "provider", "OpenAI API");
  button.name = `🔑 ${provider}：確認中…`;
  try {
    const status = await credentialStatus(provider);
    button.name = status.configured
      ? `✅ ${provider} セッション登録済み（画像＋H3共通）`
      : `⚠️ ${provider} APIキー未登録／入力`;
  } catch {
    button.name = `⚠️ ${provider} 状態エラー／開く`;
  }
  node.setDirtyCanvas(true, true);
}

function showCredentialDialog(node, button, {requiredForRun = false} = {}) {
  const provider = widgetValue(node, "provider", "OpenAI API");
  const previous = document.querySelector("[data-nanobanana-h3-credential-dialog]");
  if (previous) {
    previous.__finishCredentialDialog?.(false);
    previous.remove();
  }
  const overlay = document.createElement("div");
  overlay.dataset.nanobananaH3CredentialDialog = "true";
  overlay.style.cssText = "position:fixed;inset:0;z-index:10000;background:#0009;display:flex;align-items:center;justify-content:center";
  const panel = document.createElement("div");
  panel.style.cssText = "width:560px;max-width:92vw;background:#252525;color:#eee;padding:20px;border-radius:10px;font:14px sans-serif";
  panel.innerHTML = `
    <h3 style="margin:0 0 8px">${requiredForRun ? "実行前のAPI設定" : "API設定"}（入力欄は1つ）</h3>
    <p style="margin:0 0 8px;color:#ddd">選択中：<strong>${provider}</strong></p>
    <p style="margin:0 0 8px;color:#bbb">このキーは画像変換とH3プロンプト生成に共通利用します。動作中のComfyUIサーバーのメモリだけに保持され、ファイルやワークフローへ保存されず、ComfyUI終了・再起動で消去されます。</p>
    ${requiredForRun ? '<p style="margin:0 0 14px;color:#ffcc80">認証成功後、保留中の実行を自動的に続けます。閉じると今回の実行を中止します。</p>' : ""}
    <div data-status style="color:#bbb;margin-bottom:8px">状態を確認中…</div>
    <input data-key type="password" autocomplete="off" placeholder="${provider} のAPIキー" style="width:100%;box-sizing:border-box;padding:9px">
    <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:14px">
      <button data-close>${requiredForRun ? "今回の実行を中止" : "閉じる"}</button><button data-save>${requiredForRun ? "認証して実行を続ける" : "認証してこのセッションで使用"}</button>
    </div>`;

  let settled = false;
  let settleDialog;
  const resultPromise = new Promise((resolve) => {
    settleDialog = (configured) => {
      if (settled) return;
      settled = true;
      overlay.remove();
      resolve(configured);
    };
  });
  overlay.__finishCredentialDialog = settleDialog;

  const statusElement = panel.querySelector("[data-status]");
  const setStatus = (configured) => {
    statusElement.textContent = configured ? `✅ ${provider} 登録済み` : `⚠️ ${provider} 未登録`;
    statusElement.style.color = configured ? "#8ee59b" : "#ffcc80";
  };
  const refresh = async () => {
    try {
      setStatus((await credentialStatus(provider)).configured);
    } catch (error) {
      statusElement.textContent = `⚠️ 状態確認エラー: ${error.message}`;
    }
    refreshCredentialStatus(node, button);
  };

  panel.querySelector("[data-close]").onclick = () => settleDialog(false);
  panel.querySelector("[data-save]").onclick = async () => {
    const input = panel.querySelector("[data-key]");
    const saveButton = panel.querySelector("[data-save]");
    const apiKey = input.value.trim();
    if (!apiKey) return;
    saveButton.disabled = true;
    saveButton.textContent = "認証を確認中…";
    try {
      const response = await fetch("/nanobanana_h3/credential", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({provider, slot: CREDENTIAL_SLOT, api_key: apiKey}),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "認証に失敗しました");
      input.value = "";
      setStatus(true);
      settleDialog(true);
    } catch (error) {
      alert(`${provider} を登録できませんでした: ${error.message}`);
    } finally {
      saveButton.disabled = false;
      saveButton.textContent = requiredForRun ? "認証して実行を続ける" : "認証してこのセッションで使用";
      refreshCredentialStatus(node, button);
    }
  };
  overlay.appendChild(panel);
  document.body.appendChild(overlay);
  refresh();
  queueMicrotask(() => panel.querySelector("[data-key]")?.focus());
  return resultPromise;
}

function workflowCredentialNodes() {
  return (app.graph?._nodes || []).filter((node) =>
    node.type === "NanoBananaH3Transform" && node.mode !== 2 && node.mode !== 4
  );
}

async function ensureWorkflowCredentialsForRun() {
  for (const node of workflowCredentialNodes()) {
    const provider = widgetValue(node, "provider", "OpenAI API");
    const button = node.__nanoBananaCredentialButton;
    let status;
    try {
      status = await credentialStatus(provider);
    } catch (error) {
      alert(`${provider} のAPI登録状態を確認できないため、実行を中止しました: ${error.message}`);
      return false;
    }
    if (status.configured) {
      if (button) refreshCredentialStatus(node, button);
      continue;
    }
    if (button) {
      button.name = `⚠️ ${provider} APIキー未登録／実行待機中`;
      node.setDirtyCanvas(true, true);
    }
    const configured = await showCredentialDialog(node, button, {requiredForRun: true});
    if (!configured) return false;
  }
  return true;
}

async function postJson(path, body) {
  const response = await fetch(path, {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify(body),
  });
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || "処理に失敗しました");
  return result;
}

function makeButton(label, onClick) {
  const button = document.createElement("button");
  button.textContent = label;
  button.onclick = onClick;
  button.style.cssText = "padding:9px 14px;border-radius:6px;border:1px solid #666;background:#3b3b3b;color:#fff;cursor:pointer";
  return button;
}

function showDialogueReview(detail) {
  document.querySelector("[data-nanobanana-h3-dialogue-review]")?.remove();
  const overlay = document.createElement("div");
  overlay.dataset.nanobananaH3DialogueReview = "true";
  overlay.style.cssText = "position:fixed;inset:0;z-index:10020;background:#000b;display:flex;align-items:center;justify-content:center;padding:20px";
  const panel = document.createElement("div");
  panel.style.cssText = "width:min(980px,96vw);max-height:92vh;overflow:auto;background:#242424;color:#eee;padding:20px;border-radius:12px;font:14px sans-serif;box-shadow:0 18px 60px #000";

  const title = document.createElement("h2");
  title.textContent = "動画生成前の台詞・読み確認";
  title.style.cssText = "margin:0 0 8px;font-size:21px";
  const note = document.createElement("p");
  note.textContent = "H3動画生成はまだ始まっていません。発音用台詞だけを必要に応じて直し、確定してください。";
  note.style.cssText = "margin:0 0 16px;color:#bfe3ff";
  panel.append(title, note);

  const textareas = [];
  for (const row of detail.dialogues || []) {
    const card = document.createElement("div");
    card.style.cssText = "margin:0 0 12px;padding:12px;border:1px solid #555;border-radius:8px;background:#303030";
    const speaker = document.createElement("div");
    speaker.textContent = `${row.speaker}・台詞 ${Number(row.index) + 1}`;
    speaker.style.cssText = "font-weight:700;color:#ffd180;margin-bottom:6px";
    const originalLabel = document.createElement("div");
    originalLabel.textContent = "原文";
    originalLabel.style.cssText = "font-size:12px;color:#aaa";
    const original = document.createElement("div");
    original.textContent = row.original;
    original.style.cssText = "padding:5px 0 9px;white-space:pre-wrap";
    const readingLabel = document.createElement("div");
    readingLabel.textContent = "発音用台詞（ここを修正）";
    readingLabel.style.cssText = "font-size:12px;color:#8ee59b";
    const reading = document.createElement("textarea");
    reading.value = row.reading;
    reading.rows = Math.max(2, Math.ceil(String(row.reading).length / 54));
    reading.style.cssText = "width:100%;box-sizing:border-box;resize:vertical;margin-top:4px;padding:9px;background:#181818;color:#fff;border:1px solid #6c8;border-radius:6px;font:15px sans-serif;line-height:1.5";
    textareas.push(reading);
    card.append(speaker, originalLabel, original, readingLabel, reading);
    panel.appendChild(card);
  }

  const dictionaryOption = document.createElement("label");
  dictionaryOption.style.cssText = "display:flex;align-items:center;gap:8px;margin:10px 0;color:#ddd";
  const dictionaryCheckbox = document.createElement("input");
  dictionaryCheckbox.type = "checkbox";
  const dictionaryText = document.createElement("span");
  dictionaryText.textContent = "手で修正した行を共通発音辞書へ登録する";
  dictionaryOption.append(dictionaryCheckbox, dictionaryText);
  panel.appendChild(dictionaryOption);

  const status = document.createElement("div");
  status.style.cssText = "min-height:20px;color:#ffcc80;margin:4px 0";
  panel.appendChild(status);
  const controls = document.createElement("div");
  controls.style.cssText = "position:sticky;bottom:-20px;display:flex;justify-content:flex-end;gap:8px;padding:14px 0 2px;background:#242424";
  const cancel = makeButton("今回の生成を中止", async () => {
    cancel.disabled = confirm.disabled = true;
    try {
      await postJson("/nanobanana_h3/dialogue_review/submit", {request_id: detail.request_id, cancelled: true});
      overlay.remove();
    } catch (error) {
      status.textContent = `中止できませんでした: ${error.message}`;
      cancel.disabled = confirm.disabled = false;
    }
  });
  const confirm = makeButton("この読みで動画を生成", async () => {
    const readings = textareas.map((field) => field.value.trim());
    if (readings.some((value) => !value)) {
      status.textContent = "空欄の台詞があります。原文へ戻すか、読みを入力してください。";
      return;
    }
    cancel.disabled = confirm.disabled = true;
    confirm.textContent = "確定して生成を再開中…";
    try {
      const result = await postJson("/nanobanana_h3/dialogue_review/submit", {
        request_id: detail.request_id,
        readings,
        save_changed_to_dictionary: dictionaryCheckbox.checked,
      });
      overlay.remove();
      if (result.saved_count) console.info(`[Nano Banana H3] ${result.saved_count}件を発音辞書へ保存しました。`);
    } catch (error) {
      status.textContent = `確定できませんでした: ${error.message}`;
      cancel.disabled = confirm.disabled = false;
      confirm.textContent = "この読みで動画を生成";
    }
  });
  confirm.style.background = "#176b39";
  controls.append(cancel, confirm);
  panel.appendChild(controls);
  overlay.appendChild(panel);
  document.body.appendChild(overlay);
  textareas[0]?.focus();
}

async function showPronunciationDictionary() {
  const existing = document.querySelector("[data-nanobanana-h3-dictionary-dialog]");
  if (existing) existing.remove();
  const response = await fetch("/nanobanana_h3/pronunciation_dictionary", {cache: "no-store"});
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || "発音辞書を読み込めませんでした");

  const overlay = document.createElement("div");
  overlay.dataset.nanobananaH3DictionaryDialog = "true";
  overlay.style.cssText = "position:fixed;inset:0;z-index:10010;background:#000a;display:flex;align-items:center;justify-content:center;padding:20px";
  const panel = document.createElement("div");
  panel.style.cssText = "width:min(820px,95vw);max-height:90vh;overflow:auto;background:#252525;color:#eee;padding:20px;border-radius:10px;font:14px sans-serif";
  const title = document.createElement("h2");
  title.textContent = "共通発音辞書";
  title.style.margin = "0 0 6px";
  const path = document.createElement("div");
  path.textContent = `保存先: ${data.path}`;
  path.style.cssText = "color:#aaa;font-size:12px;margin-bottom:12px;word-break:break-all";
  const editor = document.createElement("textarea");
  editor.value = Object.entries(data.entries || {}).map(([source, reading]) => `${source}=${reading}`).join("\n");
  editor.rows = 18;
  editor.placeholder = "720本=ななひゃくにじゅっぽん\nAI漫画=エーアイまんが";
  editor.style.cssText = "width:100%;box-sizing:border-box;padding:10px;background:#171717;color:#fff;border:1px solid #666;border-radius:6px;font:14px monospace;line-height:1.5";
  const status = document.createElement("div");
  status.style.cssText = "min-height:20px;color:#ffcc80;margin-top:8px";
  const controls = document.createElement("div");
  controls.style.cssText = "display:flex;justify-content:flex-end;gap:8px;margin-top:8px";
  const close = makeButton("閉じる", () => overlay.remove());
  const save = makeButton("辞書を保存", async () => {
    const entries = {};
    const invalid = [];
    editor.value.split(/\r?\n/).forEach((line, index) => {
      if (!line.trim()) return;
      const separator = line.indexOf("=");
      if (separator < 1) { invalid.push(index + 1); return; }
      const source = line.slice(0, separator).trim();
      const reading = line.slice(separator + 1).trim();
      if (!source || !reading) invalid.push(index + 1);
      else entries[source] = reading;
    });
    if (invalid.length) {
      status.textContent = `${invalid.join(", ")}行目を「原文=読み」の形にしてください。`;
      return;
    }
    save.disabled = true;
    try {
      const result = await postJson("/nanobanana_h3/pronunciation_dictionary", {entries});
      status.textContent = `${result.count}件を保存しました。`;
      status.style.color = "#8ee59b";
    } catch (error) {
      status.textContent = `保存できませんでした: ${error.message}`;
    } finally {
      save.disabled = false;
    }
  });
  save.style.background = "#176b39";
  controls.append(close, save);
  panel.append(title, path, editor, status, controls);
  overlay.appendChild(panel);
  document.body.appendChild(overlay);
}

app.registerExtension({
  name: "local.nanobanana_h3.credentials",
  beforeRegisterNodeDef(nodeType, nodeData) {
    if (nodeData.name === "JapaneseDialoguePronunciationReview") {
      const original = nodeType.prototype.onNodeCreated;
      nodeType.prototype.onNodeCreated = function () {
        original?.apply(this, arguments);
        const dictionaryButton = this.addWidget("button", "📖 共通発音辞書を編集", null, async () => {
          try { await showPronunciationDictionary(); }
          catch (error) { alert(`発音辞書を開けませんでした: ${error.message}`); }
        });
        dictionaryButton.serialize = false;
      };
      return;
    }
    if (nodeData.name !== "NanoBananaH3Transform") return;
    const original = nodeType.prototype.onNodeCreated;
    nodeType.prototype.onNodeCreated = function () {
      original?.apply(this, arguments);
      const button = this.addWidget("button", "🔑 API設定を確認中…", null, () => showCredentialDialog(this, button));
      button.serialize = false;
      this.__nanoBananaCredentialButton = button;
      const copyButton = this.addWidget("button", "📋 H3システム指示をコピー", null, () => copyH3SystemPrompt(copyButton));
      copyButton.serialize = false;
      const dictionaryButton = this.addWidget("button", "📖 共通発音辞書を編集", null, async () => {
        try { await showPronunciationDictionary(); }
        catch (error) { alert(`発音辞書を開けませんでした: ${error.message}`); }
      });
      dictionaryButton.serialize = false;
      refreshCredentialStatus(this, button);
      const previousWidgetChanged = this.onWidgetChanged;
      this.onWidgetChanged = function (name, value, oldValue, widget) {
        previousWidgetChanged?.apply(this, arguments);
        if (name === "provider") {
          refreshCredentialStatus(this, button);
        }
      };
      const previousConfigure = this.onConfigure;
      this.onConfigure = function () {
        previousConfigure?.apply(this, arguments);
        queueMicrotask(() => refreshCredentialStatus(this, button));
      };
    };
  },
  setup() {
    if (!app.__nanoBananaH3DialogueReviewListenerInstalled) {
      api.addEventListener("nanobanana_h3.dialogue_review", ({detail}) => showDialogueReview(detail));
      app.__nanoBananaH3DialogueReviewListenerInstalled = true;
    }
    if (app.__nanoBananaH3ExecutionCredentialGuardInstalled) return;
    const originalQueuePrompt = app.queuePrompt;
    app.queuePrompt = async function () {
      if (!(await ensureWorkflowCredentialsForRun())) return null;
      return await originalQueuePrompt.apply(this, arguments);
    };
    app.__nanoBananaH3ExecutionCredentialGuardInstalled = true;
  },
});

async function copyH3SystemPrompt(button) {
  const response = await fetch("/nanobanana_h3/h3_system_prompt");
  if (!response.ok) throw new Error("汎用システム指示を取得できませんでした");
  await navigator.clipboard.writeText(await response.text());
  const original = button.name;
  button.name = "✅ 汎用システム指示をコピー済み";
  setTimeout(() => { button.name = original; }, 1600);
}
