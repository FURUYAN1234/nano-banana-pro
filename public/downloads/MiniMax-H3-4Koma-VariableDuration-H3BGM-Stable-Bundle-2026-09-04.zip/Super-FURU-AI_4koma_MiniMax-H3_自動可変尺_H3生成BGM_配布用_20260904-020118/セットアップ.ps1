param(
    [Parameter(Mandatory = $true)]
    [string]$ComfyUIPath
)

$ErrorActionPreference = "Stop"
$resolvedComfy = (Resolve-Path -LiteralPath $ComfyUIPath).Path
$mainPy = Join-Path $resolvedComfy "main.py"
$customNodes = Join-Path $resolvedComfy "custom_nodes"

if (-not (Test-Path -LiteralPath $mainPy -PathType Leaf)) {
    throw "ComfyUIのmain.pyが見つかりません: $mainPy"
}
if (-not (Test-Path -LiteralPath $customNodes -PathType Container)) {
    throw "ComfyUIのcustom_nodesフォルダが見つかりません: $customNodes"
}

$sourceRoot = Join-Path $PSScriptRoot "02_カスタムノード"
$packages = @(
    "ComfyUI-NanoBanana-H3",
    "ComfyUI-MiniMax-H3-Long-Video",
    "ComfyUI-Spectrum-MiniMax-H3"
)
$backupRoot = Join-Path $customNodes ("_SuperFURU_backup_" + (Get-Date -Format "yyyyMMdd-HHmmss"))
$customNodesFull = [IO.Path]::GetFullPath($customNodes).TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar

foreach ($package in $packages) {
    $source = Join-Path $sourceRoot $package
    $destination = Join-Path $customNodes $package
    $destinationFull = [IO.Path]::GetFullPath($destination)
    if (-not $destinationFull.StartsWith($customNodesFull, [StringComparison]::OrdinalIgnoreCase)) {
        throw "安全確認に失敗しました: $destinationFull"
    }
    if (-not (Test-Path -LiteralPath $source -PathType Container)) {
        throw "ZIP内のカスタムノードが不足しています: $source"
    }

    if (Test-Path -LiteralPath $destination -PathType Container) {
        New-Item -ItemType Directory -Force -Path $backupRoot | Out-Null
        $backupDestination = Join-Path $backupRoot $package
        Move-Item -LiteralPath $destination -Destination $backupDestination
        Write-Host "Backup: $package -> $backupDestination"
    }

    New-Item -ItemType Directory -Path $destination | Out-Null
    Copy-Item -Path (Join-Path $source "*") -Destination $destination -Recurse -Force
    Write-Host "Installed: $package"
}

Write-Host "導入完了。ComfyUIを起動し直してからワークフローを開いてください。"
if (Test-Path -LiteralPath $backupRoot) {
    Write-Host "旧版バックアップ: $backupRoot"
}
