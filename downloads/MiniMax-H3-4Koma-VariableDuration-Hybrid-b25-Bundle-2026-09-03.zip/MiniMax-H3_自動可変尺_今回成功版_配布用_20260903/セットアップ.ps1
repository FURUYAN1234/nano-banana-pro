param(
    [Parameter(Mandatory = $true)]
    [string]$ComfyUIPath
)

$ErrorActionPreference = "Stop"
$resolvedComfy = (Resolve-Path -LiteralPath $ComfyUIPath).Path
$mainPy = Join-Path $resolvedComfy "main.py"
$customNodes = Join-Path $resolvedComfy "custom_nodes"

if (-not (Test-Path -LiteralPath $mainPy -PathType Leaf)) {
    throw "ComfyUIのmain.pyが見つかりません: $mainPy"
}
if (-not (Test-Path -LiteralPath $customNodes -PathType Container)) {
    throw "ComfyUIのcustom_nodesフォルダが見つかりません: $customNodes"
}

$sourceRoot = Join-Path $PSScriptRoot "02_カスタムノード"
$packages = @(
    "ComfyUI-NanoBanana-H3",
    "ComfyUI-MiniMax-H3-Long-Video",
    "ComfyUI-Spectrum-MiniMax-H3"
)

foreach ($package in $packages) {
    $source = Join-Path $sourceRoot $package
    $destination = Join-Path $customNodes $package
    if (-not (Test-Path -LiteralPath $source -PathType Container)) {
        throw "ZIP内のカスタムノードが不足しています: $source"
    }
    New-Item -ItemType Directory -Force -Path $destination | Out-Null
    Copy-Item -Path (Join-Path $source "*") -Destination $destination -Recurse -Force
    Write-Host "Installed: $package"
}

Write-Host "導入完了。ComfyUIを起動し直してからワークフローを開いてください。"
