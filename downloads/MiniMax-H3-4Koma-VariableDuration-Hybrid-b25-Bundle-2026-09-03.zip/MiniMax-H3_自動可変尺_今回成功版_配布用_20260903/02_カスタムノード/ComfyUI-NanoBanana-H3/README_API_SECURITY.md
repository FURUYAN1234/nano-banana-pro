# API credential contract

- API keys are held only in the running ComfyUI server process memory.
- Keys are never serialized into workflow JSON and are never written to disk.
- Switching workflow tabs in the same ComfyUI process preserves registration.
- Stopping or restarting ComfyUI erases every registered key.
- Loading a workflow never opens the credential dialog automatically.
- When the user presses ComfyUI's Execute/Queue button, the node checks its currently selected provider before queue submission. If that provider is not registered, the node opens its credential dialog and pauses the run. Successful verification resumes that same run automatically; closing the dialog cancels only that run.
- The browser sends a key to the connected local ComfyUI server only for authentication or execution; the server then sends it only to the selected provider.
- Status labels and API responses expose only a boolean registration state, never the key or a key fragment.

Do not add credential files, persistent browser storage, logging, masking previews, or workflow widgets that contain key material.
