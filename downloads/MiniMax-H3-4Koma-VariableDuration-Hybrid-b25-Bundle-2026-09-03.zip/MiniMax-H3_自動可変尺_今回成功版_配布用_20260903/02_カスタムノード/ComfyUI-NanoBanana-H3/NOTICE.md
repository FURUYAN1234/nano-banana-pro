# ComfyUI-NanoBanana-H3 notice

Copyright (c) 2026 ComfyUI-NanoBanana-H3 contributors.

The original source files in this directory are licensed under GPL-3.0-or-later; see `LICENSE`.

This notice does not grant rights to ComfyUI, the separately bundled third-party custom nodes, model weights, OpenAI or Google services, user-supplied input, or generated output. Those materials remain governed by their own terms.
