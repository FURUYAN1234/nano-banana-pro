# Four-panel v5.9.7 validation

API source extraction and prompt generation completed earlier in this task. Subject IDs and right-to-left balloon order were verified. The final GPU resume run was `4c34145c-1299-47a6-a777-7e9a1b405dac`, completed 2026-09-10 JST, 25 seconds, 864x480,24fps, audio present. Full FFmpeg decode passed.

Segments1-3 were preserved from the preceding run; segments4-5 were regenerated. Selected attempts:1,2,1,1,2. Audio audit passed for all retained candidates. Segments1,2,4 passed audiovisual audits. Segments3,5 retained speaker-only failures after bounded retries, explicitly accepted under the user fallback policy. Do not describe all five as speaker-correct. Inspected selected frame sheets showed no obvious duplicate main bodies or major hairstyle replacement in those samples. Human full-length listening and exhaustive frame-by-frame visual review were not performed.

The generic candidate-selection correction passed six new priority tests and the complete29-test Long-Video suite. Earlier NanoBanana48 tests passed. Windows CP932 checks were performed earlier for portable text I/O and redaction; the newly packaged tests are checked again as reported in RELEASE_CHECKS. Local tests are not another-PC ComfyUI execution.

ZIP extraction, verify_package.py, exact manifest membership and hashes, clean-tag rebuild ZIP byte equality and extracted-file equality are recorded in the companion RELEASE_CHECKS.json. No model, credential, personal pronunciation dictionary, input image or validation video is distributed. Another-PC execution and fresh GPU generation from the ZIP are unverified. GitHub/Note publication is not performed by this build.
