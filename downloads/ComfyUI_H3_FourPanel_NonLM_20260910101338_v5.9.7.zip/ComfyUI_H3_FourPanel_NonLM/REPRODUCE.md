# Four-panel v5.9.7 reproducible source
```
git clone ComfyUI_H3_FourPanel_NonLM_20260910101338_v5.9.7_source.bundle source
cd source
git checkout --detach fourpanel-v5.9.7
python build_release.py ../rebuilt.zip
```
Compare ZIP sizes and SHA256, then extract both ZIPs into fresh directories and compare every relative path and SHA256 (including SHA256SUMS.json). Run verify_package.py on each extracted root. Existing public ancestry and development tests/documents are preserved. This namespaced tag is for the four-panel product only. GitHub/Note publication is a separate operation.
