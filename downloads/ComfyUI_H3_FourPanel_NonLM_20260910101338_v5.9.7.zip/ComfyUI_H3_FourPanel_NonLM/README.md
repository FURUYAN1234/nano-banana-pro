# MiniMax H3 Four-panel non-LM Studio release v5.9.7

This release contains one workflow: `FourPanel_NonLM_4step_20260910101338_v5.9.7.json`. It uses the selected cloud API for image transformation, H3 prompt authoring and auditing; LM Studio is not required.

Copy all five folders from `custom_nodes/` into ComfyUI's `custom_nodes/`:
- ComfyUI-NanoBanana-H3
- ComfyUI-MiniMax-H3-Long-Video
- ComfyUI-Spectrum-MiniMax-H3 (included for compatibility; not connected in the Fused4 workflow)
- ComfyUI-H3-AudioRefine (bundled runtime dependency)
- ComfyUI-PlagueKind-Nodes (bundled SLA dependency)

All five are included; do not separately download and patch them. Install requirements using ComfyUI's Python. Use a CUDA/H3-compatible ComfyUI and OS/PyTorch-compatible Triton (triton-windows on Windows), FFmpeg on PATH and a Japanese font. Download the four models listed in models.json into their specified models directories.

Run verify_package.py after extraction. Load the workflow, supply your own four-panel image, register the selected API key in the node and confirm dialogue readings. API keys remain only in process memory and must be re-entered after restart. No model weights, user images/videos, credentials or personal pronunciation dictionary are included.

Video: Fused4 + SLA, 4 steps, 24fps, 16:9. Audio: 2 refinement steps at 0.5, with original/refined candidate comparison. Duration: five seconds per spoken turn, 30-second fallback without dialogue. H3 generates quiet instrumental BGM. Completed files are saved in ComfyUI/output/video/MiniMax_H3; checkpoints are in output/h3_long_video.

Quality checks compare at most five candidates, including the initial attempt. An earlier passing candidate proceeds immediately; if all five fail, the best inspected candidate is retained and generation continues. Protected dialogue is never rewritten by prose translation. Interruptions and unavailable required inputs are not reported as successful generation.

Version 5.9.7 preserves paired subject/speaker identities and audits nearby frames. After five failed candidates, clean dialogue with a speaker-only mismatch outranks broken dialogue; identity duplication retains its full penalty. The verified 25-second GPU run reused the first three segments and regenerated the last two. All selected audio audits passed; segments 3 and 5 retain speaker mismatches accepted under the specified fallback policy. Full decoding passed and selected frame samples were inspected. Full human audio listening, another-PC execution and fresh GPU execution from this ZIP remain unverified.

See [the version correction and apology](VERSION_CORRECTION_JA.md). This four-panel product follows the user-reported 5.9.6 baseline as 5.9.7 and is separate from the T2V/I2V/Ref2V service. See VALIDATION.md for evidence and limits.
