import ast, json, os, pathlib, unittest
SOURCE = pathlib.Path(os.environ.get("H3_RANK_SOURCE", str(pathlib.Path(__file__).resolve().parents[1] / "minimax_h3_long_video/nodes.py")))
ns={"json":json}
fn=next(n for n in ast.parse(SOURCE.read_text(encoding="utf-8")).body if isinstance(n,ast.FunctionDef) and n.name=="_candidate_quality_rank")
exec(compile(ast.Module(body=[fn],type_ignores=[]),str(SOURCE),"exec"),ns)
rank=ns["_candidate_quality_rank"]
def av(audio="pass", visual="pass"):
 return "fail: audiovisual: "+json.dumps({"audio":audio,"visual":visual})
def visual(issues=None,status="fail"):
 return "fail 0:"+json.dumps({"first":{"issues":issues or [],"speaker_check":{"status":status}},"recheck":{"issues":issues or [],"speaker_check":{"status":status}}})
class PriorityTests(unittest.TestCase):
 def test_speaker_fallback_beats_broken_audio(self):
  for kind in ["repeated_speech","overlapping_speech","changed_words","missing_speech"]:
   with self.subTest(kind=kind):
    bad='fail: dialogue audio: '+json.dumps({"issues":[{"kind":kind}]})
    self.assertLess(rank(True,av(visual=visual())),rank(True,av(audio=bad)))
 def test_full_pass_beats_fallback(self):
  self.assertLess(rank(False,"pass"),rank(True,av(visual=visual())))
 def test_duplication_not_relaxed(self):
  self.assertGreater(rank(True,av(visual=visual([{"type":"identity_duplication"}]))),rank(True,av(visual=visual())))
 def test_unknown_and_malformed_not_speaker_only(self):
  for v in ["unavailable: timeout","fail 0:{oops}","fail 0:{}",'fail 0:{"issues":[]}']:
   self.assertGreater(rank(True,av(visual=v)),rank(True,av(visual=visual())))
 def test_recheck_identity_failure_not_relaxed(self):
  v='fail 0:'+json.dumps({"first":{"issues":[],"speaker_check":{"status":"fail"}},"recheck":{"issues":[{"description":"duplicate body"}],"speaker_check":{"status":"fail"}}})
  self.assertGreater(rank(True,av(visual=v)),rank(True,av(visual=visual())))
 def test_observation_uncertainty_keeps_fallback_available(self):
  self.assertEqual(rank(True,av(visual=visual(status="not_observable"))), (1,1))
if __name__=="__main__":unittest.main()
