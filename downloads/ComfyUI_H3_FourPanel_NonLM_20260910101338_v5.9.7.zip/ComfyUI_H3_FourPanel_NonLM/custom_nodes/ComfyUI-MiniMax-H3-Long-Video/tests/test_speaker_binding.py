# SPDX-License-Identifier: MIT
"""Offline speaker binding and adjacent-frame sampling regressions."""
import ast,importlib.util,pathlib,sys,unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('h3_speaker_timeline',ROOT/'minimax_h3_long_video/timeline.py')
t=importlib.util.module_from_spec(spec);sys.modules[spec.name]=t;spec.loader.exec_module(t)
class BindingTests(unittest.TestCase):
    def test_distinct_namespaces_resolve_explicit_definition(self):
        prompt='subject_definitions:\n<Subject 9> (S2): a robot.\n<Subject 2> (S8): a bird.\nsummary: task'
        mapping=t._speaker_bindings(prompt)
        self.assertEqual(t._nearest_dialogue_identity('<Subject 2> watches. (S2)',mapping),(9,2))
    def test_duplicate_speaker_definition_does_not_invent_owner(self):
        mapping=t._speaker_bindings('<Subject 1> (S2): person\n<Subject 3> (S2): person')
        self.assertEqual(t._nearest_dialogue_identity('(S2)',mapping),(None,2))
    def test_unmapped_speaker_is_preserved_without_same_number_assumption(self):
        self.assertEqual(t._nearest_dialogue_identity('(S7)',{}),(None,7))
    def test_subject_only_uses_unique_reverse_binding(self):
        self.assertEqual(t._nearest_dialogue_identity('<Subject 9> says,',{2:9}),(9,2))
    def test_spread_retains_both_labels_after_other_character_mentions(self):
        rows=t._spread_one_dialogue_per_segment([(1,0,'<Subject 4> watches. (S7) <d>[English] Hello.</d>')],1,5,{7:2})
        self.assertIn('<Subject 2> (S7) is the only moving mouth',rows[0][2])
    def test_speech_first_retains_pair_text_and_clock(self):
        text='[Shot 1] At 00:01.625, <Subject 4> watches. (S7) <d>[English] Hello.</d>'
        out=t._prioritize_local_dialogue(text,4.5,1.625,{7:2})
        self.assertIn('<Subject 2> (S7) begins',out)
        self.assertIn('00:01.775',out)
        self.assertEqual(out.count('<d>[English] Hello.</d>'),1)
    def test_full_slice_keeps_speaker_pair_for_each_turn(self):
        prompt='subject_definitions:\n<Subject 1> (S2): short hair, dark coat.\n<Subject 2> (S8): long hair, light coat.\nsummary: task\ndetailed_description:\n[Shot 1] <Subject 2> watches. (S2) <d>[English] First.</d>\n[Shot 2] At 00:05.000, <Subject 1> watches. (S8) <d>[English] Next.</d>\noverall_soundscape: quiet\nnon_diegetic_music: N/A'
        for i,(subject,speaker,words) in enumerate([(1,2,'First.'),(2,8,'Next.')]):
            out=t.slice_prompt(prompt,i*5,(i+1)*5,context_seconds=1.625 if i else 0,segment_index=i,segment_count=2,timeline_duration_seconds=10)
            self.assertIn(f'<Subject {subject}> (S{speaker}) begins',out)
            self.assertEqual(out.count('<d>'),1)
            self.assertIn(words,out)
    def test_offscreen_speech_is_not_forced_onscreen(self):
        rows=t._spread_one_dialogue_per_segment(
            [(1,0,'Off-screen (S7) says, <d>[English] Hello.</d>')],1,5,{7:2})
        out=t._prioritize_local_dialogue('[Shot 1] '+rows[0][2],4.5,0,{7:2})
        self.assertIn('off-screen <Subject 2> (S7) begins',out)
        self.assertNotIn('only moving mouth',out)
        self.assertNotIn('remain clearly identifiable',out)
        self.assertEqual(out.count('<d>'),1)
    def test_preserve_input_single_segment_unchanged(self):
        prompt='[Shot 1] Voice (S7) <d>[English] Original.</d>'
        self.assertEqual(t.slice_prompt(prompt,0,5,segment_count=1,preserve_input_prompt=True),prompt)

class ProbeTests(unittest.TestCase):
    def test_six_ordered_offsets_stay_in_delivered_speech_window(self):
        tree=ast.parse((ROOT/'minimax_h3_long_video/nodes.py').read_text(encoding='utf-8'))
        fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='_speaker_probe_offsets');ns={}
        exec(compile(ast.Module(body=[fn],type_ignores=[]),'offsets','exec'),ns)
        for duration in [.1,.5,.6,1,1.5,2,3,5,10]:
            offsets=ns['_speaker_probe_offsets'](duration)
            self.assertEqual(len(offsets),6)
            self.assertTrue(all(0<=x<=max(0,duration-.5) for x in offsets))
            self.assertEqual(list(offsets), sorted(offsets))
if __name__=='__main__':unittest.main()
