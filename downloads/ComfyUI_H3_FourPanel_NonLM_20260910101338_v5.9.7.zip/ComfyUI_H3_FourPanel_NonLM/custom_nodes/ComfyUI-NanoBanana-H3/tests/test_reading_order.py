# SPDX-License-Identifier: MIT
"""Offline tests: no provider credentials, image uploads or inference."""
import importlib.util
import pathlib
import unittest
import copy
ROOT=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('reading_contract',ROOT/'identity_contract.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
def row(text,box,panel=1,entity='E1'):
    return dict(text=text,balloon_bbox=box,panel=panel,entity_id=entity,evidence='visible balloon tail')
def inventory(rows):
    return dict(entities=[dict(id='E1',kind='human',appearance='coat',hair='short',appendages='none',evidence='source',panels=[1,2])],background='',uncertainties=[],dialogues=rows)
class ReadingOrder(unittest.TestCase):
    def test_reverses_left_first_without_changing_text_or_owner(self):
        rows=[row('left',[.1,.1,.3,.3]),row('right',[.7,.1,.9,.3])]
        source=inventory(rows); result=c.validate_inventory(source)
        self.assertEqual(result['dialogues'],list(reversed(rows)))
        self.assertEqual(source['dialogues'],rows)
    def test_correct_order_unchanged(self):
        rows=[row('right',[.7,.1,.9,.3]),row('left',[.1,.1,.3,.3])]
        self.assertEqual(c.validate_inventory(inventory(rows))['dialogues'],rows)
    def test_panel_priority_before_horizontal_position(self):
        rows=[row('second',[.7,.1,.9,.3],2),row('first',[.1,.1,.3,.3],1)]
        self.assertEqual([r['text'] for r in c.validate_inventory(inventory(rows))['dialogues']],['first','second'])
    def test_vertical_column_reads_top_first_despite_minor_x_difference(self):
        rows=[row('bottom',[.71,.6,.91,.8]),row('top',[.7,.1,.9,.3])]
        self.assertEqual([r['text'] for r in c.validate_inventory(inventory(rows))['dialogues']],['top','bottom'])
    def test_missing_bad_or_nan_geometry_retains_candidate(self):
        for box in [None,[],[0,0,0,0],[False,0,1,1],[float('nan'),0,1,1]]:
            source=inventory([row('first',box),row('second',[.7,.1,.9,.3])])
            self.assertEqual(c.validate_inventory(source)['dialogues'],source['dialogues'])
            self.assertEqual(c.inventory_order_rank(source),1)
    def test_empty_silent_source(self):
        self.assertEqual(c.validate_inventory(inventory([]))['dialogues'],[])
    def test_recheck_failure_keeps_draft(self):
        draft=inventory([row('text',[.7,.1,.9,.3])])
        self.assertEqual(c.best_order_inventory(draft,None),draft)
    def test_later_degraded_candidate_does_not_win(self):
        draft=inventory([row('text',[.7,.1,.9,.3])])
        for checked in [inventory([]),inventory([row('text',None)])]:
            self.assertEqual(c.best_order_inventory(draft,checked),draft)
    def test_recheck_with_positions_wins(self):
        draft=inventory([row('text',None)]);checked=inventory([row('text',[.7,.1,.9,.3])])
        self.assertEqual(c.best_order_inventory(draft,checked),checked)
    def test_contract_uses_geometric_order(self):
        source=inventory([row('LEFT_TEXT',[.1,.1,.3,.3]),row('RIGHT_TEXT',[.7,.1,.9,.3])])
        result=c.contract_text(source,True)
        self.assertLess(result.index('RIGHT_TEXT'),result.index('LEFT_TEXT'))
    def test_shots_follow_geometry_with_action_and_speaker_intact(self):
        source=inventory([row('left',[.1,.1,.3,.3]),row('right',[.7,.1,.9,.3])])
        prompt='[Shot 1]\nleft action (S1) <d>left</d>\n[Shot 2] At 00:05.000,\nright action (S1) <d>right</d>\noverall_soundscape: quiet'
        result=c.align_dialogue_shots(prompt,source)
        self.assertLess(result.index('right action'),result.index('left action'))
        self.assertIn('[Shot 2] At 00:05.000,',result)

class InventoryIntegration(unittest.TestCase):
    def run_source(self,checked,cache=None):
        import ast,hashlib,json
        tree=ast.parse((ROOT/'__init__.py').read_text(encoding='utf-8'))
        fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='_source_inventory')
        calls=[]
        draft=inventory([row('left',[.1,.1,.3,.3]),row('right',[.7,.1,.9,.3])])
        def request(*args):
            calls.append(args)
            if len(calls)==1:return c.validate_inventory(draft)
            if isinstance(checked,Exception):raise checked
            return c.validate_inventory(checked)
        def advisory(operation,fallback):
            try:return operation()
            except ValueError:return fallback
        ns=dict(hashlib=hashlib,json=json,IDENTITY_REVISION=c.REVISION,
                INVENTORY_INSTRUCTION=c.INVENTORY_INSTRUCTION,
                _SOURCE_INVENTORY_CACHE=cache if cache is not None else {},
                _tensor_to_png_base64=lambda image:'mock-image',
                _source_inspection_images=lambda image:['mock-image'],
                _validated_inventory_request=request,_advisory_check=advisory,
                best_order_inventory=c.best_order_inventory,inventory_order_rank=c.inventory_order_rank)
        exec(compile(ast.Module(body=[fn],type_ignores=[]),'source-inventory-test','exec'),ns)
        return ns['_source_inventory']('mock','',None),calls,ns
    def test_failed_recheck_keeps_geometrically_ordered_draft(self):
        result,calls,ns=self.run_source(ValueError('mock failure'))
        self.assertEqual([r['text'] for r in result['dialogues']],['right','left'])
        self.assertEqual(len(calls),2)
    def test_degraded_recheck_keeps_draft_and_cache_avoids_extra_requests(self):
        result,calls,ns=self.run_source(inventory([]))
        self.assertEqual(len(result['dialogues']),2)
        self.assertEqual(ns['_source_inventory']('mock','',None),result)
        self.assertEqual(len(calls),2)
    def test_old_revision_cache_not_reused(self):
        import hashlib
        old={('mock','source-identity-v15-prop-scope',hashlib.sha256(b'mock-image').hexdigest()):inventory([])}
        result,calls,ns=self.run_source(inventory([]),old)
        self.assertEqual(len(calls),2)
        self.assertEqual(len(result['dialogues']),2)

if __name__=='__main__':unittest.main()
