# SPDX-License-Identifier: MIT
import ast,importlib.util,pathlib,unittest,copy
ROOT=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('h3_speaker_audit',ROOT/'speaker_audit.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
PROMPT='subject_definitions:\n<Subject 9> (S2): a short-haired person.\n<Subject 2> (S7): a long-haired person.\nsummary: scene\ndetailed_description:\n[Shot 1] <Subject 9> (S2) says, <d>[English] Hello.</d>'
EXPECTED={'subject_id':9,'speaker_id':'S2'}
def passing():
    return {'pass':True,'speaker_check':{'status':'pass','expected_subject_id':9,'expected_speaker_id':'S2','observed_speaking_subject_ids':[9],'extra_speaking_subject_ids':[],'evidence':[{'subject_id':9,'frame_indices':[1,2],'observation':'Jaw and lips change between paired frames while others remain still.'}]}}
class SpeakerAuditTests(unittest.TestCase):
    def test_expected_owner_from_explicit_pair(self):self.assertEqual(a.speech_expectation(PROMPT),EXPECTED)
    def test_bare_speaker_resolves_definition(self):self.assertEqual(a.speech_expectation(PROMPT.replace('<Subject 9> (S2) says','(S2) says')),EXPECTED)
    def test_no_dialogue_and_offscreen_not_forced_visible(self):
        self.assertIsNone(a.speech_expectation(PROMPT.replace('<d>[English] Hello.</d>','silent reaction')))
        self.assertIsNone(a.speech_expectation(PROMPT.replace('says,','speaks off-screen,')))
    def test_spoken_words_and_identity_pass_alone_are_insufficient(self):self.assertFalse(a.speaker_check_passes({'pass':True},EXPECTED,6))
    def test_paired_articulation_passes(self):self.assertTrue(a.speaker_check_passes(passing(),EXPECTED,6))
    def test_wrong_or_extra_speaker_fails(self):
        for ids in [[2],[9,2],[],[True]]:
            r=passing();r['speaker_check']['observed_speaking_subject_ids']=ids
            self.assertFalse(a.speaker_check_passes(r,EXPECTED,6))
    def test_unobserved_or_unrelated_evidence_not_pass(self):
        for changes in [{'status':'not_observable'},{'evidence':[]},{'expected_subject_id':2},{'expected_speaker_id':'S7'},{'extra_speaking_subject_ids':[2]}]:
            r=passing();r['speaker_check'].update(changes);self.assertFalse(a.speaker_check_passes(r,EXPECTED,6))
    def test_single_frame_or_out_of_range_cannot_prove_motion(self):
        for indices in [[1],[1,1],[0,2],[1,7],[True,2]]:
            r=passing();r['speaker_check']['evidence'][0]['frame_indices']=indices
            self.assertFalse(a.speaker_check_passes(r,EXPECTED,6))
    def test_silent_source_uses_existing_identity_gate(self):self.assertTrue(a.speaker_check_passes({'pass':True},None,6))
    def test_instruction_distinguishes_reaction_from_speech(self):
        prompt=a.speaker_audit_instruction(EXPECTED,6)
        self.assertIn('single open mouth',prompt);self.assertIn('not_observable',prompt);self.assertIn('<Subject 9> (S2)',prompt)


class ProductionAuditTests(unittest.TestCase):
    """Run the production adapter on CPU with a fake provider response."""
    @classmethod
    def setUpClass(cls):
        import json, re, torch
        cls.torch = torch
        tree = ast.parse((ROOT/'__init__.py').read_text(encoding='utf-8'))
        frames = next(n for n in tree.body if isinstance(n, ast.FunctionDef)
                      and n.name == '_video_identity_frames')
        owner = next(n for n in tree.body if isinstance(n, ast.ClassDef)
                     and n.name == 'NanoBananaH3Transform')
        audit = next(n for n in owner.body if isinstance(n, ast.FunctionDef)
                     and n.name == 'audit_video_segment')
        audit.decorator_list = []
        cls.ns = {'json': json, 're': re, '_credential': lambda provider: 'offline-stub',
                  'parse_json': json.loads, 'speech_expectation': a.speech_expectation,
                  'speaker_audit_instruction': a.speaker_audit_instruction,
                  'speaker_check_passes': a.speaker_check_passes}
        exec(compile(ast.Module(body=[frames, audit], type_ignores=[]),
                     'production-adapter', 'exec'), cls.ns)

    def run_audit(self, responses, prompt=PROMPT):
        import json
        from unittest.mock import Mock
        request = Mock(side_effect=[json.dumps(r) for r in responses])
        self.ns['_identity_text_request'] = request
        frames = self.torch.zeros((6, 8, 8, 3))
        passed, detail = self.ns['audit_video_segment']('offline', [frames[:1]], frames, prompt)
        return passed, json.loads(detail), request

    def test_production_rejects_identity_only_even_when_provider_says_pass(self):
        r = {'pass': True, 'frames_checked': 6, 'issues': []}
        passed, detail, request = self.run_audit([r, r])
        self.assertFalse(passed)
        self.assertEqual(request.call_count, 2)
        self.assertIn('speaker_check', request.call_args_list[0].args[2])
        self.assertEqual(len(request.call_args_list[0].args[3]), 7)

    def test_production_accepts_valid_speaker_evidence_and_stops_recheck(self):
        r = passing(); r.update(frames_checked=6, issues=[])
        passed, detail, request = self.run_audit([r])
        self.assertTrue(passed)
        self.assertEqual(request.call_count, 1)

    def test_production_independent_recheck_can_recover_false_rejection(self):
        bad = passing(); bad.update(frames_checked=6, issues=[])
        bad['speaker_check']['observed_speaking_subject_ids'] = [2]
        good = passing(); good.update(frames_checked=6, issues=[])
        passed, detail, request = self.run_audit([bad, good])
        self.assertTrue(passed)
        self.assertEqual(request.call_count, 2)
        self.assertNotIn('observed_speaking_subject_ids: [2]', request.call_args_list[1].args[2])

    def test_silent_segment_does_not_require_speaker_check(self):
        r = {'pass': True, 'frames_checked': 6, 'issues': []}
        passed, detail, request = self.run_audit([r], PROMPT.replace('<d>[English] Hello.</d>', 'silent'))
        self.assertTrue(passed)

    def test_actual_frame_batch_and_legacy_grid_remain_supported(self):
        batch = self.torch.arange(6*8*8*3).reshape(6,8,8,3)
        frames = self.ns['_video_identity_frames'](batch)
        self.assertEqual(len(frames), 6)
        self.assertTrue(all(self.torch.equal(frame, batch[i:i+1]) for i,frame in enumerate(frames)))
        legacy = self.ns['_video_identity_frames'](self.torch.zeros((1,16,16,3)))
        self.assertEqual(len(legacy), 3)
        self.assertTrue(all(tuple(frame.shape) == (1,8,8,3) for frame in legacy))

if __name__=='__main__':unittest.main()
