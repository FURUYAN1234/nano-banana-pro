# SPDX-License-Identifier: MIT
"""Prevent locale-dependent reads from returning to distributed tests."""
import ast
import pathlib
import unittest

class PortableTests(unittest.TestCase):
    def test_distributed_tests_explicitly_select_text_encoding(self):
        packages = pathlib.Path(__file__).resolve().parents[2]
        checked = 0
        for name in ("ComfyUI-NanoBanana-H3", "ComfyUI-MiniMax-H3-Long-Video"):
            folder = packages/name/"tests"
            for path in folder.glob("*.py"):
                checked += 1
                tree = ast.parse(path.read_text(encoding="utf-8"))
                for node in ast.walk(tree):
                    if (isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
                            and node.func.attr in ("read_text", "write_text")):
                        self.assertTrue(any(k.arg == "encoding" for k in node.keywords),
                                        str(path.name)+":"+str(node.lineno)+" lacks explicit encoding")
        self.assertGreater(checked, 0)

if __name__ == "__main__":
    unittest.main()
