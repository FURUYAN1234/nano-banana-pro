# SPDX-License-Identifier: MIT
"""No-network checks for error paths; credentials are synthetic test values."""
import ast
import pathlib
import re
import traceback
import types
import unittest
from unittest.mock import Mock

ROOT = pathlib.Path(__file__).resolve().parents[1]

class ProviderErrorTests(unittest.TestCase):
    def setUp(self):
        source = ast.parse((ROOT / "__init__.py").read_text(encoding="utf-8"))
        names = {"_safe_provider_error", "_openai_chat_request", "_openai_image_edit",
                 "_request", "_h3_llm_request"}
        functions = [n for n in source.body if isinstance(n, ast.FunctionDef) and n.name in names]
        class RequestFailure(Exception):
            pass
        self.requests = types.SimpleNamespace(RequestException=RequestFailure, post=Mock(), get=Mock())
        self.ns = {"re": re, "requests": self.requests,
                   "_sanitize_api_key": lambda provider, key: key,
                   "_tensor_to_png_bytes": lambda image: b"offline-image",
                   "_H3_LLM_SYSTEM": "offline", "AUTHORING_LANGUAGE": "",
                   "_normalize_h3_prose": lambda provider, key, text: text,
                   "_response_text": lambda payload: payload["text"]}
        module = ast.Module(body=[ast.ImportFrom(module="__future__",
                            names=[ast.alias(name="annotations")], level=0)] + functions, type_ignores=[])
        exec(compile(ast.fix_missing_locations(module), "provider-error-functions", "exec"), self.ns)
        # Short invalid values cannot be mistaken for credentials or shipped model settings.
        self.key = "sk-FAKE-UNIT-TEST-ONLY"

    def routes(self):
        return {
            "openai_text": lambda: self.ns["_openai_chat_request"](self.key, "system", "text"),
            "openai_image": lambda: self.ns["_openai_image_edit"](self.key, None, "text"),
            "gemini_image": lambda: self.ns["_request"]("Google Gemini API", self.key, "offline", {}),
            "gemini_h3": lambda: self.ns["_h3_llm_request"]("Google Gemini API", self.key, "offline", "text", 0),
        }

    def test_all_four_transport_errors_hide_key_and_original_chain(self):
        for name, route in self.routes().items():
            with self.subTest(route=name):
                self.requests.post.side_effect = self.requests.RequestException(
                    "offline failure https://example.invalid/?key=" + self.key)
                try:
                    route()
                except RuntimeError as error:
                    rendered = "".join(traceback.TracebackException.from_exception(error).format())
                    self.assertNotIn(self.key, rendered)
                    self.assertIn("[REDACTED]", str(error))
                    self.assertTrue(error.__suppress_context__)
                else:
                    self.fail("Expected synthetic transport failure")

    def test_all_four_http_errors_hide_echoed_key_and_keep_status(self):
        for name, route in self.routes().items():
            with self.subTest(route=name):
                self.requests.post.return_value = types.SimpleNamespace(
                    ok=False, status_code=403, text="Forbidden credential " + self.key)
                with self.assertRaises(RuntimeError) as caught:
                    route()
                self.assertNotIn(self.key, str(caught.exception))
                self.assertIn("403", str(caught.exception))

    def test_url_and_provider_key_patterns_are_hidden(self):
        message = "403 ?key=not-a-real-credential&retry=no AIzaFAKEONLY sk-FAKEONLY"
        out = self.ns["_safe_provider_error"](message, "")
        self.assertNotIn("FAKEONLY", out)
        self.assertNotIn("not-a-real-credential", out)
        self.assertIn("403", out)
        self.assertIn("retry=no", out)

    def test_normal_text_response_is_unchanged(self):
        self.requests.post.return_value = types.SimpleNamespace(
            ok=True, json=lambda: {"choices": [{"message": {"content": "normal response"}}]})
        self.assertEqual(self.ns["_openai_chat_request"](self.key, "system", "text"), "normal response")

if __name__ == "__main__":
    unittest.main()
