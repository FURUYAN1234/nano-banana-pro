# SPDX-License-Identifier: MIT
"""Regression tests run without provider credentials or model downloads."""
import ast
import importlib.util
import json
import pathlib
import re
import sys
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

language = load("h3_test_prose", ROOT / "prose_language.py")
policy = load("h3_test_candidate", ROOT / "candidate_policy.py")
def rows_request(request, transform):
    rows = json.loads(request.split("\n", 1)[1])["rows"]
    return {"rows": [{"id": r["id"], "text": transform(r["text"])} for r in rows]}

class ProseTests(unittest.TestCase):
    def test_english_and_japanese_spoken_words_need_no_request(self):
        text = 'summary:\nA girl speaks. (S2) <d>[Japanese] まだ、いける！</d>\noverlay_title: "物語"'
        out, report = language.normalize_prose(text, lambda _: self.fail("unneeded API"))
        self.assertEqual(out, text)
        self.assertEqual(report["attempts"], 0)

    def test_preserves_dialogue_ownership_labels_time_and_title(self):
        text = 'overlay_title: "物語"\ndetailed_description:\n[Shot 2] At 00:05.000,\n<Subject 2> が座る。 (S2)\n<d>[Japanese] まだ、いける！</d>'
        out, report = language.normalize_prose(text, lambda q: rows_request(q, lambda v: v.replace("が座る。", "sits down.")))
        self.assertEqual(out, text.replace("が座る。", "sits down."))
        self.assertEqual(language.dialogue_signature(out), language.dialogue_signature(text))
        self.assertEqual(report["status"], "translated")

    def test_protected_visible_writing_is_retained(self):
        text = '看板には「入口」とある。'
        out, _ = language.normalize_prose(text, lambda q: rows_request(q, lambda v: v.replace("看板には", "The sign reads ").replace("とある。", ".")))
        self.assertEqual(out, 'The sign reads 「入口」.')

    def test_token_deletion_or_new_dialogue_rejected(self):
        original = '<Subject 7> が座る。 (S7) <d>こんにちは</d>'
        for transform in [lambda s: "Someone sits.", lambda s: s.replace("が座る。", "<d>hello</d>")]:
            with self.subTest(transform=transform):
                out, report = language.normalize_prose(original, lambda q: rows_request(q, transform))
                self.assertEqual(out, original)
                self.assertEqual(report["attempts"], 2)

    def test_reordered_speakers_rejected(self):
        text = '<Subject 1> が座る。 (S1) <d>はい</d>'
        def bad(v):
            tokens = language._TOKEN.findall(v)
            return " ".join(reversed(tokens)) + " sits."
        self.assertEqual(language.normalize_prose(text, lambda q: rows_request(q, bad))[0], text)

    def test_partial_best_survives_later_unavailable_request(self):
        text = '人が座る。\n雨が降る。'
        calls = []
        def request(q):
            calls.append(q)
            return rows_request(q, lambda v: v.replace('人が座る。', 'A person sits.')) if len(calls) == 1 else None
        out, report = language.normalize_prose(text, request)
        self.assertEqual(out, 'A person sits.\n雨が降る。')
        self.assertEqual(report["status"], "partial")
        self.assertEqual(len(calls), 2)

    def test_malformed_response_falls_back_without_stopping(self):
        text = '人が座る。'
        for raw in ['bad JSON', {"rows": []}, {"rows": [{"id": [], "text": "hello"}]}, None]:
            self.assertEqual(language.normalize_prose(text, lambda q: raw)[0], text)

    def test_duplicate_or_extra_rows_rejected(self):
        text = '人が座る。'
        for rows in [[{"id": 0, "text": "A person sits."}] * 2, [{"id": 22, "text": "A person sits."}]]:
            self.assertEqual(language.normalize_prose(text, lambda q: {"rows": rows})[0], text)

class CandidateTests(unittest.TestCase):
    def test_fewer_identity_errors_wins_and_unknown_is_not_pass(self):
        lesser = {"issues": ["wrong hair"], "matches": []}
        worse = {"issues": ["wrong hair", "duplicate"], "unexpected_entities": ["copy"]}
        self.assertLess(policy.identity_rank(False, lesser), policy.identity_rank(False, worse))
        self.assertLess(policy.identity_rank(False, worse), policy.identity_rank(False, {"status": "unavailable"}))
        self.assertLess(policy.identity_rank(True, {}), policy.identity_rank(False, lesser))

    def test_good_reference_not_replaced_by_duplicate(self):
        first = policy.reference_rank(False, "small text", True, {})
        second = policy.reference_rank(True, "", False, {"issues": ["duplicate"], "matches": [{"instances": 2}]})
        self.assertLess(first, second)

class TimingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        source = ast.parse((ROOT / "__init__.py").read_text(encoding="utf-8"))
        names = {"_dialogue_schedule_issues", "_repair_dialogue_schedule"}
        constants = {"_DIALOGUE_TAG_RE", "_SHOT_MARKER_RE", "_DIALOGUE_REPAIR_SYSTEM"}
        nodes = [ast.ImportFrom(module="__future__", names=[ast.alias(name="annotations")], level=0)]
        nodes += [n for n in source.body if (isinstance(n, ast.FunctionDef) and n.name in names) or
                  (isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id in constants for t in n.targets))]
        cls.ns = {"re": re, "dialogue_signature": language.dialogue_signature}
        exec(compile(ast.fix_missing_locations(ast.Module(body=nodes, type_ignores=[])), "timing-test", "exec"), cls.ns)
    def run_repair(self, responses):
        self.ns["_openai_chat_request"] = lambda *a, **k: responses.pop(0)
        prompt = '[Shot 1]\n(S1) <d>やあ</d>\n[Shot 2] At 00:00.000,\n(S2) <d>はい</d>'
        return prompt, self.ns["_repair_dialogue_schedule"]("OpenAI API", "", prompt, None)
    def test_changed_words_or_speakers_are_never_accepted(self):
        for bad in ['[Shot 1]\n(S1) <d>bye</d>\n[Shot 2] At 00:05.000,\n(S2) <d>はい</d>',
                    '[Shot 1]\n(S2) <d>やあ</d>\n[Shot 2] At 00:05.000,\n(S1) <d>はい</d>']:
            before, after = self.run_repair([bad, bad])
            self.assertEqual(after, before)
    def test_valid_retiming_preserves_words(self):
        fixed = '[Shot 1]\n(S1) <d>やあ</d>\n[Shot 2] At 00:05.000,\n(S2) <d>はい</d>'
        self.assertEqual(self.run_repair([fixed])[1], fixed)
    def test_all_failed_retries_return_original_without_exception(self):
        before, after = self.run_repair(["", ""])
        self.assertEqual(after, before)


class TransformSelectionTests(unittest.TestCase):
    def test_transform_returns_best_image_and_prompt_after_failed_repairs(self):
        import tempfile
        import types
        from unittest.mock import patch
        source = ast.parse((ROOT / "__init__.py").read_text(encoding="utf-8"))
        transform = next(n for n in source.body if isinstance(n, ast.ClassDef) and n.name == "NanoBananaH3Transform")
        module = ast.Module(body=[ast.ImportFrom(module="__future__", names=[ast.alias(name="annotations")], level=0), transform], type_ignores=[])
        resume = types.ModuleType("h3_test_parent.resume_context")
        resume.restore = lambda *args: None
        prompts = iter(["summary:\nfirst candidate", "summary:\nsecond candidate"])
        def verdict(provider, key, inventory, source, candidate, prompt=None):
            if prompt is None:
                return (True, {"pass": True}) if candidate == "first image" else (False, {"issues": ["duplicate"], "matches": [{"instances": 2}]})
            return False, {"issues": ["one issue"] if "first" in prompt else ["one", "two", "three"]}
        with tempfile.TemporaryDirectory() as directory, patch.dict(sys.modules, {"h3_test_parent.resume_context": resume}):
            ns = {
                "__package__": "h3_test_parent", "__name__": "h3_test_parent",
                "json": json, "re": re, "Path": pathlib.Path,
                "time": types.SimpleNamespace(time=lambda: 1),
                "folder_paths": types.SimpleNamespace(get_output_directory=lambda: directory, get_temp_directory=lambda: directory),
                "_PROVIDERS": ["OpenAI API"], "IDENTITY_REVISION": "test", "_SINGLE_FRAME_CONTRACT": "",
                "_credential": lambda p: "test-not-a-key",
                "_advisory_check": lambda op, fallback: op(),
                "_source_inventory": lambda *a: {}, "contract_text": lambda *a: "",
                "_reference_composition_source": lambda image, inventory: image,
                "_openai_image_edit": lambda *a: "first image",
                "_create_reference_candidate": lambda *a: "second image",
                "_inspect_single_clean_frame": lambda p, k, i: (i == "second image", "minor text"),
                "_identity_verdict": verdict, "_save_diagnostic_image": lambda *a: "diagnostic.png",
                "_identity_text_request": lambda *a: next(prompts),
                "_uses_auto_dialogue_duration": lambda p: False,
                "_canonicalize_dialogue_language_tags": lambda p: p,
                "normalize_reference_definition": lambda p, inventory: p,
                "_normalize_h3_prose": lambda provider, key, prompt: prompt,
                "reference_rank": policy.reference_rank, "identity_rank": policy.identity_rank,
                "AUTHORING_LANGUAGE": language.AUTHORING_LANGUAGE,
            }
            exec(compile(ast.fix_missing_locations(module), "transform-integration", "exec"), ns)
            output = ns["NanoBananaH3Transform"]().transform("source", "OpenAI API", 0.0, 42, "image instruction", "prompt instruction")
            self.assertEqual(output[:2], ("first image", "summary:\nfirst candidate"))
            metadata = json.loads(pathlib.Path(directory, "diagnostic.png.json").read_text(encoding="utf-8"))
            self.assertEqual(metadata["selected_reference_attempt"], 1)
            self.assertEqual(metadata["selected_prompt_attempt"], 1)

if __name__ == "__main__":
    unittest.main()
