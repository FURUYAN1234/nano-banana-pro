# SPDX-License-Identifier: MIT
"""Ranks advisory authoring candidates; unknown audits are never successful."""
def identity_rank(passed, result):
    if passed is True:
        return (0, 0)
    if not isinstance(result, dict) or result.get("status") == "unavailable":
        return (2, 0)
    issues = result.get("issues")
    matches = result.get("matches")
    if not isinstance(issues, list) and not isinstance(matches, list):
        return (2, 0)
    score = 10 * len(issues or []) + 100 * len(result.get("unexpected_entities") or [])
    for row in matches or []:
        if not isinstance(row, dict):
            score += 100
            continue
        instances = row.get("instances")
        if type(instances) is int:
            score += 100 * abs(instances - 1)
        for field in ("appearance_preserved", "attachments_preserved", "core_identity_preserved"):
            if row.get(field) is False:
                score += 40
    return (1, max(1, score))

def reference_rank(clean, reason, identity_ok, identity_result):
    category, score = identity_rank(identity_ok, identity_result)
    clean_unknown = not clean and reason == "unavailable"
    # Prefer evaluated identities, then the fewest identity/layout defects.
    return (max(category, 2 if clean_unknown else 0),
            score + (0 if clean else 30))
