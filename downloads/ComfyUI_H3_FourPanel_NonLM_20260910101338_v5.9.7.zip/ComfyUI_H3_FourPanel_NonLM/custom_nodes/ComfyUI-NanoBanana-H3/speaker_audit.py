"""Validate visible dialogue ownership separately from identity/ASR checks."""
import re

def speech_expectation(prompt):
    definition=re.split(r'(?im)^\s*(?:summary|detailed_description|integrated_multimodal_description)\s*:',prompt,maxsplit=1)[0]
    mapping={};ambiguous=set()
    for line in re.finditer(r'(?im)^\s*<Subject\s+(\d+)>[^\n]*',definition):
        subject=int(line.group(1))
        for sid in re.findall(r'\(S(\d+)\)',line.group(0),re.I):
            sid=int(sid)
            if sid in mapping and mapping[sid]!=subject:ambiguous.add(sid)
            mapping[sid]=subject
    shots=list(re.finditer(r'\[Shot\s+\d+\]',prompt,re.I))
    if not shots:return None
    local=prompt[shots[0].start():]
    turns=list(re.finditer(r'<d>(.*?)</d>',local,re.I|re.S))
    if len(turns)!=1:return None
    turn=turns[0];prefix=local[:turn.start()]
    # Narration explicitly marked off-screen is not an on-screen lip-sync task.
    clause=re.split(r'[.!?\n]',prefix)[-1]
    if re.search(r'(?i)off[- ]screen|voice[- ]over|narrator',clause):return None
    tokens=list(re.finditer(r'<Subject\s+(\d+)>|\(S(\d+)\)',prefix,re.I))
    if not tokens:return None
    token=tokens[-1]
    if token.group(2):
        sid=int(token.group(2));subject=mapping.get(sid)
        if sid in ambiguous or subject is None:return None
    else:
        subject=int(token.group(1));ids=[k for k,v in mapping.items() if v==subject and k not in ambiguous]
        if len(ids)!=1:return None
        sid=ids[0]
    return {'subject_id':subject,'speaker_id':'S'+str(sid)}


def speaker_audit_instruction(expected, frame_count):
    if expected is None:return ''
    return (" VISIBLE SPEAKER CHECK is required independently of correct words and identity. "
            "The intended physical speaker is <Subject {subject_id}> ({speaker_id}). "
            "Use their reference appearance to identify them; screen position is not their identity. "
            "Candidate images are chronological. With six frames, pairs 1/2, 3/4 and 5/6 "
            "are nearby instants: compare changing lip/jaw shapes within each pair. "
            "A single open mouth, smile, yawn, breath or silent surprised reaction alone "
            "does not prove speech. Report not_observable when articulation cannot be resolved. "
            "Do not pass merely because the expected words were heard elsewhere or the right "
            "character is present. Fail if another visible identity articulates the line, "
            "several characters visibly speak it, or the expected speaker stays silent while "
            "another speaks. Non-speakers may blink, breathe and react silently. "
            "Add speaker_check to the JSON: {{status:pass|fail|not_observable, "
            "expected_subject_id:{subject_id},expected_speaker_id:'{speaker_id}', "
            "observed_speaking_subject_ids:[integer IDs],extra_speaking_subject_ids:[], "
            "evidence:[{{subject_id:integer,frame_indices:[two or more distinct indices from 1..{count}], "
            "observation:'concrete visible lip/jaw change'}}]}}. "
            "Overall pass requires the expected speaker alone to be verified; missing or "
            "not_observable speaker evidence is not a pass. Keep identity and speaker "
            "findings separate in the report.").format(count=frame_count,**expected)


def speaker_check_passes(result, expected, frame_count):
    if expected is None:return True
    check=result.get('speaker_check') if isinstance(result,dict) else None
    if not isinstance(check,dict) or check.get('status')!='pass':return False
    subject=expected['subject_id']
    if type(check.get('expected_subject_id')) is not int or check['expected_subject_id']!=subject:return False
    if check.get('expected_speaker_id')!=expected['speaker_id']:return False
    observed=check.get('observed_speaking_subject_ids')
    if observed!=[subject] or any(type(x) is not int for x in observed):return False
    if check.get('extra_speaking_subject_ids')!=[]:return False
    evidence=check.get('evidence')
    if not isinstance(evidence,list):return False
    for row in evidence:
        if (not isinstance(row,dict) or type(row.get('subject_id')) is not int
            or row['subject_id']!=subject):continue
        indices=row.get('frame_indices')
        if (isinstance(indices,list) and len(indices)>=2
            and all(type(i) is int and 1<=i<=frame_count for i in indices)
            and len(set(indices))>=2 and isinstance(row.get('observation'),str)
            and row['observation'].strip()):return True
    return False
