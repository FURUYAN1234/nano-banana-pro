"""Source-derived identity checks; no character names or fixed population sizes."""
import json
import re
import unicodedata

REVISION = "source-identity-v13"
KINDS = {"human", "animal", "robot", "fantasy", "object"}

INVENTORY_INSTRUCTION = '''Inspect the original manga image. Return ONLY JSON:
{"entities":[{"id":"E1","kind":"human|animal|robot|fantasy|object",
"appearance":"source-derived face, clothes, colors and distinguishing features",
"hair":"observed length/shape or not_applicable or uncertain",
"appendages":"tails/ears/wings/accessories, their owner and attachment points; or none/uncertain",
"evidence":"where in the source these features are visible",
"panels":[1]}],"background":"source-supported crowd/environment",
"uncertainties":[],"dialogues":[{"entity_id":"E1","text":"exact original spoken text",
"panel":1,"evidence":"balloon tail or clear visual connection to this entity"}]}
Deduplicate repeated drawings of the same character across panels. Distinct twins or
look-alikes are distinct entities if the source establishes them. Include all story
characters and identity-critical robots/animals/objects; exclude incidental furniture
from entity counts. Never infer humans from panels, dialogue turns, speaker IDs or
robots. Describe ambiguous green/colored shapes as uncertain rather than guessing
hair versus tail versus clothing. Do not use franchise knowledge to replace evidence.
Empty entities is valid for a scene with no identifiable characters/critical objects.
Number IDs E1,E2,... independently of speaker IDs. Panel numbers refer to source panels.
Extract every spoken balloon in source reading order (Japanese manga: right to left
within each panel, panels top to bottom). Map each balloon to its actual speaker using
its tail, proximity and visual evidence, NOT left-to-right character numbering.
Do not include titles, credits, signs, sound effects or screen text as dialogue.
Use an empty dialogues list for a silent source. Preserve exact text and punctuation.
'''

def parse_json(value):
    value = value.strip()
    if value.startswith("```"):
        value = value.split("\n", 1)[1].rsplit("```", 1)[0].strip()
    result = json.loads(value)
    if not isinstance(result, dict):
        raise ValueError("Identity response must be a JSON object")
    return result

def validate_inventory(value):
    data = parse_json(value) if isinstance(value, str) else value
    if not isinstance(data, dict) or not isinstance(data.get("entities"), list):
        raise ValueError("Identity inventory has no entity list")
    for i, entity in enumerate(data["entities"], 1):
        if not isinstance(entity, dict) or entity.get("id") != f"E{i}" or entity.get("kind") not in KINDS:
            raise ValueError("Identity inventory has invalid IDs or entity kinds")
        for key in ("appearance", "hair", "appendages", "evidence"):
            if not isinstance(entity.get(key), str) or not entity[key].strip():
                raise ValueError(f"Identity inventory lacks {key}")
        if not isinstance(entity.get("panels"), list) or not entity["panels"] or any(type(n) is not int or n < 1 for n in entity["panels"]):
            raise ValueError("Identity inventory lacks source-panel evidence")
    if not isinstance(data.get("background"), str) or not isinstance(data.get("uncertainties"), list):
        raise ValueError("Identity inventory lacks background/uncertainty fields")
    if not isinstance(data.get('dialogues'), list):
        raise ValueError('Source inventory lacks dialogue ownership')
    ids={e['id'] for e in data['entities']}
    for row in data['dialogues']:
        if (not isinstance(row,dict) or row.get('entity_id') not in ids
            or not isinstance(row.get('text'),str) or not row['text'].strip()
            or type(row.get('panel')) is not int or row['panel']<1
            or not isinstance(row.get('evidence'),str) or not row['evidence'].strip()):
            raise ValueError('Source dialogue lacks an evidenced speaker')
    return data

def contract_text(inventory, include_dialogue=False):
    validate_inventory(inventory)
    contract=inventory if include_dialogue else {k:v for k,v in inventory.items() if k!='dialogues'}
    if not include_dialogue:
        contract=dict(contract,entities=[{k:v for k,v in e.items() if k not in ('evidence','panels')} for e in inventory['entities']])
    return ("SOURCE IDENTITY INVENTORY (E IDs are source bookkeeping, not H3 labels "
            "or extra bodies):\n" + json.dumps(contract, ensure_ascii=False) +
            "\nPreserve kinds, distinguishing features and attachment points. "
            "Repeated panels depict the same identity. Hair, tails, ears, clothing "
            "and props must not be merged or reassigned. Do not resolve uncertain "
            "features by inventing anatomy. Show each intended identity once in "
            "the clean reference. Source crowds remain background crowds, never "
            "copies of main characters. Later shots follow the source panel's "
            "visible subset; do not force every entity into every shot.")


def _renderable_identity(value):
    """Source label OCR identifies an object but must not reintroduce its lettering."""
    value=re.sub(r'''["'“‘][^"'”’\n]+["'”’](\s+(?:shirt|T-shirt|hoodie|badge|label)\b)''',
                 r'unmarked\1',value,flags=re.I)
    quoted=r'''(?:"[^"\n]*"|'[^'\n]*'|“[^”\n]*”|「[^」\n]*」)'''
    # Real v10 OCR phrased a printed shirt label as `shirt with "..." on it`.
    # Match the surface and printing context so physical quoted accessories survive.
    surface=r'(?:T-shirt|shirt|hoodie|badge|display|screen|panel|sign|label)'
    value=re.sub(r'\b('+surface+r')\s+with\s+'+quoted+r'\s+(?:printed\s+)?on\s+(?:it|the\s+front|its\s+front)\b',
                 r'unmarked \1',value,flags=re.I)
    value=re.sub(r'\b(display|screen|panel|sign|badge|label|T-shirt|shirt|hoodie)\s+(?:labelled|labeled|reading|reads?|saying)\s+(?:'+quoted+r'|[^,.;\n]+)',
                 r'unmarked \1',value,flags=re.I)
    value=re.sub(quoted+r'(?:-like)?\s+(hair\s+)?(accessory|clip)(?:/letters)?',
                 lambda m:'unmarked '+(m.group(1) or '')+m.group(2),value,flags=re.I)
    value=re.sub(quoted+r'\s+(?:text|lettering|letters)\b','unmarked surface',value,flags=re.I)
    value=re.sub(r'\ba unmarked\b','an unmarked',value)
    return value


def _dialogue_key(text):
    text=re.sub(r'^\s*\[[^\]]+\]\s*','',text)
    text=unicodedata.normalize('NFKC',text)
    return ''.join(c for c in text if not c.isspace() and not unicodedata.category(c).startswith('P'))


def align_dialogue_shots(prompt, inventory):
    """Order complete single-turn shots by verified source text AND speaker.

    Do not relabel an unrelated character or substitute words inside its action.
    If a shot cannot be matched, retain the input so validation can request repair.
    """
    markers=list(re.finditer(r'(?im)^[ \t]*\[Shot\s+\d+\](?:[ \t]+At[ \t]+\d+:\d+(?:\.\d+)?[ \t]*,?)?',prompt))
    source=inventory['dialogues']
    if not source or len(markers)!=len(source):return prompt
    tail=re.search(r'(?im)^\s*overall_soundscape\s*:',prompt[markers[-1].end():])
    if tail is None:return prompt
    tail_start=markers[-1].end()+tail.start()
    blocks=[];available={}
    for i,marker in enumerate(markers):
        end=markers[i+1].start() if i+1<len(markers) else tail_start
        body=prompt[marker.end():end].strip()
        turns=list(re.finditer(r'<d>(.*?)</d>',body,re.S|re.I))
        if len(turns)!=1:return prompt
        turn=turns[0];speakers=re.findall(r'\(S(\d+)\)',body[:turn.start()],re.I)
        if not speakers:return prompt
        key=(_dialogue_key(turn.group(1)),'E'+speakers[-1])
        available.setdefault(key,[]).append(i);blocks.append(body)
    order=[]
    for row in source:
        matches=available.get((_dialogue_key(row['text']),row['entity_id']),[])
        if not matches:return prompt
        order.append(matches.pop(0))
    if any(available.values()):return prompt
    rendered=[]
    for i,index in enumerate(order):
        minutes,seconds=divmod(i*5,60)
        anchor='[Shot 1]' if i==0 else f'[Shot {i+1}] At {minutes:02d}:{seconds:02d}.000,'
        rendered.append(anchor+'\n'+blocks[index])
    return prompt[:markers[0].start()]+'\n\n'.join(rendered)+'\n\n'+prompt[tail_start:].lstrip()


def normalize_reference_definition(prompt, inventory=None):
    # A generated reference description once added a fourth person beside a robot.
    # The reference is completely identified by the verified entity definitions.
    parts=re.split(r'(?im)^(\s*summary\s*:)',prompt,maxsplit=1)
    parts[0]=re.sub(r'(?im)^\s*<Picture\s+1>\s*:[^\n]*',
        '<Picture 1>: The verified reference scene containing each defined source entity once; background crowds are not additional main identities.',parts[0])
    if inventory is not None:
        # Identity attributes are structured data, not a verbatim-copy exam for a model.
        # Keep the generated voice description but render identity definitions ourselves.
        old=dict(re.findall(r'(?im)^\s*<Subject\s+(\d+)>[^\n]*?(Voice\s*:[^\n]*)',parts[0]))
        old={k:re.split(r'(?i)\b(?:Hair|Appendages|Appearance)\s*:',v,maxsplit=1)[0].strip() for k,v in old.items()}
        speakers={r['entity_id'] for r in inventory['dialogues']}
        rows=re.findall(r'(?im)^\s*overlay_title\s*[:：][^\n]*',parts[0])+['subject_definitions:']
        for i,e in enumerate(inventory['entities'],1):
            label=f' (S{i})' if e['id'] in speakers else ''
            appearance=_renderable_identity(e['appearance'])
            hair=_renderable_identity(e['hair']);appendages=_renderable_identity(e['appendages'])
            rows.append(f"<Subject {i}>{label}: {e['kind']}. {appearance}. Hair: {hair}. Appendages: {appendages}. "+old.get(str(i),''))
        rows.append('<Picture 1>: The verified reference scene containing each defined source entity once; background crowds are not additional main identities.')
        parts[0]='\n'.join(rows)+'\n\n'
    result=''.join(parts)
    if inventory is not None:
        retention=['retention_analysis:',
            '<Picture 1>: partially_preserved; retain the reference identities and style, with story-driven framing.']
        for i,e in enumerate(inventory['entities'],1):
            panels=', '.join(str(p) for p in e['panels'])
            retention.append(f'<Subject {i}>: fully_preserved identity attributes whenever visible; evidenced in source panels {panels}. Visibility follows the current source beat, not a requirement to appear in every shot.')
        result=re.sub(r'(?ims)^\s*retention_analysis\s*:.*?(?=^\s*detailed_description\s*:)',
                      '\n\n'+'\n'.join(retention)+'\n\n',result,count=1)
        # Generated global prose previously invented "all four subjects and robot"
        # and forced that aggregate into source panels which omit the robot.
        result=re.sub(r'(?ims)^\s*\[Global Instructions\]\s*.*\Z','',result).rstrip()
        result+='\n\n[Global Instructions]\nPreserve each source identity, physical attachments, clothing design, voice and visual style across shots. Each visible main identity has one body; source background crowds remain background crowds. A defined identity need not appear in every shot. Preserve the verified source dialogue order and the sole active speaker in each five-second window. Keep all non-speakers\' lips closed. Printed words are intentionally removed while the underlying clothes, clips and props retain their physical shapes and colors. Only the workflow adds publication text after video generation. Preserve the selected continuous soundscape and music policy.'
    return result


def prompt_contract_issues(prompt,inventory):
    """Check source speaker ownership using actual tags, without a model verdict."""
    issues=[]
    definitions=re.split(r'(?im)^\s*summary\s*:',prompt,maxsplit=1)[0]
    lines=re.findall(r'(?im)^\s*<Subject\s+(\d+)>\s*([^\n]*)',definitions)
    expected={str(i):e for i,e in enumerate(inventory['entities'],1)}
    if len(lines)!=len(expected) or {n for n,_ in lines}!=set(expected):
        issues.append('Define exactly one Subject per inventory E ID: E1 -> Subject 1, E2 -> Subject 2, etc.; no extra Subject definitions.')
    speaker_to_entity={}
    for number,line in lines:
        if number not in expected:continue
        entity=expected[number]
        for sid in re.findall(r'\((S\d+)\)',line,re.I):
            sid=sid.upper()
            if sid in speaker_to_entity and speaker_to_entity[sid]!=entity['id']:
                issues.append('A speaker label is assigned to multiple entities: '+sid)
            speaker_to_entity[sid]=entity['id']
    turns=list(re.finditer(r'<d>.*?</d>',prompt,re.S|re.I))
    source=inventory['dialogues']
    if len(turns)!=len(source):
        issues.append(f"Preserve all {len(source)} source dialogue turns in reading order; found {len(turns)}.")
    for i,(turn,row) in enumerate(zip(turns,source)):
        spoken=re.sub(r'^<d>|</d>$','',turn.group(0),flags=re.I)
        if _dialogue_key(spoken)!=_dialogue_key(row['text']):
            issues.append(f"Dialogue {i+1} must retain source text/order: {row['text']}")
        boundary=turns[i-1].end() if i else len(definitions)
        prefix=prompt[boundary:turn.start()]
        shot=list(re.finditer(r'\[Shot\s+\d+\]',prefix,re.I))
        if shot:prefix=prefix[shot[-1].end():]
        speakers=re.findall(r'\((S\d+)\)',prefix,re.I)
        actual=speaker_to_entity.get(speakers[-1].upper()) if speakers else None
        if actual!=row['entity_id']:
            issues.append(f"Dialogue {i+1} belongs to {row['entity_id']} (source: {row['text']}); bind its speaking tag to that entity. Found {actual or 'unbound speaker'}.")
    return issues

def verdict_passes(value, inventory, prompt=False):
    data = parse_json(value) if isinstance(value, str) else value
    # No truthy strings, missing rows or unexamined identity matches count as pass.
    if not isinstance(data, dict) or data.get("pass") is not True or data.get("issues") != []:
        return False
    rows = data.get("matches")
    if not isinstance(rows, list) or len(rows) != len(inventory["entities"]):
        return False
    by_id = {e["id"]: e for e in inventory["entities"]}
    if len({r.get("id") for r in rows if isinstance(r, dict)}) != len(rows):
        return False
    if data.get("unexpected_entities") != []:
        return False
    labels = []
    for row in rows:
        if not isinstance(row, dict) or row.get("id") not in by_id:
            return False
        if row.get("kind") != by_id[row["id"]]["kind"] or row.get("appearance_preserved") is not True or row.get("attachments_preserved") is not True:
            return False
        if type(row.get("instances")) is not int or row["instances"] != 1:
            return False
        if prompt:
            label = row.get("subject_id")
            if type(label) is not int or label < 1:
                return False
            labels.append(label)
    return not prompt or len(set(labels)) == len(labels)

def audit_instruction(inventory, prompt=None, candidate_first=False):
    scope = ("Also verify that the H3 prompt preserves the source speaker ownership, "
             "entity kinds, attributes and each source panel's visible set. An entity "
             "must map to exactly one defined <Subject N>. subject_id is that integer. "
             "Count instances as intended simultaneous bodies, not repeated label mentions. "
             "Report conflicting human counts, identity transfer and duplicated bodies. "
             "PROMPT TO CHECK:\n" + prompt if prompt is not None else
             "Check each entity occurs once in the candidate scene. All inventory "
             "entities must be represented in this reference. Do not count background crowds "
             "as unexpected main entities unless they copy a main character.")
    image_order = ("Image 1 is the CANDIDATE single scene to inspect; image 2 is the ORIGINAL manga for identity reference only. "
                   if candidate_first else "Image 1 is the ORIGINAL manga; image 2 is the CANDIDATE single scene to inspect. ")
    rows = [{"id":e["id"], "kind":e["kind"], "instances":None,
             "appearance_preserved":None, "attachments_preserved":None,
             "candidate_region":"describe actual position and visible identifying features"}
            for e in inventory["entities"]]
    if prompt is not None:
        for row in rows:row["subject_id"]="integer from the actual H3 definition"
    return (image_order +
            "Compare them directly, using this source inventory:\n" + contract_text(inventory, prompt is not None) +
            "\n" + scope +
            "\nEXPLICIT TRANSFORMATION POLICY: All source printed writing is intentionally "
            "removed from the clean reference and generated video, including clothing text, "
            "hair-clip letters, prop labels, display lettering and speech balloons. Blank "
            "fabric and unlettered clips/controls are CORRECT, not missing identity features. "
            "Preserve their underlying physical shapes and colors. Do not require deleted "
            "writing to reappear. This rule overrides source inventory label transcriptions. "
            "\nIMPORTANT: A reference keyframe combines the manga into a NEW composition. "
            "Different poses, expressions, camera angles, left/right positions, scale, "
            "partial occlusion, and cropped legs are EXPECTED and are NOT identity errors. "
            "Determine presence from visible identity cues, not whether the entire body "
            "or its original pose is visible. Inspect the entire candidate, including "
            "edges and background, before reporting a missing entity. A partly visible "
            "robot or person is present. Evaluate hair length and anatomical attachments "
            "only where both sources provide visible evidence. An unobservable feature "
            "is not evidence of a change. Only flag concrete missing/duplicated identities, "
            "changed kinds or visible contradictory defining features.\n"
            "COUNT BODIES FIRST: Repeated source panels show the same identity, but "
            "the candidate is ONE simultaneous scene. In the candidate, standing and "
            "kneeling versions of the same identity, or a front-facing body plus a "
            "back-facing body of that identity, are DUPLICATE BODIES. Count every "
            "matching body across foreground, middle and background; do not deduplicate "
            "them as alternate poses or moments. Report every duplicate's position.\n"
            "Return JSON only, filling every row in this template with your actual observations: " +
            json.dumps({"pass":None,"issues":[],"unexpected_entities":[],"matches":rows},ensure_ascii=False) +
            "\nFor a missing entity use instances=0 and candidate_region describing the "
            "regions searched; for duplicates list BOTH positions. Do not omit rows. "
            "Do not copy defaults without checking the images.")
