﻿param([Parameter(Mandatory=$true)][string]$ComfyUIPath, [switch]$InstallMissing)
$ErrorActionPreference = 'Stop'
$installRoot = (Resolve-Path -LiteralPath $ComfyUIPath).Path
if (-not (Test-Path -LiteralPath (Join-Path $installRoot 'main.py') -PathType Leaf)) { throw 'ComfyUIのmain.pyがありません。' }
$nodeRoot = Join-Path $installRoot 'custom_nodes'
if (-not (Test-Path -LiteralPath $nodeRoot -PathType Container)) { throw 'custom_nodesがありません。' }
$packages = @('ComfyUI-NanoBanana-H3','ComfyUI-MiniMax-H3-Long-Video','ComfyUI-Spectrum-MiniMax-H3')
$sourceRoot = Join-Path $PSScriptRoot '02_カスタムノード'
foreach ($package in $packages) {
 if (-not (Test-Path -LiteralPath (Join-Path $sourceRoot "$package/__init__.py"))) { throw "配布物が不足: $package" }
}
& (Join-Path $PSScriptRoot '必須ノードの確認.ps1') -ComfyUIPath $installRoot -InstallMissing:$InstallMissing
$backupRoot = Join-Path $installRoot ('SuperFURU_backups/' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff'))
$rootPrefix = [IO.Path]::GetFullPath($installRoot).TrimEnd('\') + '\'
foreach ($package in $packages) {
 $destination = Join-Path $nodeRoot $package
 $backupDestination = Join-Path $backupRoot $package
 foreach ($candidate in @($destination,$backupDestination)) {
  if (-not ([IO.Path]::GetFullPath($candidate).StartsWith($rootPrefix,[StringComparison]::OrdinalIgnoreCase))) { throw "配置先がComfyUIの外です: $candidate" }
 }
 if (Test-Path -LiteralPath $destination) {
  if ((Get-Item -LiteralPath $destination).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "リンク先への移動を避けるため停止しました: $destination" }
  New-Item -ItemType Directory -Force -Path $backupRoot | Out-Null
  Move-Item -LiteralPath $destination -Destination $backupDestination
 }
 Copy-Item -LiteralPath (Join-Path $sourceRoot $package) -Destination $destination -Recurse
 Write-Host "導入: $package"
}
Write-Host '3パッケージのコピーが完了しました。外部ノードの配置も確認済みです。モデル4点・Python依存・TritonはREADMEに従い導入してください。'
Write-Host 'ComfyUIを再起動し、01_ワークフローのJSONを開いてください。'
if (Test-Path -LiteralPath $backupRoot) { Write-Host "旧版: $backupRoot" }
