﻿param([Parameter(Mandatory=$true)][string]$ComfyUIPath, [switch]$InstallMissing)
$ErrorActionPreference = 'Stop'
$installRoot = (Resolve-Path -LiteralPath $ComfyUIPath).Path
if (-not (Test-Path -LiteralPath (Join-Path $installRoot 'main.py') -PathType Leaf)) { throw 'ComfyUIのmain.pyがありません。' }
$manifest = Get-Content -LiteralPath (Join-Path $PSScriptRoot '外部必須ノード.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$missing = @()
foreach ($dependency in $manifest.dependencies) {
 $destination = Join-Path (Join-Path $installRoot 'custom_nodes') $dependency.directory
 if (Test-Path -LiteralPath (Join-Path $destination '__init__.py') -PathType Leaf) { Write-Host "配置済み: $($dependency.name)（読み込み成功はComfyUI起動後に確認）"; continue }
 if ($InstallMissing) {
  if (Test-Path -LiteralPath $destination) { throw "不完全な既存フォルダがあります。上書きせず停止: $destination" }
  if (-not (Get-Command git -ErrorAction SilentlyContinue)) { throw 'Gitがありません。同梱の必須ノード取得.htmlから正規配布先を開いてください。' }
  & git clone --depth 1 -- $dependency.repository $destination
  if ($LASTEXITCODE -ne 0) { throw "取得失敗: $($dependency.name)" }
  if (-not (Test-Path -LiteralPath (Join-Path $destination '__init__.py'))) { throw "取得内容が不完全です: $destination" }
  Write-Host "取得完了: $($dependency.name)"
 } else {
  $missing += $dependency.name
  Write-Host "不足: $($dependency.name)"
  Write-Host "正規取得先: $($dependency.repository)"
  Write-Host "保存先: $destination"
 }
}
if ($missing.Count) { throw '外部必須ノードが不足しています。必須ノード取得.htmlを開くか、このスクリプトを -InstallMissing 付きで実行してください。' }
Write-Host '配置の確認が完了しました。PlagueKindのrequirementsとTritonはComfyUIのPythonへ導入し、起動後のノード読み込みを確認してください。'
