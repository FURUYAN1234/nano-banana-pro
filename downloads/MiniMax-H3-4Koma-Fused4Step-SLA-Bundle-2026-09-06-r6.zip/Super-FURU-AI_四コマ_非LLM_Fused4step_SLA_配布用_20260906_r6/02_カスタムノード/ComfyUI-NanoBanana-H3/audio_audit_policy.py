"""Practical dialogue acceptance; a harmless hesitation is not a failed line."""
import re
import unicodedata

def _spoken_form(text):
    text = unicodedata.normalize('NFKC', text)
    text = ''.join(chr(ord(c)-0x60) if 'ァ' <= c <= 'ヶ' else c for c in text)
    return ''.join(c for c in text if not c.isspace() and not unicodedata.category(c).startswith(('P','S')))

def minor_filler_only(expected, acoustic):
    if not expected or not isinstance(acoustic, dict):
        return False
    transcript = acoustic.get('verbatim_transcript')
    issues = acoustic.get('issues')
    if not isinstance(transcript, str) or not isinstance(issues, list) or not issues:
        return False
    # Length of an expressive long-vowel mark is not an extra spoken clause.
    expected_form = _spoken_form(''.join(expected))
    heard_form = _spoken_form(transcript)
    issue_texts = [' '.join(str(v) for v in i.values()) if isinstance(i, dict) else str(i) for i in issues]
    if ('ー' in expected_form
            and re.sub(r'ー+っ?$', 'ー', re.sub('ー+', 'ー', expected_form)) == re.sub(r'ー+っ?$', 'ー', re.sub('ー+', 'ー', heard_form))
            and all(re.search(r'prolong|vowel|elongat|伸ば|長音', t, re.I) for t in issue_texts)
            and not any(re.search(r'repeated (?:phrase|sentence|word)|overlap|doubl|missing|wrong|changed meaning|台詞.*重複|欠落', t, re.I) for t in issue_texts)):
        return True
    for issue in issues:
        text = ' '.join(str(v) for v in issue.values()) if isinstance(issue, dict) else str(issue)
        if re.search(r'repeat|overlap|doubl|missing|truncat|wrong|changed meaning|重複|繰り返|欠落|別の台詞', text, re.I):
            return False
        if not re.search(r'hesitation|interjection|filler|minor_filler|exhalation|sigh|breath|間投詞|ためらい|フィラー|感嘆|ため息|吐息|息継ぎ', text, re.I):
            return False
    # Require a word boundary: do not strip the start of a meaningful word.
    cleaned = re.sub(r'^\s*(?:あっ|えっ|えーと|えっと|うーん|あの|はぁ|はあ|ふぅ|ふう)[\s、,。!！?？]+', '', transcript, count=1)
    return cleaned != transcript and _spoken_form(cleaned) == _spoken_form(''.join(expected))
