import json,pathlib,zipfile,sys

def validate(w,readme):
 nodes={n['id']:n for n in w['nodes']};links={l[0]:l for l in w['links']}
 transform=next(n for n in nodes.values() if n['type']=='NanoBananaH3Transform')
 port=next(i for i in transform['inputs'] if i['name']=='h3_prompt_instruction');source=nodes[links[port['link']][1]]
 prompt=source['widgets_values'][0];final=prompt.split('[H3-GENERATED BGM AND DIALOGUE STABILITY OVERRIDE')[-1]
 assert 'must not be N/A' in final and 'H3生成BGMあり' in readme and 'BGMなし' not in readme,'BGM mismatch'
 for typ,count,index in [('BasicScheduler',4,1)]:
  n=next(n for n in nodes.values() if n['type']==typ);assert n['widgets_values_named']['steps']==count
 sampler=next(n for n in nodes.values() if n['type']=='MiniMaxH3LongReferenceSampler');assert sampler['widgets_values_named']['audio_refine_steps']==2
 assert 'H3SLAAttention' in [n['type'] for n in nodes.values()]
 for term in ['4ステップ','2ステップ','ComfyUI-PlagueKind-Nodes','Triton','custom_nodes','APIキー','読み確認','output/video/MiniMax_H3','不足モデル']:assert term in readme,term
 loaders=[n for n in nodes.values() if n['type'] in ['UNETLoader','CLIPLoader','VAELoader']];assert len(loaders)==4
 for n in loaders:
  model=n['properties']['models'][0];assert model['name']==n['widgets_values'][0];assert model['directory'] in ['diffusion_models','text_encoders','vae'];assert model['url'].startswith('https://') and model['name'] in model['url']
 return {'bgm':'H3-generated, strongly ducked','video_steps':4,'audio_refine_steps':2,'model_loaders_with_metadata':4,'h3_instruction_source_node':source['id']}
if __name__=='__main__':
 p=pathlib.Path(sys.argv[1])
 if p.suffix=='.zip':
  with zipfile.ZipFile(p) as z:
   w=json.loads(z.read(next(n for n in z.namelist() if '/01_ワークフロー/' in n and n.endswith('.json'))));r=z.read(next(n for n in z.namelist() if n.endswith('/README_最初にお読みください.md'))).decode('utf8')
 else:w=json.loads(next((p/'01_ワークフロー').glob('*.json')).read_text(encoding='utf8'));r=(p/'README_最初にお読みください.md').read_text(encoding='utf8')
 print(json.dumps(validate(w,r),ensure_ascii=False))
 try:validate(w,r.replace('H3生成BGMあり','BGMなし'))
 except AssertionError:print('BGM誤記の検出: PASS')
 else:raise RuntimeError('negative case missed')
